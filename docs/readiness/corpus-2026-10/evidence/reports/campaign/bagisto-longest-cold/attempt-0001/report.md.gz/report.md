# PHP Upgrade Preflight Report

Resolution: **blocked** | Staged: **blocked** | Schema: `0.8` | Tool: `php-upgrade-preflight 0.3.5`

## Decision Summary
- Direct target: `blocked`.
- Staged path: `evaluated`, `blocked`; stop reason: `blocking_registry_not_cleared`.
- First recorded direct dependency finding: `transitive-package-conflict` for `laravel/framework` (evidence: `solver-1`, `solver-2`, `solver-3`, `solver-5`).
- First active staged blocker: `transitive-package-conflict` for `laravel/framework` (evidence: `solver-6`, `stage-attempt-1`, `solver-7`, `solver-8`).
- Relevant recorded plan actions:
  - laravel-10-to-11: [laravel-10-to-11] Resolve every active blocker and rerun this complete stage; do not advance. (evidence: `stage-plan-1`, `laravel-stage-target-1`, `laravel-stage-remediation-2`, `laravel-stage-remediation-1`, `laravel-stage-remediation-3`, `stage-attempt-1`, `stage-root-change-1`, `stage-attempt-2`, `stage-root-change-2`, `stage-root-change-3`, `stage-attempt-3`, `stage-root-change-4`, `stage-root-change-5`, `stage-root-change-6`, `stage-root-change-7`, `old-illuminate-consumer-1`, `old-illuminate-consumer-2`, `old-illuminate-consumer-3`, `old-illuminate-consumer-4`, `old-illuminate-consumer-5`, `old-illuminate-consumer-6`, `old-illuminate-consumer-7`, `old-illuminate-consumer-8`, `old-illuminate-consumer-9`, `old-illuminate-consumer-10`, `laravel-package-nunomaduro_collision-1`, `laravel-package-guidance-1`, `laravel-package-laravel_sanctum-1`, `laravel-package-guidance-2`, `laravel-package-phpunit_phpunit-1`, `laravel-package-guidance-3`, `laravel-advisory-doctrine_dbal-1`, `laravel-package-advisory-1`, `laravel-advisory-laravel_sanctum-1`, `laravel-package-advisory-2`, `lock-metadata-3`, `lock-metadata-5`, `lock-metadata-7`, `lock-metadata-4`, `lock-metadata-6`, `lock-metadata-8`, `solver-6`, `solver-7`, `solver-8`)
- Observed risk grade: `high`. No successful direct target resolution was observed; the risk grade is not a verified low-risk conclusion.
- Planning range: 6-32 hours (low confidence). Hours are an uncalibrated planning heuristic for reported dependency, source-change, and test/debugging work, not a project quote. Unobserved migration, deployment, runtime failures, and business validation work are excluded.
- First recorded limitation: Locked package "barryvdh/laravel-debugbar" files mapping was unavailable, so its symbols could not be indexed.
- First recorded check: Validate the edited Composer manifest before dependency installation.
- Application validation: Identify and run the project test suite; no Composer test script was detected.

## Analysis Request
- Project: `[PROJECT_ROOT]`
- Current PHP: `8.1.0`
- Target PHP: `8.3.0`
- Source paths: `default project paths`
- Framework integrations: `laravel`
- Target platform profile: `not supplied`
- Composer execution mode: `compatible`
- Requested format: `json`
- Output destination: `stdout`
- Targets:
  - `laravel/framework`: `^13.0`
  - `php`: `8.3.0`

## Platform Provenance
- Analyzer PHP: `8.3.33` (provenance: `runtime`)
- Current project PHP: `8.1.0` (provenance: `request`)
- Target PHP: `8.3.0` (provenance: `request`)
- Extensions: provenance `mixed`; explicitly modeled: yes; completeness: `partial`; unmodeled values: `analyzer_runtime`
  - `ext-bcmath`: `present` (provenance: `request`)
  - `ext-curl`: `present` (provenance: `request`)
  - `ext-exif`: `present` (provenance: `request`)
  - `ext-fileinfo`: `present` (provenance: `request`)
  - `ext-gd`: `present` (provenance: `request`)
  - `ext-imagick`: `present` (provenance: `request`)
  - `ext-mbstring`: `present` (provenance: `request`)
  - `ext-openssl`: `present` (provenance: `request`)
  - `ext-pdo`: `present` (provenance: `request`)
  - `ext-xml`: `present` (provenance: `request`)
  - `ext-zip`: `present` (provenance: `request`)
- Target platform profile: none; platform packages not explicitly modeled above remain analyzer-host dependent.

## Composer Execution Provenance
- Mode: `compatible`; Composer version: `2.10.2`; expected: `>=2.0.0 <3.0.0`; matches: `yes`
- Executable selection: `explicit`; environment: `inherited`; network: `inherited`; repositories: `project_and_global`
- Timeouts: scenario `45 s`; diagnostic `15 s`; Composer home: `inherited`
- Inheritance: global configuration yes; credentials may be inherited yes; offline requested no; process/OS isolation no
- Side effects: scripts disabled; plugins disabled; installation disabled; audit disabled; interaction disabled; progress disabled.

## Project State
- Analyzed path: `[PROJECT_ROOT]`
- Composer platform PHP: `not configured`
- Locked packages: `198`
- Root requirements:
  - `php`: `^8.1`
  - `ext-calendar`: `*`
  - `ext-curl`: `*`
  - `ext-intl`: `*`
  - `ext-mbstring`: `*`
  - `ext-openssl`: `*`
  - `ext-pdo`: `*`
  - `ext-pdo_mysql`: `*`
  - `ext-tokenizer`: `*`
  - `astrotomic/laravel-translatable`: `^11.0.0`
  - `barryvdh/laravel-dompdf`: `^2.0.0`
  - `diglactic/laravel-breadcrumbs`: `^8.0`
  - `doctrine/dbal`: `^3.0`
  - `elasticsearch/elasticsearch`: `^8.10`
  - `enshrined/svg-sanitize`: `^0.16.0`
  - `guzzlehttp/guzzle`: `^7.0.1`
  - `intervention/image`: `^2.4`
  - `intervention/imagecache`: `^2.5.2`
  - `kalnoy/nestedset`: `^6.0`
  - `khaled.alshamaa/ar-php`: `^6.0.0`
  - `konekt/concord`: `^1.2`
  - `laravel/framework`: `^10.0`
  - `laravel/octane`: `^2.0`
  - `laravel/sanctum`: `^3.2`
  - `laravel/socialite`: `^5.0`
  - `laravel/tinker`: `^2.0`
  - `laravel/ui`: `^4.0`
  - `maatwebsite/excel`: `^3.1.46`
  - `mpdf/mpdf`: `^8.2`
  - `openai-php/laravel`: `^0.7.8`
  - `paypal/paypal-checkout-sdk`: `1.0.1`
  - `predis/predis`: `^2.2`
  - `prettus/l5-repository`: `^2.6`
  - `pusher/pusher-php-server`: `^7.0`
  - `shetabit/visitor`: `^4.1`
  - `spatie/laravel-responsecache`: `^7.4`
  - `spatie/laravel-sitemap`: `^6.2`
  - `bagisto/laravel-datafaker`: `dev-master`
  - `barryvdh/laravel-debugbar`: `^3.8`
  - `fakerphp/faker`: `^1.9.1`
  - `laravel/pint`: `^1.8`
  - `mockery/mockery`: `^1.3.1`
  - `nunomaduro/collision`: `^7.0`
  - `pestphp/pest`: `^2.6`
  - `pestphp/pest-plugin-laravel`: `^2.1`
  - `phpunit/phpunit`: `^10.0`
  - `spatie/laravel-ignition`: `^2.0`

## Composer Scenarios
- `baseline-validation`: succeeded (outcome `success`, Composer `2.10.2`, duration `326 ms`, exit `0`, failure type `none`)
  - command argv: `["[COMPOSER_EXECUTABLE]","validate","--check-lock","--no-check-publish","--no-scripts","--no-plugins","--no-interaction"]`
  - temporary workspace: `not preserved`
  - stdout excerpt: *(empty)*
  - stderr excerpt:
    ```text
    ./composer.json is valid, but with a few warnings
    See [REDACTED_URL] for details on the schema
    # General warnings
    - require.paypal/paypal-checkout-sdk : exact version constraints (1.0.1) should be avoided if the package follows semantic versioning

    ```
  - candidate lock: SHA-256 `58c54c07bfae3dcde5d51fe5f2a1c327c18b3c4579e46731e6aaf89dbdd1ac7a`, content hash `39622e2e478c3641803ae55003acc4e6`, packages `198`
  - diagnostics: none
- `exact-target`: failed (outcome `solver_failure`, Composer `2.10.2`, duration `6689 ms`, exit `2`, failure type `solver`)
  - command argv: `["[COMPOSER_EXECUTABLE]","update","laravel/framework","--no-scripts","--no-plugins","--no-install","--no-audit","--no-progress","--no-interaction"]`
  - temporary workspace: `not preserved`
  - stdout excerpt: *(empty)*
  - stderr excerpt:
    ```text
    Loading composer repositories with package information
    Updating dependencies
    Your requirements could not be resolved to an installable set of packages.

      Problem 1
        - Root composer.json requires PHP extension ext-calendar * but it is missing from your system. Install or enable PHP's calendar extension.

          Alternatively you can require one of these packages that provide the extension (or parts of it):
          Keep in mind that the suggestions are automated and may not be valid or safe to use
          - fisharebest/ext-calendar Implementation of the Arabic (Hijri), French, Gregorian, Jewish, Julian and Persian (Jalali) calenda
          - condorcet-php/php-calendars Pure PHP implementation of the Arabic (Hijri), French, Gregorian, Jewish, Julian and Persian (Jalali

      Problem 2
        - Root composer.json requires PHP extension ext-intl * but it is missing from your system. Install or enable PHP's intl extension.

          Alternatively you can require one of these packages that provide the extension (or parts of it):
          Keep in mind that the suggestions are automated and may not be valid or safe to use
          - phuture/continuum A forward-compatibility layer bringing tomorrow’s PHP features to today’s runtimes.

      Problem 3
        - Root composer.json requires PHP extension ext-pdo_mysql * but it is missing from your system. Install or enable PHP's pdo_mysql extension.
      Problem 4
        - Root composer.json requires laravel/framework ^13.0, found laravel/framework[v13.0.0, ..., v13.37.0] but these were not loaded, because they are affected by security advisories ("PKSA-d5tc-s1qs-h781", "PKSA-m5cs-t1y6-qpcs", "PKSA-3r5d-mb8f-1qw9", "PKSA-mdq4-51ck-6kdq"). Go to [REDACTED_URL] to find advisory details. To ignore the advisories, add their IDs to the "policy.advisories.ignore-id" config or add the package to "policy.advisories.ignore". To turn the feature off entirely, you can set "policy.advisories.block" to false.
      Problem 5
        - diglactic/laravel-breadcrumbs is locked to version v8.1.1 and an update of this package was not requested.
        - diglactic/laravel-breadcrumbs v8.1.1 requires laravel/framework ^6.0 || ^7.0 || ^8.0 || ^9.0 || ^10.0 -> found laravel/framework[v6.0.0, ..., v6.20.45, v7.0.0, ..., v7.30.7, v8.0.0, ..., v8.83.29, v9.0.0, ..., v9.52.22, v10.0.0, ..., v10.50.3] but it conflicts with your root composer.json require (^13.0).
      Problem 6
        - khaled.alshamaa/ar-php is locked to version v6.3.4 and an update of this package was not requested.
        - khaled.alshamaa/ar-php v6.3.4 requires ext-calendar * -> it is missing from your system. Install or enable PHP's calendar extension.

          Alternatively you can require one of these packages that provide the extension (or parts of it):
          Keep in mind that the suggestions are automated and may not be valid or safe to use
          - fisharebest/ext-calendar Implementation of the Arabic (Hijri), French, Gregorian, Jewish, Julian and Persian (Jalali) calenda
          - condorcet-php/php-calendars Pure PHP implementation of the Arabic (Hijri), French, Gregorian, Jewish, Julian and Persian (Jalali

      Problem 7
        - laravel/octane is locked to version v2.3.0 and an update of this package was not requested.
        - laravel/octane v2.3.0 requires laravel/framework ^10.10.1|^11.0 -> found laravel/framework[v10.10.1, ..., v10.50.3, v11.0.0, ..., v11.57.0] but it conflicts with your root composer.json require (^13.0).
      Problem 8
        - openai-php/laravel is locked to version v0.7.8 and an update of this package was not requested.
        - openai-php/laravel v0.7.8 requires laravel/framework ^9.46.0|^10.14.1 -> found laravel/framework[v9.46.0, ..., v9.52.22, v10.14.1, ..., v10.50.3] but it conflicts with your root composer.json require (^13.0).
      Problem 9
        - pestphp/pest-plugin-laravel is locked to version v2.2.0 and an update of this package was not requested.
        - pestphp/pest-plugin-laravel v2.2.0 requires laravel/framework ^10.18.0|^11.0 -> f
    [TRUNCATED: 4762 bytes of output omitted]
    ```
  - candidate lock: not available
  - diagnostic for `laravel/framework ^13.0` (outcome `success`, exit `1`), command argv: `["[COMPOSER_EXECUTABLE]","prohibits","laravel/framework","^13.0","--tree","--locked","--no-scripts","--no-plugins","--no-interaction"]`
    - stdout excerpt:
      ```text
      laravel/framework v10.41.0 The Laravel Framework.
      |--astrotomic/laravel-translatable v11.12.1 (requires illuminate/contracts ^8.0 || ^9.0 || ^10.0)
      |  `--bagisto/bagisto (requires astrotomic/laravel-translatable ^11.0.0)
      |--astrotomic/laravel-translatable v11.12.1 (requires illuminate/database ^8.0 || ^9.0 || ^10.0) (circular dependency aborted here)
      |--astrotomic/laravel-translatable v11.12.1 (requires illuminate/support ^8.0 || ^9.0 || ^10.0) (circular dependency aborted here)
      |--barryvdh/laravel-dompdf v2.0.1 (requires illuminate/support ^6|^7|^8|^9|^10)
      |  `--bagisto/bagisto (requires barryvdh/laravel-dompdf ^2.0.0)
      |--diglactic/laravel-breadcrumbs v8.1.1 (requires laravel/framework ^6.0 || ^7.0 || ^8.0 || ^9.0 || ^10.0)
      |  `--bagisto/bagisto (requires diglactic/laravel-breadcrumbs ^8.0)
      |--intervention/imagecache 2.6.0 (requires illuminate/cache ^5.5|~6|~7|~8|~9|~10)
      |  `--bagisto/bagisto (requires intervention/imagecache ^2.5.2)
      |--intervention/imagecache 2.6.0 (requires illuminate/filesystem ^5.5|~6|~7|~8|~9|~10) (circular dependency aborted here)
      |--kalnoy/nestedset v6.0.3 (requires illuminate/database ^7.0|^8.0|^9.0|^10.0)
      |  `--bagisto/bagisto (requires kalnoy/nestedset ^6.0)
      |--kalnoy/nestedset v6.0.3 (requires illuminate/events ^7.0|^8.0|^9.0|^10.0) (circular dependency aborted here)
      |--kalnoy/nestedset v6.0.3 (requires illuminate/support ^7.0|^8.0|^9.0|^10.0) (circular dependency aborted here)
      |--konekt/concord 1.14.0 (requires illuminate/console ^9.2|^10.0|^11.0)
      |  `--bagisto/bagisto (requires konekt/concord ^1.2)
      |--konekt/concord 1.14.0 (requires illuminate/support ^9.2|^10.0|^11.0) (circular dependency aborted here)
      |--konekt/enum-eloquent 1.9.3 (requires illuminate/database ^8.75|9.*|10.*|11.*)
      |  `--konekt/concord 1.14.0 (requires konekt/enum-eloquent ^1.7)
      |     `--bagisto/bagisto (requires konekt/concord ^1.2)
      |--laravel/octane v2.3.0 (requires laravel/framework ^10.10.1|^11.0)
      |  `--bagisto/bagisto (requires laravel/octane ^2.0)
      |--laravel/prompts v0.1.15 (requires illuminate/collections ^10.0|^11.0)
      |  |--laravel/framework v10.41.0 (requires laravel/prompts ^0.1.9) (circular dependency aborted here)
      |  `--laravel/framework v13.37.0 (requires laravel/prompts ^0.3.25) (circular dependency aborted here)
      |--laravel/sanctum v3.3.3 (requires illuminate/console ^9.21|^10.0)
      |  `--bagisto/bagisto (requires laravel/sanctum ^3.2)
      |--laravel/sanctum v3.3.3 (requires illuminate/contracts ^9.21|^10.0) (circular dependency aborted here)
      |--laravel/sanctum v3.3.3 (requires illuminate/database ^9.21|^10.0) (circular dependency aborted here)
      |--laravel/sanctum v3.3.3 (requires illuminate/support ^9.21|^10.0) (circular dependency aborted here)
      |--laravel/socialite v5.11.0 (requires illuminate/contracts ^6.0|^7.0|^8.0|^9.0|^10.0|^11.0)
      |  `--bagisto/bagisto (requires laravel/socialite ^5.0)
      |--laravel/socialite v5.11.0 (requires illuminate/http ^6.0|^7.0|^8.0|^9.0|^10.0|^11.0) (circular dependency aborted here)
      |--laravel/socialite v5.11.0 (requires illuminate/support ^6.0|^7.0|^8.0|^9.0|^10.0|^11.0) (circular dependency aborted here)
      |--laravel/tinker v2.9.0 (requires illuminate/console ^6.0|^7.0|^8.0|^9.0|^10.0|^11.0)
      |  `--bagisto/bagisto (requires laravel/tinker ^2.0)
      |--laravel/tinker v2.9.0 (requires illuminate/contracts ^6.0|^7.0|^8.0|^9.0|^10.0|^11.0) (circular dependency aborted here)
      |--laravel/tinker v2.9.0 (requires illuminate/support ^6.0|^7.0|^8.0|^9.0|^10.0|^11.0) (circular dependency aborted here)
      |--laravel/ui v4.4.0 (requires illuminate/console ^9.21|^10.0|^11.0)
      |  `--bagisto/bagisto (requires laravel/ui ^4.0)
      |--laravel/ui v4.4.0 (requires illuminate/filesystem ^9.21|^10.0|^11.0) (circular dependency aborted here)
      |--laravel/ui v4.4.0 (requires illuminate/support ^9.21|^10.0|^11.0) (circular dependency aborted here)
      |--laravel/ui v4.4.0 (requires illuminate/validation ^9.21|^10.0|^11.0) (circular dependency aborted here)
      |--maatwebsite/excel 3.1.52 (requires i
      [TRUNCATED: 14235 bytes of output omitted]
      ```
    - stderr excerpt:
      ```text
      Not finding what you were looking for? Try calling `composer require "laravel/framework:^13.0" --dry-run` to get another view on the problem.

      ```
  - diagnostic for `php 8.3.0` (outcome `success`, exit `0`), command argv: `["[COMPOSER_EXECUTABLE]","prohibits","php","8.3.0","--tree","--locked","--no-scripts","--no-plugins","--no-interaction"]`
    - stdout excerpt: *(empty)*
    - stderr excerpt:
      ```text
      There is no installed package depending on "php" in versions not matching 8.3.0

      ```
- `target-with-all-dependencies`: failed (outcome `solver_failure`, Composer `2.10.2`, duration `6170 ms`, exit `2`, failure type `solver`)
  - command argv: `["[COMPOSER_EXECUTABLE]","update","laravel/framework","--with-all-dependencies","--no-scripts","--no-plugins","--no-install","--no-audit","--no-progress","--no-interaction"]`
  - temporary workspace: `not preserved`
  - stdout excerpt: *(empty)*
  - stderr excerpt:
    ```text
    Loading composer repositories with package information
    Updating dependencies
    Your requirements could not be resolved to an installable set of packages.

      Problem 1
        - Root composer.json requires PHP extension ext-calendar * but it is missing from your system. Install or enable PHP's calendar extension.

          Alternatively you can require one of these packages that provide the extension (or parts of it):
          Keep in mind that the suggestions are automated and may not be valid or safe to use
          - fisharebest/ext-calendar Implementation of the Arabic (Hijri), French, Gregorian, Jewish, Julian and Persian (Jalali) calenda
          - condorcet-php/php-calendars Pure PHP implementation of the Arabic (Hijri), French, Gregorian, Jewish, Julian and Persian (Jalali

      Problem 2
        - Root composer.json requires PHP extension ext-intl * but it is missing from your system. Install or enable PHP's intl extension.

          Alternatively you can require one of these packages that provide the extension (or parts of it):
          Keep in mind that the suggestions are automated and may not be valid or safe to use
          - phuture/continuum A forward-compatibility layer bringing tomorrow’s PHP features to today’s runtimes.

      Problem 3
        - Root composer.json requires PHP extension ext-pdo_mysql * but it is missing from your system. Install or enable PHP's pdo_mysql extension.
      Problem 4
        - Root composer.json requires laravel/framework ^13.0, found laravel/framework[v13.0.0, ..., v13.37.0] but these were not loaded, because they are affected by security advisories ("PKSA-d5tc-s1qs-h781", "PKSA-m5cs-t1y6-qpcs", "PKSA-3r5d-mb8f-1qw9", "PKSA-mdq4-51ck-6kdq"). Go to [REDACTED_URL] to find advisory details. To ignore the advisories, add their IDs to the "policy.advisories.ignore-id" config or add the package to "policy.advisories.ignore". To turn the feature off entirely, you can set "policy.advisories.block" to false.
      Problem 5
        - diglactic/laravel-breadcrumbs is locked to version v8.1.1 and an update of this package was not requested.
        - diglactic/laravel-breadcrumbs v8.1.1 requires laravel/framework ^6.0 || ^7.0 || ^8.0 || ^9.0 || ^10.0 -> found laravel/framework[v6.0.0, ..., v6.20.45, v7.0.0, ..., v7.30.7, v8.0.0, ..., v8.83.29, v9.0.0, ..., v9.52.22, v10.0.0, ..., v10.50.3] but it conflicts with your root composer.json require (^13.0).
      Problem 6
        - khaled.alshamaa/ar-php is locked to version v6.3.4 and an update of this package was not requested.
        - khaled.alshamaa/ar-php v6.3.4 requires ext-calendar * -> it is missing from your system. Install or enable PHP's calendar extension.

          Alternatively you can require one of these packages that provide the extension (or parts of it):
          Keep in mind that the suggestions are automated and may not be valid or safe to use
          - fisharebest/ext-calendar Implementation of the Arabic (Hijri), French, Gregorian, Jewish, Julian and Persian (Jalali) calenda
          - condorcet-php/php-calendars Pure PHP implementation of the Arabic (Hijri), French, Gregorian, Jewish, Julian and Persian (Jalali

      Problem 7
        - laravel/octane is locked to version v2.3.0 and an update of this package was not requested.
        - laravel/octane v2.3.0 requires laravel/framework ^10.10.1|^11.0 -> found laravel/framework[v10.10.1, ..., v10.50.3, v11.0.0, ..., v11.57.0] but it conflicts with your root composer.json require (^13.0).
      Problem 8
        - openai-php/laravel is locked to version v0.7.8 and an update of this package was not requested.
        - openai-php/laravel v0.7.8 requires laravel/framework ^9.46.0|^10.14.1 -> found laravel/framework[v9.46.0, ..., v9.52.22, v10.14.1, ..., v10.50.3] but it conflicts with your root composer.json require (^13.0).
      Problem 9
        - pestphp/pest-plugin-laravel is locked to version v2.2.0 and an update of this package was not requested.
        - pestphp/pest-plugin-laravel v2.2.0 requires laravel/framework ^10.18.0|^11.0 -> f
    [TRUNCATED: 4622 bytes of output omitted]
    ```
  - candidate lock: not available
  - diagnostic for `laravel/framework ^13.0` (outcome `success`, exit `1`), command argv: `["[COMPOSER_EXECUTABLE]","prohibits","laravel/framework","^13.0","--tree","--locked","--no-scripts","--no-plugins","--no-interaction"]`
    - stdout excerpt:
      ```text
      laravel/framework v10.41.0 The Laravel Framework.
      |--astrotomic/laravel-translatable v11.12.1 (requires illuminate/contracts ^8.0 || ^9.0 || ^10.0)
      |  `--bagisto/bagisto (requires astrotomic/laravel-translatable ^11.0.0)
      |--astrotomic/laravel-translatable v11.12.1 (requires illuminate/database ^8.0 || ^9.0 || ^10.0) (circular dependency aborted here)
      |--astrotomic/laravel-translatable v11.12.1 (requires illuminate/support ^8.0 || ^9.0 || ^10.0) (circular dependency aborted here)
      |--barryvdh/laravel-dompdf v2.0.1 (requires illuminate/support ^6|^7|^8|^9|^10)
      |  `--bagisto/bagisto (requires barryvdh/laravel-dompdf ^2.0.0)
      |--diglactic/laravel-breadcrumbs v8.1.1 (requires laravel/framework ^6.0 || ^7.0 || ^8.0 || ^9.0 || ^10.0)
      |  `--bagisto/bagisto (requires diglactic/laravel-breadcrumbs ^8.0)
      |--intervention/imagecache 2.6.0 (requires illuminate/cache ^5.5|~6|~7|~8|~9|~10)
      |  `--bagisto/bagisto (requires intervention/imagecache ^2.5.2)
      |--intervention/imagecache 2.6.0 (requires illuminate/filesystem ^5.5|~6|~7|~8|~9|~10) (circular dependency aborted here)
      |--kalnoy/nestedset v6.0.3 (requires illuminate/database ^7.0|^8.0|^9.0|^10.0)
      |  `--bagisto/bagisto (requires kalnoy/nestedset ^6.0)
      |--kalnoy/nestedset v6.0.3 (requires illuminate/events ^7.0|^8.0|^9.0|^10.0) (circular dependency aborted here)
      |--kalnoy/nestedset v6.0.3 (requires illuminate/support ^7.0|^8.0|^9.0|^10.0) (circular dependency aborted here)
      |--konekt/concord 1.14.0 (requires illuminate/console ^9.2|^10.0|^11.0)
      |  `--bagisto/bagisto (requires konekt/concord ^1.2)
      |--konekt/concord 1.14.0 (requires illuminate/support ^9.2|^10.0|^11.0) (circular dependency aborted here)
      |--konekt/enum-eloquent 1.9.3 (requires illuminate/database ^8.75|9.*|10.*|11.*)
      |  `--konekt/concord 1.14.0 (requires konekt/enum-eloquent ^1.7)
      |     `--bagisto/bagisto (requires konekt/concord ^1.2)
      |--laravel/octane v2.3.0 (requires laravel/framework ^10.10.1|^11.0)
      |  `--bagisto/bagisto (requires laravel/octane ^2.0)
      |--laravel/prompts v0.1.15 (requires illuminate/collections ^10.0|^11.0)
      |  |--laravel/framework v10.41.0 (requires laravel/prompts ^0.1.9) (circular dependency aborted here)
      |  `--laravel/framework v13.37.0 (requires laravel/prompts ^0.3.25) (circular dependency aborted here)
      |--laravel/sanctum v3.3.3 (requires illuminate/console ^9.21|^10.0)
      |  `--bagisto/bagisto (requires laravel/sanctum ^3.2)
      |--laravel/sanctum v3.3.3 (requires illuminate/contracts ^9.21|^10.0) (circular dependency aborted here)
      |--laravel/sanctum v3.3.3 (requires illuminate/database ^9.21|^10.0) (circular dependency aborted here)
      |--laravel/sanctum v3.3.3 (requires illuminate/support ^9.21|^10.0) (circular dependency aborted here)
      |--laravel/socialite v5.11.0 (requires illuminate/contracts ^6.0|^7.0|^8.0|^9.0|^10.0|^11.0)
      |  `--bagisto/bagisto (requires laravel/socialite ^5.0)
      |--laravel/socialite v5.11.0 (requires illuminate/http ^6.0|^7.0|^8.0|^9.0|^10.0|^11.0) (circular dependency aborted here)
      |--laravel/socialite v5.11.0 (requires illuminate/support ^6.0|^7.0|^8.0|^9.0|^10.0|^11.0) (circular dependency aborted here)
      |--laravel/tinker v2.9.0 (requires illuminate/console ^6.0|^7.0|^8.0|^9.0|^10.0|^11.0)
      |  `--bagisto/bagisto (requires laravel/tinker ^2.0)
      |--laravel/tinker v2.9.0 (requires illuminate/contracts ^6.0|^7.0|^8.0|^9.0|^10.0|^11.0) (circular dependency aborted here)
      |--laravel/tinker v2.9.0 (requires illuminate/support ^6.0|^7.0|^8.0|^9.0|^10.0|^11.0) (circular dependency aborted here)
      |--laravel/ui v4.4.0 (requires illuminate/console ^9.21|^10.0|^11.0)
      |  `--bagisto/bagisto (requires laravel/ui ^4.0)
      |--laravel/ui v4.4.0 (requires illuminate/filesystem ^9.21|^10.0|^11.0) (circular dependency aborted here)
      |--laravel/ui v4.4.0 (requires illuminate/support ^9.21|^10.0|^11.0) (circular dependency aborted here)
      |--laravel/ui v4.4.0 (requires illuminate/validation ^9.21|^10.0|^11.0) (circular dependency aborted here)
      |--maatwebsite/excel 3.1.52 (requires i
      [TRUNCATED: 14235 bytes of output omitted]
      ```
    - stderr excerpt:
      ```text
      Not finding what you were looking for? Try calling `composer require "laravel/framework:^13.0" --dry-run` to get another view on the problem.

      ```
  - diagnostic for `php 8.3.0` (outcome `success`, exit `0`), command argv: `["[COMPOSER_EXECUTABLE]","prohibits","php","8.3.0","--tree","--locked","--no-scripts","--no-plugins","--no-interaction"]`
    - stdout excerpt: *(empty)*
    - stderr excerpt:
      ```text
      There is no installed package depending on "php" in versions not matching 8.3.0

      ```
- `minimal-changes`: failed (outcome `solver_failure`, Composer `2.10.2`, duration `6645 ms`, exit `2`, failure type `solver`)
  - command argv: `["[COMPOSER_EXECUTABLE]","update","laravel/framework","--with-all-dependencies","--minimal-changes","--no-scripts","--no-plugins","--no-install","--no-audit","--no-progress","--no-interaction"]`
  - temporary workspace: `not preserved`
  - stdout excerpt: *(empty)*
  - stderr excerpt:
    ```text
    Loading composer repositories with package information
    Updating dependencies
    Your requirements could not be resolved to an installable set of packages.

      Problem 1
        - Root composer.json requires PHP extension ext-calendar * but it is missing from your system. Install or enable PHP's calendar extension.

          Alternatively you can require one of these packages that provide the extension (or parts of it):
          Keep in mind that the suggestions are automated and may not be valid or safe to use
          - fisharebest/ext-calendar Implementation of the Arabic (Hijri), French, Gregorian, Jewish, Julian and Persian (Jalali) calenda
          - condorcet-php/php-calendars Pure PHP implementation of the Arabic (Hijri), French, Gregorian, Jewish, Julian and Persian (Jalali

      Problem 2
        - Root composer.json requires PHP extension ext-intl * but it is missing from your system. Install or enable PHP's intl extension.

          Alternatively you can require one of these packages that provide the extension (or parts of it):
          Keep in mind that the suggestions are automated and may not be valid or safe to use
          - phuture/continuum A forward-compatibility layer bringing tomorrow’s PHP features to today’s runtimes.

      Problem 3
        - Root composer.json requires PHP extension ext-pdo_mysql * but it is missing from your system. Install or enable PHP's pdo_mysql extension.
      Problem 4
        - Root composer.json requires laravel/framework ^13.0, found laravel/framework[v13.0.0, ..., v13.37.0] but these were not loaded, because they are affected by security advisories ("PKSA-d5tc-s1qs-h781", "PKSA-m5cs-t1y6-qpcs", "PKSA-3r5d-mb8f-1qw9", "PKSA-mdq4-51ck-6kdq"). Go to [REDACTED_URL] to find advisory details. To ignore the advisories, add their IDs to the "policy.advisories.ignore-id" config or add the package to "policy.advisories.ignore". To turn the feature off entirely, you can set "policy.advisories.block" to false.
      Problem 5
        - diglactic/laravel-breadcrumbs is locked to version v8.1.1 and an update of this package was not requested.
        - diglactic/laravel-breadcrumbs v8.1.1 requires laravel/framework ^6.0 || ^7.0 || ^8.0 || ^9.0 || ^10.0 -> found laravel/framework[v6.0.0, ..., v6.20.45, v7.0.0, ..., v7.30.7, v8.0.0, ..., v8.83.29, v9.0.0, ..., v9.52.22, v10.0.0, ..., v10.50.3] but it conflicts with your root composer.json require (^13.0).
      Problem 6
        - khaled.alshamaa/ar-php is locked to version v6.3.4 and an update of this package was not requested.
        - khaled.alshamaa/ar-php v6.3.4 requires ext-calendar * -> it is missing from your system. Install or enable PHP's calendar extension.

          Alternatively you can require one of these packages that provide the extension (or parts of it):
          Keep in mind that the suggestions are automated and may not be valid or safe to use
          - fisharebest/ext-calendar Implementation of the Arabic (Hijri), French, Gregorian, Jewish, Julian and Persian (Jalali) calenda
          - condorcet-php/php-calendars Pure PHP implementation of the Arabic (Hijri), French, Gregorian, Jewish, Julian and Persian (Jalali

      Problem 7
        - laravel/octane is locked to version v2.3.0 and an update of this package was not requested.
        - laravel/octane v2.3.0 requires laravel/framework ^10.10.1|^11.0 -> found laravel/framework[v10.10.1, ..., v10.50.3, v11.0.0, ..., v11.57.0] but it conflicts with your root composer.json require (^13.0).
      Problem 8
        - openai-php/laravel is locked to version v0.7.8 and an update of this package was not requested.
        - openai-php/laravel v0.7.8 requires laravel/framework ^9.46.0|^10.14.1 -> found laravel/framework[v9.46.0, ..., v9.52.22, v10.14.1, ..., v10.50.3] but it conflicts with your root composer.json require (^13.0).
      Problem 9
        - pestphp/pest-plugin-laravel is locked to version v2.2.0 and an update of this package was not requested.
        - pestphp/pest-plugin-laravel v2.2.0 requires laravel/framework ^10.18.0|^11.0 -> f
    [TRUNCATED: 4622 bytes of output omitted]
    ```
  - candidate lock: not available
  - diagnostic for `laravel/framework ^13.0` (outcome `success`, exit `1`), command argv: `["[COMPOSER_EXECUTABLE]","prohibits","laravel/framework","^13.0","--tree","--locked","--no-scripts","--no-plugins","--no-interaction"]`
    - stdout excerpt:
      ```text
      laravel/framework v10.41.0 The Laravel Framework.
      |--astrotomic/laravel-translatable v11.12.1 (requires illuminate/contracts ^8.0 || ^9.0 || ^10.0)
      |  `--bagisto/bagisto (requires astrotomic/laravel-translatable ^11.0.0)
      |--astrotomic/laravel-translatable v11.12.1 (requires illuminate/database ^8.0 || ^9.0 || ^10.0) (circular dependency aborted here)
      |--astrotomic/laravel-translatable v11.12.1 (requires illuminate/support ^8.0 || ^9.0 || ^10.0) (circular dependency aborted here)
      |--barryvdh/laravel-dompdf v2.0.1 (requires illuminate/support ^6|^7|^8|^9|^10)
      |  `--bagisto/bagisto (requires barryvdh/laravel-dompdf ^2.0.0)
      |--diglactic/laravel-breadcrumbs v8.1.1 (requires laravel/framework ^6.0 || ^7.0 || ^8.0 || ^9.0 || ^10.0)
      |  `--bagisto/bagisto (requires diglactic/laravel-breadcrumbs ^8.0)
      |--intervention/imagecache 2.6.0 (requires illuminate/cache ^5.5|~6|~7|~8|~9|~10)
      |  `--bagisto/bagisto (requires intervention/imagecache ^2.5.2)
      |--intervention/imagecache 2.6.0 (requires illuminate/filesystem ^5.5|~6|~7|~8|~9|~10) (circular dependency aborted here)
      |--kalnoy/nestedset v6.0.3 (requires illuminate/database ^7.0|^8.0|^9.0|^10.0)
      |  `--bagisto/bagisto (requires kalnoy/nestedset ^6.0)
      |--kalnoy/nestedset v6.0.3 (requires illuminate/events ^7.0|^8.0|^9.0|^10.0) (circular dependency aborted here)
      |--kalnoy/nestedset v6.0.3 (requires illuminate/support ^7.0|^8.0|^9.0|^10.0) (circular dependency aborted here)
      |--konekt/concord 1.14.0 (requires illuminate/console ^9.2|^10.0|^11.0)
      |  `--bagisto/bagisto (requires konekt/concord ^1.2)
      |--konekt/concord 1.14.0 (requires illuminate/support ^9.2|^10.0|^11.0) (circular dependency aborted here)
      |--konekt/enum-eloquent 1.9.3 (requires illuminate/database ^8.75|9.*|10.*|11.*)
      |  `--konekt/concord 1.14.0 (requires konekt/enum-eloquent ^1.7)
      |     `--bagisto/bagisto (requires konekt/concord ^1.2)
      |--laravel/octane v2.3.0 (requires laravel/framework ^10.10.1|^11.0)
      |  `--bagisto/bagisto (requires laravel/octane ^2.0)
      |--laravel/prompts v0.1.15 (requires illuminate/collections ^10.0|^11.0)
      |  |--laravel/framework v10.41.0 (requires laravel/prompts ^0.1.9) (circular dependency aborted here)
      |  `--laravel/framework v13.37.0 (requires laravel/prompts ^0.3.25) (circular dependency aborted here)
      |--laravel/sanctum v3.3.3 (requires illuminate/console ^9.21|^10.0)
      |  `--bagisto/bagisto (requires laravel/sanctum ^3.2)
      |--laravel/sanctum v3.3.3 (requires illuminate/contracts ^9.21|^10.0) (circular dependency aborted here)
      |--laravel/sanctum v3.3.3 (requires illuminate/database ^9.21|^10.0) (circular dependency aborted here)
      |--laravel/sanctum v3.3.3 (requires illuminate/support ^9.21|^10.0) (circular dependency aborted here)
      |--laravel/socialite v5.11.0 (requires illuminate/contracts ^6.0|^7.0|^8.0|^9.0|^10.0|^11.0)
      |  `--bagisto/bagisto (requires laravel/socialite ^5.0)
      |--laravel/socialite v5.11.0 (requires illuminate/http ^6.0|^7.0|^8.0|^9.0|^10.0|^11.0) (circular dependency aborted here)
      |--laravel/socialite v5.11.0 (requires illuminate/support ^6.0|^7.0|^8.0|^9.0|^10.0|^11.0) (circular dependency aborted here)
      |--laravel/tinker v2.9.0 (requires illuminate/console ^6.0|^7.0|^8.0|^9.0|^10.0|^11.0)
      |  `--bagisto/bagisto (requires laravel/tinker ^2.0)
      |--laravel/tinker v2.9.0 (requires illuminate/contracts ^6.0|^7.0|^8.0|^9.0|^10.0|^11.0) (circular dependency aborted here)
      |--laravel/tinker v2.9.0 (requires illuminate/support ^6.0|^7.0|^8.0|^9.0|^10.0|^11.0) (circular dependency aborted here)
      |--laravel/ui v4.4.0 (requires illuminate/console ^9.21|^10.0|^11.0)
      |  `--bagisto/bagisto (requires laravel/ui ^4.0)
      |--laravel/ui v4.4.0 (requires illuminate/filesystem ^9.21|^10.0|^11.0) (circular dependency aborted here)
      |--laravel/ui v4.4.0 (requires illuminate/support ^9.21|^10.0|^11.0) (circular dependency aborted here)
      |--laravel/ui v4.4.0 (requires illuminate/validation ^9.21|^10.0|^11.0) (circular dependency aborted here)
      |--maatwebsite/excel 3.1.52 (requires i
      [TRUNCATED: 14235 bytes of output omitted]
      ```
    - stderr excerpt:
      ```text
      Not finding what you were looking for? Try calling `composer require "laravel/framework:^13.0" --dry-run` to get another view on the problem.

      ```
  - diagnostic for `php 8.3.0` (outcome `success`, exit `0`), command argv: `["[COMPOSER_EXECUTABLE]","prohibits","php","8.3.0","--tree","--locked","--no-scripts","--no-plugins","--no-interaction"]`
    - stdout excerpt: *(empty)*
    - stderr excerpt:
      ```text
      There is no installed package depending on "php" in versions not matching 8.3.0

      ```
- `target-platform-only`: failed (outcome `solver_failure`, Composer `2.10.2`, duration `10528 ms`, exit `2`, failure type `solver`)
  - command argv: `["[COMPOSER_EXECUTABLE]","update","--no-scripts","--no-plugins","--no-install","--no-audit","--no-progress","--no-interaction"]`
  - temporary workspace: `not preserved`
  - stdout excerpt: *(empty)*
  - stderr excerpt:
    ```text
    Loading composer repositories with package information
    Updating dependencies
    Your requirements could not be resolved to an installable set of packages.

      Problem 1
        - Root composer.json requires PHP extension ext-calendar * but it is missing from your system. Install or enable PHP's calendar extension.

          Alternatively you can require one of these packages that provide the extension (or parts of it):
          Keep in mind that the suggestions are automated and may not be valid or safe to use
          - fisharebest/ext-calendar Implementation of the Arabic (Hijri), French, Gregorian, Jewish, Julian and Persian (Jalali) calenda
          - condorcet-php/php-calendars Pure PHP implementation of the Arabic (Hijri), French, Gregorian, Jewish, Julian and Persian (Jalali

      Problem 2
        - Root composer.json requires PHP extension ext-intl * but it is missing from your system. Install or enable PHP's intl extension.

          Alternatively you can require one of these packages that provide the extension (or parts of it):
          Keep in mind that the suggestions are automated and may not be valid or safe to use
          - phuture/continuum A forward-compatibility layer bringing tomorrow’s PHP features to today’s runtimes.

      Problem 3
        - Root composer.json requires PHP extension ext-pdo_mysql * but it is missing from your system. Install or enable PHP's pdo_mysql extension.
      Problem 4
        - Root composer.json requires enshrined/svg-sanitize ^0.16.0, found enshrined/svg-sanitize[0.16.0] but these were not loaded, because they are affected by security advisories ("PKSA-8j6w-3kr7-s9xk", "PKSA-6j95-1jtb-x6wc", "PKSA-cbx2-m9db-bmzd", "PKSA-4g5g-4rkv-myqs"). Go to [REDACTED_URL] to find advisory details. To ignore the advisories, add their IDs to the "policy.advisories.ignore-id" config or add the package to "policy.advisories.ignore". To turn the feature off entirely, you can set "policy.advisories.block" to false.
      Problem 5
        - Root composer.json requires laravel/framework ^10.0, found laravel/framework[v10.0.0, ..., v10.50.3] but these were not loaded, because they are affected by security advisories ("PKSA-d5tc-s1qs-h781", "PKSA-m5cs-t1y6-qpcs", "PKSA-3r5d-mb8f-1qw9", "PKSA-mdq4-51ck-6kdq", "PKSA-8qx3-n5y5-vvnd", "PKSA-w7xr-vk7n-rstm"). Go to [REDACTED_URL] to find advisory details. To ignore the advisories, add their IDs to the "policy.advisories.ignore-id" config or add the package to "policy.advisories.ignore". To turn the feature off entirely, you can set "policy.advisories.block" to false.
      Problem 6
        - Root composer.json requires openai-php/laravel ^0.7.8 -> satisfiable by openai-php/laravel[v0.7.8].
        - openai-php/laravel v0.7.8 requires laravel/framework ^9.46.0|^10.14.1 -> found laravel/framework[v9.46.0, ..., v9.52.22, v10.14.1, ..., v10.50.3] but these were not loaded, because they are affected by security advisories ("PKSA-d5tc-s1qs-h781", "PKSA-m5cs-t1y6-qpcs", "PKSA-3r5d-mb8f-1qw9", "PKSA-mdq4-51ck-6kdq", "PKSA-8qx3-n5y5-vvnd", "PKSA-w7xr-vk7n-rstm"). Go to [REDACTED_URL] to find advisory details. To ignore the advisories, add their IDs to the "policy.advisories.ignore-id" config or add the package to "policy.advisories.ignore". To turn the feature off entirely, you can set "policy.advisories.block" to false.
      Problem 7
        - Root composer.json requires barryvdh/laravel-dompdf ^2.0.0 -> satisfiable by barryvdh/laravel-dompdf[v2.0.0, ..., v2.2.0].
        - barryvdh/laravel-dompdf v2.0.0 requires dompdf/dompdf ^2 -> found dompdf/dompdf[v2.0.0, ..., v2.0.8] but these were not loaded, because they are affected by security advisories ("PKSA-cv56-2228-pzr6", "PKSA-6r8f-nxsb-67bq", "PKSA-gh7h-hhy4-byg7", "PKSA-mwt3-h9tv-kx78", "PKSA-hp6n-n4kz-21wk", "PKSA-mckv-s5hg-868k", "PKSA-7ztm-rpt3-qqzk", "PKSA-2kw5-jd8w-5mvh", "PKSA-4jrs-y99s-q8j6", "PKSA-hbk6-2vfz-8f8n"). Go to [REDACTED_URL] to find advisory details. To ignore the advisories, add their IDs to the "policy.advisories.ignore-
    [TRUNCATED: 6640 bytes of output omitted]
    ```
  - candidate lock: not available
  - diagnostic for `php 8.3.0` (outcome `success`, exit `0`), command argv: `["[COMPOSER_EXECUTABLE]","prohibits","php","8.3.0","--tree","--locked","--no-scripts","--no-plugins","--no-interaction"]`
    - stdout excerpt: *(empty)*
    - stderr excerpt:
      ```text
      There is no installed package depending on "php" in versions not matching 8.3.0

      ```
- `staged-targets`: failed (outcome `solver_failure`, Composer `2.10.2`, duration `6529 ms`, exit `2`, failure type `solver`)
  - command argv: `["[COMPOSER_EXECUTABLE]","update","laravel/framework","--with-all-dependencies","--no-scripts","--no-plugins","--no-install","--no-audit","--no-progress","--no-interaction"]`
  - temporary workspace: `not preserved`
  - stdout excerpt: *(empty)*
  - stderr excerpt:
    ```text
    Loading composer repositories with package information
    Updating dependencies
    Your requirements could not be resolved to an installable set of packages.

      Problem 1
        - Root composer.json requires PHP extension ext-calendar * but it is missing from your system. Install or enable PHP's calendar extension.

          Alternatively you can require one of these packages that provide the extension (or parts of it):
          Keep in mind that the suggestions are automated and may not be valid or safe to use
          - fisharebest/ext-calendar Implementation of the Arabic (Hijri), French, Gregorian, Jewish, Julian and Persian (Jalali) calenda
          - condorcet-php/php-calendars Pure PHP implementation of the Arabic (Hijri), French, Gregorian, Jewish, Julian and Persian (Jalali

      Problem 2
        - Root composer.json requires PHP extension ext-intl * but it is missing from your system. Install or enable PHP's intl extension.

          Alternatively you can require one of these packages that provide the extension (or parts of it):
          Keep in mind that the suggestions are automated and may not be valid or safe to use
          - phuture/continuum A forward-compatibility layer bringing tomorrow’s PHP features to today’s runtimes.

      Problem 3
        - Root composer.json requires PHP extension ext-pdo_mysql * but it is missing from your system. Install or enable PHP's pdo_mysql extension.
      Problem 4
        - Root composer.json requires laravel/framework ^13.0, found laravel/framework[v13.0.0, ..., v13.37.0] but these were not loaded, because they are affected by security advisories ("PKSA-d5tc-s1qs-h781", "PKSA-m5cs-t1y6-qpcs", "PKSA-3r5d-mb8f-1qw9", "PKSA-mdq4-51ck-6kdq"). Go to [REDACTED_URL] to find advisory details. To ignore the advisories, add their IDs to the "policy.advisories.ignore-id" config or add the package to "policy.advisories.ignore". To turn the feature off entirely, you can set "policy.advisories.block" to false.
      Problem 5
        - diglactic/laravel-breadcrumbs is locked to version v8.1.1 and an update of this package was not requested.
        - diglactic/laravel-breadcrumbs v8.1.1 requires laravel/framework ^6.0 || ^7.0 || ^8.0 || ^9.0 || ^10.0 -> found laravel/framework[v6.0.0, ..., v6.20.45, v7.0.0, ..., v7.30.7, v8.0.0, ..., v8.83.29, v9.0.0, ..., v9.52.22, v10.0.0, ..., v10.50.3] but it conflicts with your root composer.json require (^13.0).
      Problem 6
        - khaled.alshamaa/ar-php is locked to version v6.3.4 and an update of this package was not requested.
        - khaled.alshamaa/ar-php v6.3.4 requires ext-calendar * -> it is missing from your system. Install or enable PHP's calendar extension.

          Alternatively you can require one of these packages that provide the extension (or parts of it):
          Keep in mind that the suggestions are automated and may not be valid or safe to use
          - fisharebest/ext-calendar Implementation of the Arabic (Hijri), French, Gregorian, Jewish, Julian and Persian (Jalali) calenda
          - condorcet-php/php-calendars Pure PHP implementation of the Arabic (Hijri), French, Gregorian, Jewish, Julian and Persian (Jalali

      Problem 7
        - laravel/octane is locked to version v2.3.0 and an update of this package was not requested.
        - laravel/octane v2.3.0 requires laravel/framework ^10.10.1|^11.0 -> found laravel/framework[v10.10.1, ..., v10.50.3, v11.0.0, ..., v11.57.0] but it conflicts with your root composer.json require (^13.0).
      Problem 8
        - openai-php/laravel is locked to version v0.7.8 and an update of this package was not requested.
        - openai-php/laravel v0.7.8 requires laravel/framework ^9.46.0|^10.14.1 -> found laravel/framework[v9.46.0, ..., v9.52.22, v10.14.1, ..., v10.50.3] but it conflicts with your root composer.json require (^13.0).
      Problem 9
        - pestphp/pest-plugin-laravel is locked to version v2.2.0 and an update of this package was not requested.
        - pestphp/pest-plugin-laravel v2.2.0 requires laravel/framework ^10.18.0|^11.0 -> f
    [TRUNCATED: 4622 bytes of output omitted]
    ```
  - candidate lock: not available
  - diagnostic for `laravel/framework ^13.0` (outcome `success`, exit `1`), command argv: `["[COMPOSER_EXECUTABLE]","prohibits","laravel/framework","^13.0","--tree","--locked","--no-scripts","--no-plugins","--no-interaction"]`
    - stdout excerpt:
      ```text
      laravel/framework v10.41.0 The Laravel Framework.
      |--astrotomic/laravel-translatable v11.12.1 (requires illuminate/contracts ^8.0 || ^9.0 || ^10.0)
      |  `--bagisto/bagisto (requires astrotomic/laravel-translatable ^11.0.0)
      |--astrotomic/laravel-translatable v11.12.1 (requires illuminate/database ^8.0 || ^9.0 || ^10.0) (circular dependency aborted here)
      |--astrotomic/laravel-translatable v11.12.1 (requires illuminate/support ^8.0 || ^9.0 || ^10.0) (circular dependency aborted here)
      |--barryvdh/laravel-dompdf v2.0.1 (requires illuminate/support ^6|^7|^8|^9|^10)
      |  `--bagisto/bagisto (requires barryvdh/laravel-dompdf ^2.0.0)
      |--diglactic/laravel-breadcrumbs v8.1.1 (requires laravel/framework ^6.0 || ^7.0 || ^8.0 || ^9.0 || ^10.0)
      |  `--bagisto/bagisto (requires diglactic/laravel-breadcrumbs ^8.0)
      |--intervention/imagecache 2.6.0 (requires illuminate/cache ^5.5|~6|~7|~8|~9|~10)
      |  `--bagisto/bagisto (requires intervention/imagecache ^2.5.2)
      |--intervention/imagecache 2.6.0 (requires illuminate/filesystem ^5.5|~6|~7|~8|~9|~10) (circular dependency aborted here)
      |--kalnoy/nestedset v6.0.3 (requires illuminate/database ^7.0|^8.0|^9.0|^10.0)
      |  `--bagisto/bagisto (requires kalnoy/nestedset ^6.0)
      |--kalnoy/nestedset v6.0.3 (requires illuminate/events ^7.0|^8.0|^9.0|^10.0) (circular dependency aborted here)
      |--kalnoy/nestedset v6.0.3 (requires illuminate/support ^7.0|^8.0|^9.0|^10.0) (circular dependency aborted here)
      |--konekt/concord 1.14.0 (requires illuminate/console ^9.2|^10.0|^11.0)
      |  `--bagisto/bagisto (requires konekt/concord ^1.2)
      |--konekt/concord 1.14.0 (requires illuminate/support ^9.2|^10.0|^11.0) (circular dependency aborted here)
      |--konekt/enum-eloquent 1.9.3 (requires illuminate/database ^8.75|9.*|10.*|11.*)
      |  `--konekt/concord 1.14.0 (requires konekt/enum-eloquent ^1.7)
      |     `--bagisto/bagisto (requires konekt/concord ^1.2)
      |--laravel/octane v2.3.0 (requires laravel/framework ^10.10.1|^11.0)
      |  `--bagisto/bagisto (requires laravel/octane ^2.0)
      |--laravel/prompts v0.1.15 (requires illuminate/collections ^10.0|^11.0)
      |  |--laravel/framework v10.41.0 (requires laravel/prompts ^0.1.9) (circular dependency aborted here)
      |  `--laravel/framework v13.37.0 (requires laravel/prompts ^0.3.25) (circular dependency aborted here)
      |--laravel/sanctum v3.3.3 (requires illuminate/console ^9.21|^10.0)
      |  `--bagisto/bagisto (requires laravel/sanctum ^3.2)
      |--laravel/sanctum v3.3.3 (requires illuminate/contracts ^9.21|^10.0) (circular dependency aborted here)
      |--laravel/sanctum v3.3.3 (requires illuminate/database ^9.21|^10.0) (circular dependency aborted here)
      |--laravel/sanctum v3.3.3 (requires illuminate/support ^9.21|^10.0) (circular dependency aborted here)
      |--laravel/socialite v5.11.0 (requires illuminate/contracts ^6.0|^7.0|^8.0|^9.0|^10.0|^11.0)
      |  `--bagisto/bagisto (requires laravel/socialite ^5.0)
      |--laravel/socialite v5.11.0 (requires illuminate/http ^6.0|^7.0|^8.0|^9.0|^10.0|^11.0) (circular dependency aborted here)
      |--laravel/socialite v5.11.0 (requires illuminate/support ^6.0|^7.0|^8.0|^9.0|^10.0|^11.0) (circular dependency aborted here)
      |--laravel/tinker v2.9.0 (requires illuminate/console ^6.0|^7.0|^8.0|^9.0|^10.0|^11.0)
      |  `--bagisto/bagisto (requires laravel/tinker ^2.0)
      |--laravel/tinker v2.9.0 (requires illuminate/contracts ^6.0|^7.0|^8.0|^9.0|^10.0|^11.0) (circular dependency aborted here)
      |--laravel/tinker v2.9.0 (requires illuminate/support ^6.0|^7.0|^8.0|^9.0|^10.0|^11.0) (circular dependency aborted here)
      |--laravel/ui v4.4.0 (requires illuminate/console ^9.21|^10.0|^11.0)
      |  `--bagisto/bagisto (requires laravel/ui ^4.0)
      |--laravel/ui v4.4.0 (requires illuminate/filesystem ^9.21|^10.0|^11.0) (circular dependency aborted here)
      |--laravel/ui v4.4.0 (requires illuminate/support ^9.21|^10.0|^11.0) (circular dependency aborted here)
      |--laravel/ui v4.4.0 (requires illuminate/validation ^9.21|^10.0|^11.0) (circular dependency aborted here)
      |--maatwebsite/excel 3.1.52 (requires i
      [TRUNCATED: 14235 bytes of output omitted]
      ```
    - stderr excerpt:
      ```text
      Not finding what you were looking for? Try calling `composer require "laravel/framework:^13.0" --dry-run` to get another view on the problem.

      ```

## Staged Composer Resolution
- Execution: `evaluated`; status: `blocked`; provider: `laravel`; stop reason: `blocking_registry_not_cleared`
- Enforced staged limits: `6` hops, `3` attempts per stage, `128` Composer/diagnostic processes, `300` seconds per scenario, `900` seconds per stage, `1800` seconds aggregate.
- Advisory targets: memory `268435456` bytes, JSON `524288` bytes, Markdown `262144` bytes. This report records no peak-memory measurement or per-run pass result for these targets.
- **laravel-10-to-11** (`10` -> `11`): execution `evaluated`; resolution `blocked`; selected attempt `none`
  - analysis PHP: `8.3.0`; source snapshot: `original_project`
  - This stage assessment inspects the original project source snapshot; it does not assume edits from an earlier stage were applied.
  - effective platform: `7ff5eea52eeb0b2a1bd4bd68dd8bbf1a4506d339bb05a1e329a760ce3d9ac2ea`; completeness `partial`; profile `none`
  - Composer policy: `4903c7f20752bc09ece2de57c1657218e106fa9fcd3f99118cc53373278cef5f`; mode `compatible`; stage duration `22688 ms`
  - stage evidence: `laravel-stage-target-1`, `laravel-stage-remediation-2`, `laravel-stage-remediation-1`, `laravel-stage-remediation-3`, `stage-attempt-1`, `stage-root-change-1`, `stage-attempt-2`, `stage-root-change-2`, `stage-root-change-3`, `stage-attempt-3`, `stage-root-change-4`, `stage-root-change-5`, `stage-root-change-6`, `stage-root-change-7`, `old-illuminate-consumer-1`, `old-illuminate-consumer-2`, `old-illuminate-consumer-3`, `old-illuminate-consumer-4`, `old-illuminate-consumer-5`, `old-illuminate-consumer-6`, `old-illuminate-consumer-7`, `old-illuminate-consumer-8`, `old-illuminate-consumer-9`, `old-illuminate-consumer-10`, `laravel-package-nunomaduro_collision-1`, `laravel-package-guidance-1`, `laravel-package-laravel_sanctum-1`, `laravel-package-guidance-2`, `laravel-package-phpunit_phpunit-1`, `laravel-package-guidance-3`, `laravel-advisory-doctrine_dbal-1`, `laravel-package-advisory-1`, `laravel-advisory-laravel_sanctum-1`, `laravel-package-advisory-2`, `lock-metadata-3`, `lock-metadata-5`, `lock-metadata-7`, `lock-metadata-4`, `lock-metadata-6`, `lock-metadata-8`, `solver-6`, `solver-7`, `solver-8`
  - state chain: predecessor `2b19056ebcdb41c43cbc8b1400939312428af6039ced1a148453a0500fce8d72`; input `2b19056ebcdb41c43cbc8b1400939312428af6039ced1a148453a0500fce8d72`; output `none`
  - attempt `1` `target_only`: outcome `solver_failure`; duration `5103 ms`; selected no; blockers `stage-blocker-ba12b5b48d776e0c46a1`, `stage-blocker-37a5e98f9b7453e4ad30`, `stage-blocker-9e3e5f06abdb381696f9`, `stage-blocker-4087fc6bdd4562b04086`, `stage-blocker-73f076b412702ace82a2`
    - analyzer-only root change `laravel/framework`: `^10.0` -> `^11.0`
  - attempt `2` `root_constraint_remediation`: outcome `solver_failure`; duration `7279 ms`; selected no; blockers `stage-blocker-ba12b5b48d776e0c46a1`, `stage-blocker-37a5e98f9b7453e4ad30`, `stage-blocker-9e3e5f06abdb381696f9`, `stage-blocker-4087fc6bdd4562b04086`, `stage-blocker-73f076b412702ace82a2`, `stage-blocker-3dd0578d3e3e0b845bc9`
    - analyzer-only root change `laravel/framework`: `^10.0` -> `^11.0`
    - analyzer-only root change `laravel/sanctum`: `^3.2` -> `^4.0`
  - attempt `3` `root_and_locked_package_remediation`: outcome `solver_failure`; duration `10306 ms`; selected no; blockers `stage-blocker-ba12b5b48d776e0c46a1`, `stage-blocker-37a5e98f9b7453e4ad30`, `stage-blocker-9e3e5f06abdb381696f9`, `stage-blocker-4087fc6bdd4562b04086`, `stage-blocker-3dd0578d3e3e0b845bc9`, `stage-blocker-016ebb93c1abeb3483b4`, `stage-blocker-045a4e8743643114640a`
    - analyzer-only root change `laravel/framework`: `^10.0` -> `^11.0`
    - analyzer-only root change `laravel/sanctum`: `^3.2` -> `^4.0`
    - analyzer-only root change `nunomaduro/collision`: `^7.0` -> `^8.1`
    - analyzer-only root change `phpunit/phpunit`: `^10.0` -> `^10.5.35|^11.0.1|^12.0.1`
  - original-source finding (`high`): Update or replace incompatible illuminate/support constraints before targeting Laravel 11: astrotomic/laravel-translatable, barryvdh/laravel-debugbar, barryvdh/laravel-dompdf, kalnoy/nestedset, maatwebsite/excel, prettus/l5-repository, prettus/laravel-validation, shetabit/visitor, spatie/laravel-responsecache, spatie/laravel-sitemap.
  - original-source finding (`medium`): nunomaduro/collision v7.10.0 is outside the encoded Laravel 11 review range `^8.1`; review its upgrade or replacement.
  - original-source finding (`high`): laravel/sanctum v3.3.3 is outside the encoded Laravel 11 review range `^4.0`; review its upgrade or replacement.
  - original-source finding (`medium`): phpunit/phpunit 10.5.5 is outside the encoded Laravel 11 review range `^10.5.35|^11.0.1|^12.0.1`; review its upgrade or replacement.
  - original-source finding (`low`): Review and remove doctrine/dbal if it was only installed for Laravel schema operations; Laravel 11 no longer depends on it.
  - original-source finding (`high`): Publish the laravel/sanctum migrations before deploying the Laravel 11 upgrade; this package no longer loads its migrations automatically.
  - blocker references: `stage-blocker-ba12b5b48d776e0c46a1`, `stage-blocker-37a5e98f9b7453e4ad30`, `stage-blocker-9e3e5f06abdb381696f9`, `stage-blocker-4087fc6bdd4562b04086`, `stage-blocker-73f076b412702ace82a2`, `stage-blocker-3dd0578d3e3e0b845bc9`, `stage-blocker-016ebb93c1abeb3483b4`, `stage-blocker-045a4e8743643114640a`
  - source-impact references: `none`
  - risk for `laravel-10-to-11`: `high`
  - effort: 6-28 hours (`low` confidence)
  - action: [laravel-10-to-11] Resolve every active blocker and rerun this complete stage; do not advance.
  - action: [laravel-10-to-11] Replace or remove `intervention/imagecache`.
  - action: [laravel-10-to-11] Replace or remove `paypal/paypal-checkout-sdk`.
  - action: [laravel-10-to-11] Upgrade or replace `diglactic/laravel-breadcrumbs`.
  - action: [laravel-10-to-11] Choose a `laravel/framework` version compatible with the transitive constraint.
  - action: [laravel-10-to-11] Upgrade or replace `openai-php/laravel`.
  - action: [laravel-10-to-11] Upgrade or replace `laravel/sanctum`.
  - action: [laravel-10-to-11] Choose a `illuminate/console` version compatible with the transitive constraint.
  - action: [laravel-10-to-11] Remove or replace `nunomaduro/collision`.
  - action: [laravel-10-to-11] Choose versions whose replace/provide rules can coexist.
  - action: [laravel-10-to-11] Remove or replace `pestphp/pest`.
  - test for `laravel-10-to-11`: Resolve this stage stop condition, then rerun the complete Composer stage laravel-10-to-11. (`required`)
  - stop reason: `blocking_registry_not_cleared`
- **laravel-11-to-12** (`11` -> `12`): execution `skipped`; resolution `not evaluated`; selected attempt `none`
  - analysis PHP: `8.3.0`; source snapshot: `original_project`
  - This stage assessment inspects the original project source snapshot; it does not assume edits from an earlier stage were applied.
  - effective platform: `7ff5eea52eeb0b2a1bd4bd68dd8bbf1a4506d339bb05a1e329a760ce3d9ac2ea`; completeness `partial`; profile `none`
  - Composer policy: `4903c7f20752bc09ece2de57c1657218e106fa9fcd3f99118cc53373278cef5f`; mode `compatible`; stage duration `0 ms`
  - stage evidence: `laravel-stage-target-2`, `stage-skipped-1`, `laravel-stage-remediation-6`, `laravel-stage-remediation-5`, `laravel-stage-remediation-4`, `old-illuminate-consumer-11`, `old-illuminate-consumer-12`, `old-illuminate-consumer-13`, `old-illuminate-consumer-14`, `old-illuminate-consumer-15`, `laravel-package-phpunit_phpunit-2`, `laravel-package-guidance-4`, `laravel-package-pestphp_pest-1`, `laravel-package-guidance-5`, `laravel-package-nesbot_carbon-1`, `laravel-package-guidance-6`, `laravel-package-nunomaduro_collision-2`, `laravel-package-guidance-7`
  - state chain: predecessor `none`; input `none`; output `none`
  - original-source finding (`high`): Update or replace incompatible illuminate/support constraints before targeting Laravel 12: konekt/concord, laravel/socialite, laravel/tinker, laravel/ui, spatie/laravel-ignition.
  - original-source finding (`high`): phpunit/phpunit 10.5.5 is outside the encoded Laravel 12 review range `^10.5.35|^11.0|^12.0.1`; review its upgrade or replacement.
  - original-source finding (`high`): pestphp/pest v2.31.0 is outside the encoded Laravel 12 review range `^3.0|^4.0`; review its upgrade or replacement.
  - original-source finding (`medium`): nesbot/carbon 2.72.1 is outside the encoded Laravel 12 review range `^3.0`; review its upgrade or replacement.
  - original-source finding (`medium`): nunomaduro/collision v7.10.0 is outside the encoded Laravel 12 review range `^8.6`; review its upgrade or replacement.
  - blocker references: `none`
  - source-impact references: `none`
  - risk for `laravel-11-to-12`: `high`
  - effort: not estimated (0-0 sentinel).
  - action: [laravel-11-to-12] Do not advance: this stage was skipped and has no Composer feasibility evidence.
  - test for `laravel-11-to-12`: Resolve the preceding stop condition, then execute stage laravel-11-to-12 before selecting migration tests. (`required`)
  - stop reason: `previous_stage_blocked`
- **laravel-12-to-13** (`12` -> `13`): execution `skipped`; resolution `not evaluated`; selected attempt `none`
  - analysis PHP: `8.3.0`; source snapshot: `original_project`
  - This stage assessment inspects the original project source snapshot; it does not assume edits from an earlier stage were applied.
  - effective platform: `7ff5eea52eeb0b2a1bd4bd68dd8bbf1a4506d339bb05a1e329a760ce3d9ac2ea`; completeness `partial`; profile `none`
  - Composer policy: `4903c7f20752bc09ece2de57c1657218e106fa9fcd3f99118cc53373278cef5f`; mode `compatible`; stage duration `0 ms`
  - stage evidence: `laravel-stage-target-3`, `stage-skipped-2`, `laravel-stage-remediation-7`, `laravel-stage-remediation-10`, `laravel-stage-remediation-9`, `laravel-stage-remediation-8`, `laravel-framework-constraint-1`, `laravel-package-laravel_tinker-1`, `laravel-package-guidance-8`, `laravel-package-phpunit_phpunit-3`, `laravel-package-guidance-9`, `laravel-package-pestphp_pest-2`, `laravel-package-guidance-10`, `laravel-package-nunomaduro_collision-3`, `laravel-package-guidance-11`, `laravel-request-forgery-guidance-1`, `source-89`, `ownership-1`
  - state chain: predecessor `none`; input `none`; output `none`
  - original-source finding (`high`): Update the root laravel/framework constraint from `^10.0` to a constraint compatible with Laravel 13.
  - original-source finding (`high`): laravel/tinker v2.9.0 is outside the encoded Laravel 13 review range `^3.0`; review its upgrade or replacement.
  - original-source finding (`high`): phpunit/phpunit 10.5.5 is outside the encoded Laravel 13 review range `^11.5.50|^12.0|^13.0.3`; review its upgrade or replacement.
  - original-source finding (`high`): pestphp/pest v2.31.0 is outside the encoded Laravel 13 review range `^4.0|^5.0`; review its upgrade or replacement.
  - original-source finding (`medium`): nunomaduro/collision v7.10.0 is outside the encoded Laravel 13 review range `^8.6`; review its upgrade or replacement.
  - original-source finding (`medium`): Review 1 detected direct reference to VerifyCsrfToken or ValidateCsrfToken for PreventRequestForgery when targeting Laravel 13; deprecated aliases remain available.
  - blocker references: `none`
  - source-impact references: `source-impact-b36c59766e3ff74375a6`
  - risk for `laravel-12-to-13`: `high`
  - effort: not estimated (0-0 sentinel).
  - action: [laravel-12-to-13] Do not advance: this stage was skipped and has no Composer feasibility evidence.
  - test for `laravel-12-to-13`: Resolve the preceding stop condition, then execute stage laravel-12-to-13 before selecting migration tests. (`required`)
  - stop reason: `previous_stage_blocked`
- Staged source-impact registry:
  - `source-impact-b36c59766e3ff74375a6` stages `laravel-12-to-13`: `medium` impact for `laravel/framework` (evidence: `source-89`, `laravel-request-forgery-guidance-1`, `ownership-1`)
    - `inheritance` `Illuminate\Foundation\Http\Middleware\VerifyCsrfToken` in `app/Http/Middleware/VerifyCsrfToken.php:7` (evidence: `source-89`)
- Blocker registry:
  - `stage-blocker-ba12b5b48d776e0c46a1` stage `laravel-10-to-11`: `abandoned-package` `intervention/imagecache`; lifecycle `persists` (detected@1 -> persists@2 -> persists@3); blocking package `-`; constraint `-`; path `intervention/imagecache`
  - `stage-blocker-37a5e98f9b7453e4ad30` stage `laravel-10-to-11`: `abandoned-package` `paypal/paypal-checkout-sdk`; lifecycle `persists` (detected@1 -> persists@2 -> persists@3); blocking package `-`; constraint `-`; path `paypal/paypal-checkout-sdk`
  - `stage-blocker-9e3e5f06abdb381696f9` stage `laravel-10-to-11`: `transitive-package-conflict` `laravel/framework`; lifecycle `persists` (detected@1 -> persists@2 -> persists@3); blocking package `diglactic/laravel-breadcrumbs`; constraint `^6.0 || ^7.0 || ^8.0 || ^9.0 || ^10.0`; path `bagisto/bagisto -> diglactic/laravel-breadcrumbs -> laravel/framework`
  - `stage-blocker-4087fc6bdd4562b04086` stage `laravel-10-to-11`: `transitive-package-conflict` `laravel/framework`; lifecycle `persists` (detected@1 -> persists@2 -> persists@3); blocking package `openai-php/laravel`; constraint `^9.46.0|^10.14.1`; path `bagisto/bagisto -> diglactic/laravel-breadcrumbs -> laravel/framework`
  - `stage-blocker-73f076b412702ace82a2` stage `laravel-10-to-11`: `replace-provide-conflict` `laravel/framework`; lifecycle `resolved` (detected@1 -> persists@2 -> resolved@3); blocking package `nunomaduro/collision`; constraint `>=11.0.0`; path `bagisto/bagisto -> diglactic/laravel-breadcrumbs -> laravel/framework`
  - `stage-blocker-3dd0578d3e3e0b845bc9` stage `laravel-10-to-11`: `transitive-package-conflict` `illuminate/console`; lifecycle `persists` (detected@2 -> persists@3); blocking package `laravel/sanctum`; constraint `^11.0|^12.0|^13.0`; path `laravel/sanctum -> illuminate/console`
  - `stage-blocker-016ebb93c1abeb3483b4` stage `laravel-10-to-11`: `replace-provide-conflict` `laravel/framework`; lifecycle `detected` (detected@3); blocking package `nunomaduro/collision`; constraint `<11.48.0 || >=14.0.0`; path `nunomaduro/collision -> laravel/framework`
  - `stage-blocker-045a4e8743643114640a` stage `laravel-10-to-11`: `replace-provide-conflict` `phpunit/phpunit`; lifecycle `detected` (detected@3); blocking package `pestphp/pest`; constraint `>10.5.5`; path `pestphp/pest -> phpunit/phpunit`

## Package Changes
- No lockfile changes detected.

## Framework Transition Guidance
- `laravel`: `supported` (`10` -> `13`; evidence: `laravel-transition-1`, `laravel-transition-2`, `laravel-transition-3`)
  - hop `10` -> `11`: `supported`; rule pack `laravel-10-to-11` (evidence: `laravel-transition-1`)
  - hop `11` -> `12`: `supported`; rule pack `laravel-11-to-12` (evidence: `laravel-transition-2`)
  - hop `12` -> `13`: `supported`; rule pack `laravel-12-to-13` (evidence: `laravel-transition-3`)

## Root Constraint Changes
- `laravel/framework`: updated `^10.0` -> `^13.0`. The declared root constraint differs from the requested target. (evidence: `root-constraint-1`)

## Blockers
- `transitive-package-conflict` `laravel/framework`: A transitive package constraint blocks the requested target. (high confidence; evidence: `solver-1`, `solver-2`, `solver-3`, `solver-5`)
  - requested `^13.0`; blocker `diglactic/laravel-breadcrumbs`; locked `v8.1.1`; conflict `^6.0 || ^7.0 || ^8.0 || ^9.0 || ^10.0`
  - dependency path: `bagisto/bagisto -> diglactic/laravel-breadcrumbs -> laravel/framework`
  - option: Upgrade or replace `diglactic/laravel-breadcrumbs`.
  - option: Choose a `laravel/framework` version compatible with the transitive constraint.
- `transitive-package-conflict` `laravel/framework`: A transitive package constraint blocks the requested target. (high confidence; evidence: `solver-1`, `solver-2`, `solver-3`, `solver-5`)
  - requested `^13.0`; blocker `laravel/octane`; locked `v2.3.0`; conflict `^10.10.1|^11.0`
  - dependency path: `bagisto/bagisto -> diglactic/laravel-breadcrumbs -> laravel/framework`
  - option: Upgrade or replace `laravel/octane`.
  - option: Choose a `laravel/framework` version compatible with the transitive constraint.
- `transitive-package-conflict` `laravel/framework`: A transitive package constraint blocks the requested target. (high confidence; evidence: `solver-1`, `solver-2`, `solver-3`, `solver-5`)
  - requested `^13.0`; blocker `openai-php/laravel`; locked `v0.7.8`; conflict `^9.46.0|^10.14.1`
  - dependency path: `bagisto/bagisto -> diglactic/laravel-breadcrumbs -> laravel/framework`
  - option: Upgrade or replace `openai-php/laravel`.
  - option: Choose a `laravel/framework` version compatible with the transitive constraint.
- `replace-provide-conflict` `laravel/framework`: Composer found conflicting replace, provide, or conflict rules. (high confidence; evidence: `solver-1`, `solver-2`, `solver-3`, `solver-5`)
  - requested `^13.0`; blocker `nunomaduro/collision`; locked `v7.10.0`; conflict `>=11.0.0`
  - dependency path: `bagisto/bagisto -> diglactic/laravel-breadcrumbs -> laravel/framework`
  - option: Remove or replace `nunomaduro/collision`.
  - option: Choose versions whose replace/provide rules can coexist.
- `transitive-package-conflict` `laravel/framework`: A transitive package constraint blocks the requested target. (high confidence; evidence: `solver-1`, `solver-2`, `solver-3`, `solver-5`)
  - requested `^13.0`; blocker `pestphp/pest-plugin-laravel`; locked `v2.2.0`; conflict `^10.18.0|^11.0`
  - dependency path: `bagisto/bagisto -> diglactic/laravel-breadcrumbs -> laravel/framework`
  - option: Upgrade or replace `pestphp/pest-plugin-laravel`.
  - option: Choose a `laravel/framework` version compatible with the transitive constraint.
- `extension-missing` `ext-calendar`: A required PHP extension is unavailable. (high confidence; evidence: `solver-4`)
  - requested `-`; blocker `-`; locked `-`; conflict `*`
  - dependency path: `ext-calendar`
  - option: Install and enable `ext-calendar` for the target runtime.
  - option: Choose package versions that do not require `ext-calendar`.
- `extension-missing` `ext-intl`: A required PHP extension is unavailable. (high confidence; evidence: `solver-4`)
  - requested `-`; blocker `-`; locked `-`; conflict `*`
  - dependency path: `ext-intl`
  - option: Install and enable `ext-intl` for the target runtime.
  - option: Choose package versions that do not require `ext-intl`.
- `extension-missing` `ext-pdo_mysql`: A required PHP extension is unavailable. (high confidence; evidence: `solver-4`)
  - requested `-`; blocker `-`; locked `-`; conflict `*`
  - dependency path: `ext-pdo_mysql`
  - option: Install and enable `ext-pdo_mysql` for the target runtime.
  - option: Choose package versions that do not require `ext-pdo_mysql`.
- `unknown-composer-failure` `php`: Composer failed, but the blocker type could not be classified. (low confidence; evidence: `solver-4`)
  - requested `8.3.0`; blocker `-`; locked `-`; conflict `-`
  - dependency path: `php`
  - option: Inspect the linked Composer evidence.
  - option: Run `composer prohibits php <constraint> --tree` in an isolated copy.
- `transitive-package-conflict` `laravel/framework`: A transitive package constraint blocks the requested target. (high confidence; evidence: `solver-4`)
  - requested `-`; blocker `openai-php/laravel`; locked `v0.7.8`; conflict `^9.46.0|^10.14.1`
  - dependency path: `openai-php/laravel -> laravel/framework`
  - option: Upgrade or replace `openai-php/laravel`.
  - option: Choose a `laravel/framework` version compatible with the transitive constraint.
- `transitive-package-conflict` `dompdf/dompdf`: A transitive package constraint blocks the requested target. (high confidence; evidence: `solver-4`)
  - requested `-`; blocker `barryvdh/laravel-dompdf`; locked `v2.0.0`; conflict `^2`
  - dependency path: `barryvdh/laravel-dompdf -> dompdf/dompdf`
  - option: Upgrade or replace `barryvdh/laravel-dompdf`.
  - option: Choose a `dompdf/dompdf` version compatible with the transitive constraint.
- `abandoned-package` `intervention/imagecache`: Composer lock metadata marks this package as abandoned. (high confidence; evidence: `lock-metadata-1`)
  - requested `^2.5.2`; blocker `-`; locked `2.6.0`; conflict `-`
  - dependency path: `intervention/imagecache`
  - option: Replace or remove `intervention/imagecache`.
- `abandoned-package` `paypal/paypal-checkout-sdk`: Composer lock metadata marks this package as abandoned. (high confidence; evidence: `lock-metadata-2`)
  - requested `1.0.1`; blocker `-`; locked `1.0.1`; conflict `-`
  - dependency path: `paypal/paypal-checkout-sdk`
  - option: Replace or remove `paypal/paypal-checkout-sdk`.

## Source Inventory
- `namespace_import` `Illuminate\Console\Scheduling\Schedule` in `app/Console/Kernel.php:5` (evidence: `source-1`)
- `namespace_import` `Illuminate\Foundation\Console\Kernel` in `app/Console/Kernel.php:6` (evidence: `source-2`)
- `inheritance` `Illuminate\Foundation\Console\Kernel` in `app/Console/Kernel.php:8` (evidence: `source-3`)
- `function_call` `base_path` in `app/Console/Kernel.php:43` (evidence: `source-4`)
- `namespace_import` `Illuminate\Foundation\Exceptions\Handler` in `app/Exceptions/Handler.php:5` (evidence: `source-5`)
- `namespace_import` `Throwable` in `app/Exceptions/Handler.php:6` (evidence: `source-6`)
- `inheritance` `Illuminate\Foundation\Exceptions\Handler` in `app/Exceptions/Handler.php:8` (evidence: `source-7`)
- `namespace_import` `Illuminate\Foundation\Auth\Access\AuthorizesRequests` in `app/Http/Controllers/Controller.php:5` (evidence: `source-8`)
- `namespace_import` `Illuminate\Foundation\Bus\DispatchesJobs` in `app/Http/Controllers/Controller.php:6` (evidence: `source-9`)
- `namespace_import` `Illuminate\Foundation\Validation\ValidatesRequests` in `app/Http/Controllers/Controller.php:7` (evidence: `source-10`)
- `namespace_import` `Illuminate\Routing\Controller` in `app/Http/Controllers/Controller.php:8` (evidence: `source-11`)
- `inheritance` `Illuminate\Routing\Controller` in `app/Http/Controllers/Controller.php:10` (evidence: `source-12`)
- `trait_reference` `Illuminate\Foundation\Auth\Access\AuthorizesRequests` in `app/Http/Controllers/Controller.php:12` (evidence: `source-13`)
- `trait_reference` `Illuminate\Foundation\Bus\DispatchesJobs` in `app/Http/Controllers/Controller.php:12` (evidence: `source-14`)
- `trait_reference` `Illuminate\Foundation\Validation\ValidatesRequests` in `app/Http/Controllers/Controller.php:12` (evidence: `source-15`)
- `namespace_import` `Illuminate\Foundation\Http\Kernel` in `app/Http/Kernel.php:5` (evidence: `source-16`)
- `inheritance` `Illuminate\Foundation\Http\Kernel` in `app/Http/Kernel.php:7` (evidence: `source-17`)
- `class_constant_access` `App\Http\Middleware\TrustProxies` in `app/Http/Kernel.php:18` (evidence: `source-18`)
- `class_constant_access` `Illuminate\Http\Middleware\HandleCors` in `app/Http/Kernel.php:19` (evidence: `source-19`)
- `class_constant_access` `Webkul\Core\Http\Middleware\CheckForMaintenanceMode` in `app/Http/Kernel.php:20` (evidence: `source-20`)
- `class_constant_access` `Illuminate\Foundation\Http\Middleware\ValidatePostSize` in `app/Http/Kernel.php:21` (evidence: `source-21`)
- `class_constant_access` `App\Http\Middleware\TrimStrings` in `app/Http/Kernel.php:22` (evidence: `source-22`)
- `class_constant_access` `Webkul\Core\Http\Middleware\SecureHeaders` in `app/Http/Kernel.php:23` (evidence: `source-23`)
- `class_constant_access` `Webkul\Installer\Http\Middleware\CanInstall` in `app/Http/Kernel.php:24` (evidence: `source-24`)
- `class_constant_access` `App\Http\Middleware\EncryptCookies` in `app/Http/Kernel.php:34` (evidence: `source-25`)
- `class_constant_access` `Illuminate\Cookie\Middleware\AddQueuedCookiesToResponse` in `app/Http/Kernel.php:35` (evidence: `source-26`)
- `class_constant_access` `Illuminate\Session\Middleware\StartSession` in `app/Http/Kernel.php:36` (evidence: `source-27`)
- `class_constant_access` `Illuminate\View\Middleware\ShareErrorsFromSession` in `app/Http/Kernel.php:37` (evidence: `source-28`)
- `class_constant_access` `App\Http\Middleware\VerifyCsrfToken` in `app/Http/Kernel.php:38` (evidence: `source-29`)
- `class_constant_access` `Illuminate\Routing\Middleware\SubstituteBindings` in `app/Http/Kernel.php:39` (evidence: `source-30`)
- `class_constant_access` `Illuminate\Routing\Middleware\ThrottleRequests` in `app/Http/Kernel.php:44` (evidence: `source-31`)
- `class_constant_access` `Illuminate\Routing\Middleware\SubstituteBindings` in `app/Http/Kernel.php:45` (evidence: `source-32`)
- `class_constant_access` `Illuminate\Auth\Middleware\Authenticate` in `app/Http/Kernel.php:57` (evidence: `source-33`)
- `class_constant_access` `Illuminate\Auth\Middleware\AuthenticateWithBasicAuth` in `app/Http/Kernel.php:58` (evidence: `source-34`)
- `class_constant_access` `Illuminate\Session\Middleware\AuthenticateSession` in `app/Http/Kernel.php:59` (evidence: `source-35`)
- `class_constant_access` `Illuminate\Http\Middleware\SetCacheHeaders` in `app/Http/Kernel.php:60` (evidence: `source-36`)
- `class_constant_access` `Illuminate\Auth\Middleware\Authorize` in `app/Http/Kernel.php:61` (evidence: `source-37`)
- `class_constant_access` `App\Http\Middleware\RedirectIfAuthenticated` in `app/Http/Kernel.php:62` (evidence: `source-38`)
- `class_constant_access` `Illuminate\Routing\Middleware\ValidateSignature` in `app/Http/Kernel.php:63` (evidence: `source-39`)
- `class_constant_access` `Illuminate\Routing\Middleware\ThrottleRequests` in `app/Http/Kernel.php:64` (evidence: `source-40`)
- `class_constant_access` `Webkul\Shop\Http\Middleware\CacheResponse` in `app/Http/Kernel.php:65` (evidence: `source-41`)
- `middleware_reference` `App\Http\Middleware\TrustProxies` in `app/Http/Kernel.php:18` (evidence: `source-42`)
- `middleware_reference` `Illuminate\Http\Middleware\HandleCors` in `app/Http/Kernel.php:19` (evidence: `source-43`)
- `middleware_reference` `Webkul\Core\Http\Middleware\CheckForMaintenanceMode` in `app/Http/Kernel.php:20` (evidence: `source-44`)
- `middleware_reference` `Illuminate\Foundation\Http\Middleware\ValidatePostSize` in `app/Http/Kernel.php:21` (evidence: `source-45`)
- `middleware_reference` `App\Http\Middleware\TrimStrings` in `app/Http/Kernel.php:22` (evidence: `source-46`)
- `middleware_reference` `Webkul\Core\Http\Middleware\SecureHeaders` in `app/Http/Kernel.php:23` (evidence: `source-47`)
- `middleware_reference` `Webkul\Installer\Http\Middleware\CanInstall` in `app/Http/Kernel.php:24` (evidence: `source-48`)
- `middleware_reference` `App\Http\Middleware\EncryptCookies` in `app/Http/Kernel.php:34` (evidence: `source-49`)
- `middleware_reference` `Illuminate\Cookie\Middleware\AddQueuedCookiesToResponse` in `app/Http/Kernel.php:35` (evidence: `source-50`)
- `middleware_reference` `Illuminate\Session\Middleware\StartSession` in `app/Http/Kernel.php:36` (evidence: `source-51`)
- `middleware_reference` `Illuminate\View\Middleware\ShareErrorsFromSession` in `app/Http/Kernel.php:37` (evidence: `source-52`)
- `middleware_reference` `App\Http\Middleware\VerifyCsrfToken` in `app/Http/Kernel.php:38` (evidence: `source-53`)
- `middleware_reference` `Illuminate\Routing\Middleware\SubstituteBindings` in `app/Http/Kernel.php:39` (evidence: `source-54`)
- `middleware_reference` `Illuminate\Routing\Middleware\ThrottleRequests` in `app/Http/Kernel.php:44` (evidence: `source-55`)
- `middleware_reference` `Illuminate\Routing\Middleware\SubstituteBindings` in `app/Http/Kernel.php:45` (evidence: `source-56`)
- `middleware_reference` `Illuminate\Auth\Middleware\Authenticate` in `app/Http/Kernel.php:57` (evidence: `source-57`)
- `middleware_reference` `Illuminate\Auth\Middleware\AuthenticateWithBasicAuth` in `app/Http/Kernel.php:58` (evidence: `source-58`)
- `middleware_reference` `Illuminate\Session\Middleware\AuthenticateSession` in `app/Http/Kernel.php:59` (evidence: `source-59`)
- `middleware_reference` `Illuminate\Http\Middleware\SetCacheHeaders` in `app/Http/Kernel.php:60` (evidence: `source-60`)
- `middleware_reference` `Illuminate\Auth\Middleware\Authorize` in `app/Http/Kernel.php:61` (evidence: `source-61`)
- `middleware_reference` `App\Http\Middleware\RedirectIfAuthenticated` in `app/Http/Kernel.php:62` (evidence: `source-62`)
- `middleware_reference` `Illuminate\Routing\Middleware\ValidateSignature` in `app/Http/Kernel.php:63` (evidence: `source-63`)
- `middleware_reference` `Illuminate\Routing\Middleware\ThrottleRequests` in `app/Http/Kernel.php:64` (evidence: `source-64`)
- `middleware_reference` `Webkul\Shop\Http\Middleware\CacheResponse` in `app/Http/Kernel.php:65` (evidence: `source-65`)
- `namespace_import` `Illuminate\Cookie\Middleware\EncryptCookies` in `app/Http/Middleware/EncryptCookies.php:5` (evidence: `source-66`)
- `inheritance` `Illuminate\Cookie\Middleware\EncryptCookies` in `app/Http/Middleware/EncryptCookies.php:7` (evidence: `source-67`)
- `namespace_import` `App\Providers\RouteServiceProvider` in `app/Http/Middleware/RedirectIfAuthenticated.php:5` (evidence: `source-68`)
- `namespace_import` `Closure` in `app/Http/Middleware/RedirectIfAuthenticated.php:6` (evidence: `source-69`)
- `namespace_import` `Illuminate\Http\Request` in `app/Http/Middleware/RedirectIfAuthenticated.php:7` (evidence: `source-70`)
- `namespace_import` `Illuminate\Support\Facades\Auth` in `app/Http/Middleware/RedirectIfAuthenticated.php:8` (evidence: `source-71`)
- `namespace_import` `Symfony\Component\HttpFoundation\Response` in `app/Http/Middleware/RedirectIfAuthenticated.php:9` (evidence: `source-72`)
- `static_call` `Illuminate\Support\Facades\Auth` in `app/Http/Middleware/RedirectIfAuthenticated.php:23` (evidence: `source-73`)
- `function_call` `redirect` in `app/Http/Middleware/RedirectIfAuthenticated.php:24` (evidence: `source-74`)
- `class_constant_access` `App\Providers\RouteServiceProvider` in `app/Http/Middleware/RedirectIfAuthenticated.php:24` (evidence: `source-75`)
- `namespace_import` `Illuminate\Foundation\Http\Middleware\TrimStrings` in `app/Http/Middleware/TrimStrings.php:5` (evidence: `source-76`)
- `inheritance` `Illuminate\Foundation\Http\Middleware\TrimStrings` in `app/Http/Middleware/TrimStrings.php:7` (evidence: `source-77`)
- `namespace_import` `Illuminate\Http\Middleware\TrustHosts` in `app/Http/Middleware/TrustHosts.php:5` (evidence: `source-78`)
- `inheritance` `Illuminate\Http\Middleware\TrustHosts` in `app/Http/Middleware/TrustHosts.php:7` (evidence: `source-79`)
- `namespace_import` `Illuminate\Http\Middleware\TrustProxies` in `app/Http/Middleware/TrustProxies.php:5` (evidence: `source-80`)
- `namespace_import` `Illuminate\Http\Request` in `app/Http/Middleware/TrustProxies.php:6` (evidence: `source-81`)
- `inheritance` `Illuminate\Http\Middleware\TrustProxies` in `app/Http/Middleware/TrustProxies.php:8` (evidence: `source-82`)
- `class_constant_access` `Illuminate\Http\Request` in `app/Http/Middleware/TrustProxies.php:23` (evidence: `source-83`)
- `class_constant_access` `Illuminate\Http\Request` in `app/Http/Middleware/TrustProxies.php:24` (evidence: `source-84`)
- `class_constant_access` `Illuminate\Http\Request` in `app/Http/Middleware/TrustProxies.php:25` (evidence: `source-85`)
- `class_constant_access` `Illuminate\Http\Request` in `app/Http/Middleware/TrustProxies.php:26` (evidence: `source-86`)
- `class_constant_access` `Illuminate\Http\Request` in `app/Http/Middleware/TrustProxies.php:27` (evidence: `source-87`)
- `namespace_import` `Illuminate\Foundation\Http\Middleware\VerifyCsrfToken` in `app/Http/Middleware/VerifyCsrfToken.php:5` (evidence: `source-88`)
- `inheritance` `Illuminate\Foundation\Http\Middleware\VerifyCsrfToken` in `app/Http/Middleware/VerifyCsrfToken.php:7` (evidence: `source-89`)
- `namespace_import` `Illuminate\Support\Facades\Artisan` in `app/Providers/AppServiceProvider.php:5` (evidence: `source-90`)
- `namespace_import` `Illuminate\Support\Facades\ParallelTesting` in `app/Providers/AppServiceProvider.php:6` (evidence: `source-91`)
- `namespace_import` `Illuminate\Support\Facades\Request` in `app/Providers/AppServiceProvider.php:7` (evidence: `source-92`)
- `namespace_import` `Illuminate\Support\Facades\Schema` in `app/Providers/AppServiceProvider.php:8` (evidence: `source-93`)
- `namespace_import` `Illuminate\Support\ServiceProvider` in `app/Providers/AppServiceProvider.php:9` (evidence: `source-94`)
- `inheritance` `Illuminate\Support\ServiceProvider` in `app/Providers/AppServiceProvider.php:11` (evidence: `source-95`)
- `static_call` `Illuminate\Support\Facades\Schema` in `app/Providers/AppServiceProvider.php:18` (evidence: `source-96`)
- `static_call` `Illuminate\Support\Facades\ParallelTesting` in `app/Providers/AppServiceProvider.php:20` (evidence: `source-97`)
- `static_call` `Illuminate\Support\Facades\Artisan` in `app/Providers/AppServiceProvider.php:21` (evidence: `source-98`)
- `function_call` `array_map` in `app/Providers/AppServiceProvider.php:30` (evidence: `source-99`)
- `function_call` `explode` in `app/Providers/AppServiceProvider.php:30` (evidence: `source-100`)
- `function_call` `config` in `app/Providers/AppServiceProvider.php:30` (evidence: `source-101`)
- `function_call` `array_filter` in `app/Providers/AppServiceProvider.php:32` (evidence: `source-102`)
- `function_call` `in_array` in `app/Providers/AppServiceProvider.php:38` (evidence: `source-103`)
- `static_call` `Illuminate\Support\Facades\Request` in `app/Providers/AppServiceProvider.php:38` (evidence: `source-104`)
- `static_call` `Debugbar` in `app/Providers/AppServiceProvider.php:39` (evidence: `source-105`)
- `static_call` `Debugbar` in `app/Providers/AppServiceProvider.php:41` (evidence: `source-106`)
- `service_provider` `App\Providers\AppServiceProvider` in `app/Providers/AppServiceProvider.php:11` (evidence: `source-107`)
- `config_reference` `app.debug_allowed_ips` in `app/Providers/AppServiceProvider.php:30` (evidence: `source-108`)
- `namespace_import` `Illuminate\Foundation\Support\Providers\AuthServiceProvider` in `app/Providers/AuthServiceProvider.php:6` (evidence: `source-109`)
- `inheritance` `Illuminate\Foundation\Support\Providers\AuthServiceProvider` in `app/Providers/AuthServiceProvider.php:8` (evidence: `source-110`)
- `namespace_import` `Illuminate\Support\Facades\Broadcast` in `app/Providers/BroadcastServiceProvider.php:5` (evidence: `source-111`)
- `namespace_import` `Illuminate\Support\ServiceProvider` in `app/Providers/BroadcastServiceProvider.php:6` (evidence: `source-112`)
- `inheritance` `Illuminate\Support\ServiceProvider` in `app/Providers/BroadcastServiceProvider.php:8` (evidence: `source-113`)
- `static_call` `Illuminate\Support\Facades\Broadcast` in `app/Providers/BroadcastServiceProvider.php:15` (evidence: `source-114`)
- `function_call` `base_path` in `app/Providers/BroadcastServiceProvider.php:17` (evidence: `source-115`)
- `service_provider` `App\Providers\BroadcastServiceProvider` in `app/Providers/BroadcastServiceProvider.php:8` (evidence: `source-116`)
- `namespace_import` `Illuminate\Foundation\Support\Providers\EventServiceProvider` in `app/Providers/EventServiceProvider.php:5` (evidence: `source-117`)
- `inheritance` `Illuminate\Foundation\Support\Providers\EventServiceProvider` in `app/Providers/EventServiceProvider.php:7` (evidence: `source-118`)
- `namespace_import` `Illuminate\Cache\RateLimiting\Limit` in `app/Providers/RouteServiceProvider.php:5` (evidence: `source-119`)
- `namespace_import` `Illuminate\Foundation\Support\Providers\RouteServiceProvider` in `app/Providers/RouteServiceProvider.php:6` (evidence: `source-120`)
- `namespace_import` `Illuminate\Http\Request` in `app/Providers/RouteServiceProvider.php:7` (evidence: `source-121`)
- `namespace_import` `Illuminate\Support\Facades\RateLimiter` in `app/Providers/RouteServiceProvider.php:8` (evidence: `source-122`)
- `namespace_import` `Illuminate\Support\Facades\Route` in `app/Providers/RouteServiceProvider.php:9` (evidence: `source-123`)
- `inheritance` `Illuminate\Foundation\Support\Providers\RouteServiceProvider` in `app/Providers/RouteServiceProvider.php:11` (evidence: `source-124`)
- `static_call` `Illuminate\Support\Facades\RateLimiter` in `app/Providers/RouteServiceProvider.php:27` (evidence: `source-125`)
- `static_call` `Illuminate\Cache\RateLimiting\Limit` in `app/Providers/RouteServiceProvider.php:28` (evidence: `source-126`)
- `static_call` `Illuminate\Support\Facades\Route` in `app/Providers/RouteServiceProvider.php:32` (evidence: `source-127`)
- `function_call` `base_path` in `app/Providers/RouteServiceProvider.php:34` (evidence: `source-128`)
- `static_call` `Illuminate\Support\Facades\Route` in `app/Providers/RouteServiceProvider.php:36` (evidence: `source-129`)
- `function_call` `base_path` in `app/Providers/RouteServiceProvider.php:37` (evidence: `source-130`)
- `instantiated_class` `Illuminate\Foundation\Application` in `bootstrap/app.php:14` (evidence: `source-131`)
- `function_call` `realpath` in `bootstrap/app.php:15` (evidence: `source-132`)
- `class_constant_access` `Illuminate\Contracts\Http\Kernel` in `bootstrap/app.php:30` (evidence: `source-133`)
- `class_constant_access` `App\Http\Kernel` in `bootstrap/app.php:31` (evidence: `source-134`)
- `class_constant_access` `Illuminate\Contracts\Console\Kernel` in `bootstrap/app.php:35` (evidence: `source-135`)
- `class_constant_access` `App\Console\Kernel` in `bootstrap/app.php:36` (evidence: `source-136`)
- `class_constant_access` `Illuminate\Contracts\Debug\ExceptionHandler` in `bootstrap/app.php:40` (evidence: `source-137`)
- `class_constant_access` `App\Exceptions\Handler` in `bootstrap/app.php:41` (evidence: `source-138`)
- `namespace_import` `Illuminate\Support\Facades\Facade` in `config/app.php:3` (evidence: `source-139`)
- `namespace_import` `Illuminate\Support\ServiceProvider` in `config/app.php:4` (evidence: `source-140`)
- `function_call` `env` in `config/app.php:18` (evidence: `source-141`)
- `function_call` `env` in `config/app.php:31` (evidence: `source-142`)
- `function_call` `env` in `config/app.php:44` (evidence: `source-143`)
- `function_call` `env` in `config/app.php:56` (evidence: `source-144`)
- `function_call` `env` in `config/app.php:69` (evidence: `source-145`)
- `function_call` `env` in `config/app.php:81` (evidence: `source-146`)
- `function_call` `env` in `config/app.php:94` (evidence: `source-147`)
- `function_call` `env` in `config/app.php:107` (evidence: `source-148`)
- `function_call` `env` in `config/app.php:146` (evidence: `source-149`)
- `function_call` `env` in `config/app.php:170` (evidence: `source-150`)
- `static_call` `Illuminate\Support\ServiceProvider` in `config/app.php:185` (evidence: `source-151`)
- `class_constant_access` `Astrotomic\Translatable\TranslatableServiceProvider` in `config/app.php:189` (evidence: `source-152`)
- `class_constant_access` `Barryvdh\DomPDF\ServiceProvider` in `config/app.php:190` (evidence: `source-153`)
- `class_constant_access` `Intervention\Image\ImageServiceProvider` in `config/app.php:191` (evidence: `source-154`)
- `class_constant_access` `Konekt\Concord\ConcordServiceProvider` in `config/app.php:192` (evidence: `source-155`)
- `class_constant_access` `Maatwebsite\Excel\ExcelServiceProvider` in `config/app.php:193` (evidence: `source-156`)
- `class_constant_access` `Prettus\Repository\Providers\RepositoryServiceProvider` in `config/app.php:194` (evidence: `source-157`)
- `class_constant_access` `App\Providers\AppServiceProvider` in `config/app.php:199` (evidence: `source-158`)
- `class_constant_access` `App\Providers\AuthServiceProvider` in `config/app.php:200` (evidence: `source-159`)
- `class_constant_access` `App\Providers\EventServiceProvider` in `config/app.php:202` (evidence: `source-160`)
- `class_constant_access` `App\Providers\RouteServiceProvider` in `config/app.php:203` (evidence: `source-161`)
- `class_constant_access` `Webkul\Admin\Providers\AdminServiceProvider` in `config/app.php:208` (evidence: `source-162`)
- `class_constant_access` `Webkul\Attribute\Providers\AttributeServiceProvider` in `config/app.php:209` (evidence: `source-163`)
- `class_constant_access` `Webkul\CartRule\Providers\CartRuleServiceProvider` in `config/app.php:210` (evidence: `source-164`)
- `class_constant_access` `Webkul\CatalogRule\Providers\CatalogRuleServiceProvider` in `config/app.php:211` (evidence: `source-165`)
- `class_constant_access` `Webkul\Category\Providers\CategoryServiceProvider` in `config/app.php:212` (evidence: `source-166`)
- `class_constant_access` `Webkul\Checkout\Providers\CheckoutServiceProvider` in `config/app.php:213` (evidence: `source-167`)
- `class_constant_access` `Webkul\CMS\Providers\CMSServiceProvider` in `config/app.php:214` (evidence: `source-168`)
- `class_constant_access` `Webkul\Core\Providers\CoreServiceProvider` in `config/app.php:215` (evidence: `source-169`)
- `class_constant_access` `Webkul\Core\Providers\EnvValidatorServiceProvider` in `config/app.php:216` (evidence: `source-170`)
- `class_constant_access` `Webkul\Customer\Providers\CustomerServiceProvider` in `config/app.php:217` (evidence: `source-171`)
- `class_constant_access` `Webkul\DataGrid\Providers\DataGridServiceProvider` in `config/app.php:218` (evidence: `source-172`)
- `class_constant_access` `Webkul\DataTransfer\Providers\DataTransferServiceProvider` in `config/app.php:219` (evidence: `source-173`)
- `class_constant_access` `Webkul\DebugBar\Providers\DebugBarServiceProvider` in `config/app.php:220` (evidence: `source-174`)
- `class_constant_access` `Webkul\FPC\Providers\FPCServiceProvider` in `config/app.php:221` (evidence: `source-175`)
- `class_constant_access` `Webkul\Installer\Providers\InstallerServiceProvider` in `config/app.php:222` (evidence: `source-176`)
- `class_constant_access` `Webkul\Inventory\Providers\InventoryServiceProvider` in `config/app.php:223` (evidence: `source-177`)
- `class_constant_access` `Webkul\MagicAI\Providers\MagicAIServiceProvider` in `config/app.php:224` (evidence: `source-178`)
- `class_constant_access` `Webkul\Marketing\Providers\MarketingServiceProvider` in `config/app.php:225` (evidence: `source-179`)
- `class_constant_access` `Webkul\Notification\Providers\NotificationServiceProvider` in `config/app.php:226` (evidence: `source-180`)
- `class_constant_access` `Webkul\Payment\Providers\PaymentServiceProvider` in `config/app.php:227` (evidence: `source-181`)
- `class_constant_access` `Webkul\Paypal\Providers\PaypalServiceProvider` in `config/app.php:228` (evidence: `source-182`)
- `class_constant_access` `Webkul\Product\Providers\ProductServiceProvider` in `config/app.php:229` (evidence: `source-183`)
- `class_constant_access` `Webkul\Rule\Providers\RuleServiceProvider` in `config/app.php:230` (evidence: `source-184`)
- `class_constant_access` `Webkul\Sales\Providers\SalesServiceProvider` in `config/app.php:231` (evidence: `source-185`)
- `class_constant_access` `Webkul\Shipping\Providers\ShippingServiceProvider` in `config/app.php:232` (evidence: `source-186`)
- `class_constant_access` `Webkul\Shop\Providers\ShopServiceProvider` in `config/app.php:233` (evidence: `source-187`)
- `class_constant_access` `Webkul\Sitemap\Providers\SitemapServiceProvider` in `config/app.php:234` (evidence: `source-188`)
- `class_constant_access` `Webkul\SocialLogin\Providers\SocialLoginServiceProvider` in `config/app.php:235` (evidence: `source-189`)
- `class_constant_access` `Webkul\SocialShare\Providers\SocialShareServiceProvider` in `config/app.php:236` (evidence: `source-190`)
- `class_constant_access` `Webkul\Tax\Providers\TaxServiceProvider` in `config/app.php:237` (evidence: `source-191`)
- `class_constant_access` `Webkul\Theme\Providers\ThemeServiceProvider` in `config/app.php:238` (evidence: `source-192`)
- `class_constant_access` `Webkul\User\Providers\UserServiceProvider` in `config/app.php:239` (evidence: `source-193`)
- `static_call` `Illuminate\Support\Facades\Facade` in `config/app.php:253` (evidence: `source-194`)
- `class_constant_access` `Webkul\Customer\Facades\Captcha` in `config/app.php:254` (evidence: `source-195`)
- `class_constant_access` `Webkul\Checkout\Facades\Cart` in `config/app.php:255` (evidence: `source-196`)
- `class_constant_access` `Konekt\Concord\Facades\Concord` in `config/app.php:256` (evidence: `source-197`)
- `class_constant_access` `Webkul\Core\Facades\Core` in `config/app.php:257` (evidence: `source-198`)
- `class_constant_access` `Maatwebsite\Excel\Facades\Excel` in `config/app.php:258` (evidence: `source-199`)
- `class_constant_access` `Konekt\Concord\Facades\Helper` in `config/app.php:259` (evidence: `source-200`)
- `class_constant_access` `Intervention\Image\Facades\Image` in `config/app.php:260` (evidence: `source-201`)
- `class_constant_access` `Barryvdh\DomPDF\Facade\Pdf` in `config/app.php:261` (evidence: `source-202`)
- `class_constant_access` `Webkul\Product\Facades\ProductImage` in `config/app.php:262` (evidence: `source-203`)
- `class_constant_access` `Webkul\Product\Facades\ProductVideo` in `config/app.php:263` (evidence: `source-204`)
- `class_constant_access` `Illuminate\Support\Facades\Redis` in `config/app.php:264` (evidence: `source-205`)
- `service_provider` `Astrotomic\Translatable\TranslatableServiceProvider` in `config/app.php:189` (evidence: `source-206`)
- `service_provider` `Barryvdh\DomPDF\ServiceProvider` in `config/app.php:190` (evidence: `source-207`)
- `service_provider` `Intervention\Image\ImageServiceProvider` in `config/app.php:191` (evidence: `source-208`)
- `service_provider` `Konekt\Concord\ConcordServiceProvider` in `config/app.php:192` (evidence: `source-209`)
- `service_provider` `Maatwebsite\Excel\ExcelServiceProvider` in `config/app.php:193` (evidence: `source-210`)
- `service_provider` `Prettus\Repository\Providers\RepositoryServiceProvider` in `config/app.php:194` (evidence: `source-211`)
- `service_provider` `App\Providers\AppServiceProvider` in `config/app.php:199` (evidence: `source-212`)
- `service_provider` `App\Providers\AuthServiceProvider` in `config/app.php:200` (evidence: `source-213`)
- `service_provider` `App\Providers\EventServiceProvider` in `config/app.php:202` (evidence: `source-214`)
- `service_provider` `App\Providers\RouteServiceProvider` in `config/app.php:203` (evidence: `source-215`)
- `service_provider` `Webkul\Admin\Providers\AdminServiceProvider` in `config/app.php:208` (evidence: `source-216`)
- `service_provider` `Webkul\Attribute\Providers\AttributeServiceProvider` in `config/app.php:209` (evidence: `source-217`)
- `service_provider` `Webkul\CartRule\Providers\CartRuleServiceProvider` in `config/app.php:210` (evidence: `source-218`)
- `service_provider` `Webkul\CatalogRule\Providers\CatalogRuleServiceProvider` in `config/app.php:211` (evidence: `source-219`)
- `service_provider` `Webkul\Category\Providers\CategoryServiceProvider` in `config/app.php:212` (evidence: `source-220`)
- `service_provider` `Webkul\Checkout\Providers\CheckoutServiceProvider` in `config/app.php:213` (evidence: `source-221`)
- `service_provider` `Webkul\CMS\Providers\CMSServiceProvider` in `config/app.php:214` (evidence: `source-222`)
- `service_provider` `Webkul\Core\Providers\CoreServiceProvider` in `config/app.php:215` (evidence: `source-223`)
- `service_provider` `Webkul\Core\Providers\EnvValidatorServiceProvider` in `config/app.php:216` (evidence: `source-224`)
- `service_provider` `Webkul\Customer\Providers\CustomerServiceProvider` in `config/app.php:217` (evidence: `source-225`)
- `service_provider` `Webkul\DataGrid\Providers\DataGridServiceProvider` in `config/app.php:218` (evidence: `source-226`)
- `service_provider` `Webkul\DataTransfer\Providers\DataTransferServiceProvider` in `config/app.php:219` (evidence: `source-227`)
- `service_provider` `Webkul\DebugBar\Providers\DebugBarServiceProvider` in `config/app.php:220` (evidence: `source-228`)
- `service_provider` `Webkul\FPC\Providers\FPCServiceProvider` in `config/app.php:221` (evidence: `source-229`)
- `service_provider` `Webkul\Installer\Providers\InstallerServiceProvider` in `config/app.php:222` (evidence: `source-230`)
- `service_provider` `Webkul\Inventory\Providers\InventoryServiceProvider` in `config/app.php:223` (evidence: `source-231`)
- `service_provider` `Webkul\MagicAI\Providers\MagicAIServiceProvider` in `config/app.php:224` (evidence: `source-232`)
- `service_provider` `Webkul\Marketing\Providers\MarketingServiceProvider` in `config/app.php:225` (evidence: `source-233`)
- `service_provider` `Webkul\Notification\Providers\NotificationServiceProvider` in `config/app.php:226` (evidence: `source-234`)
- `service_provider` `Webkul\Payment\Providers\PaymentServiceProvider` in `config/app.php:227` (evidence: `source-235`)
- `service_provider` `Webkul\Paypal\Providers\PaypalServiceProvider` in `config/app.php:228` (evidence: `source-236`)
- `service_provider` `Webkul\Product\Providers\ProductServiceProvider` in `config/app.php:229` (evidence: `source-237`)
- `service_provider` `Webkul\Rule\Providers\RuleServiceProvider` in `config/app.php:230` (evidence: `source-238`)
- `service_provider` `Webkul\Sales\Providers\SalesServiceProvider` in `config/app.php:231` (evidence: `source-239`)
- `service_provider` `Webkul\Shipping\Providers\ShippingServiceProvider` in `config/app.php:232` (evidence: `source-240`)
- `service_provider` `Webkul\Shop\Providers\ShopServiceProvider` in `config/app.php:233` (evidence: `source-241`)
- `service_provider` `Webkul\Sitemap\Providers\SitemapServiceProvider` in `config/app.php:234` (evidence: `source-242`)
- `service_provider` `Webkul\SocialLogin\Providers\SocialLoginServiceProvider` in `config/app.php:235` (evidence: `source-243`)
- `service_provider` `Webkul\SocialShare\Providers\SocialShareServiceProvider` in `config/app.php:236` (evidence: `source-244`)
- `service_provider` `Webkul\Tax\Providers\TaxServiceProvider` in `config/app.php:237` (evidence: `source-245`)
- `service_provider` `Webkul\Theme\Providers\ThemeServiceProvider` in `config/app.php:238` (evidence: `source-246`)
- `service_provider` `Webkul\User\Providers\UserServiceProvider` in `config/app.php:239` (evidence: `source-247`)
- `facade_alias` `Webkul\Customer\Facades\Captcha` in `config/app.php:254` (evidence: `source-248`)
- `facade_alias` `Webkul\Checkout\Facades\Cart` in `config/app.php:255` (evidence: `source-249`)
- `facade_alias` `Konekt\Concord\Facades\Concord` in `config/app.php:256` (evidence: `source-250`)
- `facade_alias` `Webkul\Core\Facades\Core` in `config/app.php:257` (evidence: `source-251`)
- `facade_alias` `Maatwebsite\Excel\Facades\Excel` in `config/app.php:258` (evidence: `source-252`)
- `facade_alias` `Konekt\Concord\Facades\Helper` in `config/app.php:259` (evidence: `source-253`)
- `facade_alias` `Intervention\Image\Facades\Image` in `config/app.php:260` (evidence: `source-254`)
- `facade_alias` `Barryvdh\DomPDF\Facade\Pdf` in `config/app.php:261` (evidence: `source-255`)
- `facade_alias` `Webkul\Product\Facades\ProductImage` in `config/app.php:262` (evidence: `source-256`)
- `facade_alias` `Webkul\Product\Facades\ProductVideo` in `config/app.php:263` (evidence: `source-257`)
- `facade_alias` `Illuminate\Support\Facades\Redis` in `config/app.php:264` (evidence: `source-258`)
- `class_constant_access` `Webkul\Customer\Models\Customer` in `config/auth.php:24` (evidence: `source-259`)
- `class_constant_access` `Webkul\User\Models\Admin` in `config/auth.php:29` (evidence: `source-260`)
- `service_provider` `Webkul\Customer\Models\Customer` in `config/auth.php:24` (evidence: `source-261`)
- `service_provider` `Webkul\User\Models\Admin` in `config/auth.php:29` (evidence: `source-262`)
- `function_call` `base_path` in `config/breadcrumbs.php:40` (evidence: `source-263`)
- `class_constant_access` `Diglactic\Breadcrumbs\Manager` in `config/breadcrumbs.php:70` (evidence: `source-264`)
- `class_constant_access` `Diglactic\Breadcrumbs\Generator` in `config/breadcrumbs.php:73` (evidence: `source-265`)
- `function_call` `env` in `config/broadcasting.php:18` (evidence: `source-266`)
- `function_call` `env` in `config/broadcasting.php:34` (evidence: `source-267`)
- `function_call` `env` in `config/broadcasting.php:35` (evidence: `source-268`)
- `function_call` `env` in `config/broadcasting.php:36` (evidence: `source-269`)
- `function_call` `env` in `config/broadcasting.php:38` (evidence: `source-270`)
- `function_call` `env` in `config/cache.php:18` (evidence: `source-271`)
- `function_call` `storage_path` in `config/cache.php:49` (evidence: `source-272`)
- `function_call` `env` in `config/cache.php:54` (evidence: `source-273`)
- `function_call` `env` in `config/cache.php:56` (evidence: `source-274`)
- `function_call` `env` in `config/cache.php:57` (evidence: `source-275`)
- `function_call` `env` in `config/cache.php:64` (evidence: `source-276`)
- `function_call` `env` in `config/cache.php:65` (evidence: `source-277`)
- `function_call` `env` in `config/cache.php:73` (evidence: `source-278`)
- `function_call` `env` in `config/cache.php:89` (evidence: `source-279`)
- `static_call` `Illuminate\Support\Str` in `config/cache.php:91` (evidence: `source-280`)
- `function_call` `env` in `config/cache.php:91` (evidence: `source-281`)
- `class_constant_access` `Webkul\Core\CoreConvention` in `config/concord.php:5` (evidence: `source-282`)
- `class_constant_access` `Webkul\Admin\Providers\ModuleServiceProvider` in `config/concord.php:14` (evidence: `source-283`)
- `class_constant_access` `Webkul\Attribute\Providers\ModuleServiceProvider` in `config/concord.php:15` (evidence: `source-284`)
- `class_constant_access` `Webkul\CartRule\Providers\ModuleServiceProvider` in `config/concord.php:16` (evidence: `source-285`)
- `class_constant_access` `Webkul\CatalogRule\Providers\ModuleServiceProvider` in `config/concord.php:17` (evidence: `source-286`)
- `class_constant_access` `Webkul\Category\Providers\ModuleServiceProvider` in `config/concord.php:18` (evidence: `source-287`)
- `class_constant_access` `Webkul\Checkout\Providers\ModuleServiceProvider` in `config/concord.php:19` (evidence: `source-288`)
- `class_constant_access` `Webkul\Core\Providers\ModuleServiceProvider` in `config/concord.php:20` (evidence: `source-289`)
- `class_constant_access` `Webkul\CMS\Providers\ModuleServiceProvider` in `config/concord.php:21` (evidence: `source-290`)
- `class_constant_access` `Webkul\Customer\Providers\ModuleServiceProvider` in `config/concord.php:22` (evidence: `source-291`)
- `class_constant_access` `Webkul\DataGrid\Providers\ModuleServiceProvider` in `config/concord.php:23` (evidence: `source-292`)
- `class_constant_access` `Webkul\DataTransfer\Providers\ModuleServiceProvider` in `config/concord.php:24` (evidence: `source-293`)
- `class_constant_access` `Webkul\Inventory\Providers\ModuleServiceProvider` in `config/concord.php:25` (evidence: `source-294`)
- `class_constant_access` `Webkul\Marketing\Providers\ModuleServiceProvider` in `config/concord.php:26` (evidence: `source-295`)
- `class_constant_access` `Webkul\Notification\Providers\ModuleServiceProvider` in `config/concord.php:27` (evidence: `source-296`)
- `class_constant_access` `Webkul\Payment\Providers\ModuleServiceProvider` in `config/concord.php:28` (evidence: `source-297`)
- `class_constant_access` `Webkul\Paypal\Providers\ModuleServiceProvider` in `config/concord.php:29` (evidence: `source-298`)
- `class_constant_access` `Webkul\Product\Providers\ModuleServiceProvider` in `config/concord.php:30` (evidence: `source-299`)
- `class_constant_access` `Webkul\Rule\Providers\ModuleServiceProvider` in `config/concord.php:31` (evidence: `source-300`)
- `class_constant_access` `Webkul\Sales\Providers\ModuleServiceProvider` in `config/concord.php:32` (evidence: `source-301`)
- `class_constant_access` `Webkul\Shipping\Providers\ModuleServiceProvider` in `config/concord.php:33` (evidence: `source-302`)
- `class_constant_access` `Webkul\Shop\Providers\ModuleServiceProvider` in `config/concord.php:34` (evidence: `source-303`)
- `class_constant_access` `Webkul\SocialLogin\Providers\ModuleServiceProvider` in `config/concord.php:35` (evidence: `source-304`)
- `class_constant_access` `Webkul\Tax\Providers\ModuleServiceProvider` in `config/concord.php:36` (evidence: `source-305`)
- `class_constant_access` `Webkul\Theme\Providers\ModuleServiceProvider` in `config/concord.php:37` (evidence: `source-306`)
- `class_constant_access` `Webkul\User\Providers\ModuleServiceProvider` in `config/concord.php:38` (evidence: `source-307`)
- `class_constant_access` `Webkul\Sitemap\Providers\ModuleServiceProvider` in `config/concord.php:39` (evidence: `source-308`)
- `function_call` `env` in `config/database.php:16` (evidence: `source-309`)
- `function_call` `env` in `config/database.php:38` (evidence: `source-310`)
- `function_call` `database_path` in `config/database.php:38` (evidence: `source-311`)
- `function_call` `env` in `config/database.php:39` (evidence: `source-312`)
- `function_call` `env` in `config/database.php:44` (evidence: `source-313`)
- `function_call` `env` in `config/database.php:45` (evidence: `source-314`)
- `function_call` `env` in `config/database.php:46` (evidence: `source-315`)
- `function_call` `env` in `config/database.php:47` (evidence: `source-316`)
- `function_call` `env` in `config/database.php:48` (evidence: `source-317`)
- `function_call` `env` in `config/database.php:49` (evidence: `source-318`)
- `function_call` `env` in `config/database.php:52` (evidence: `source-319`)
- `function_call` `env` in `config/database.php:59` (evidence: `source-320`)
- `function_call` `env` in `config/database.php:60` (evidence: `source-321`)
- `function_call` `env` in `config/database.php:61` (evidence: `source-322`)
- `function_call` `env` in `config/database.php:62` (evidence: `source-323`)
- `function_call` `env` in `config/database.php:63` (evidence: `source-324`)
- `function_call` `env` in `config/database.php:65` (evidence: `source-325`)
- `function_call` `env` in `config/database.php:72` (evidence: `source-326`)
- `function_call` `env` in `config/database.php:73` (evidence: `source-327`)
- `function_call` `env` in `config/database.php:74` (evidence: `source-328`)
- `function_call` `env` in `config/database.php:75` (evidence: `source-329`)
- `function_call` `env` in `config/database.php:76` (evidence: `source-330`)
- `function_call` `env` in `config/database.php:112` (evidence: `source-331`)
- `function_call` `env` in `config/database.php:113` (evidence: `source-332`)
- `function_call` `env` in `config/database.php:114` (evidence: `source-333`)
- `function_call` `env` in `config/database.php:115` (evidence: `source-334`)
- `function_call` `env` in `config/database.php:119` (evidence: `source-335`)
- `function_call` `env` in `config/database.php:120` (evidence: `source-336`)
- `function_call` `env` in `config/database.php:121` (evidence: `source-337`)
- `function_call` `env` in `config/database.php:122` (evidence: `source-338`)
- `function_call` `env` in `config/database.php:126` (evidence: `source-339`)
- `function_call` `env` in `config/database.php:127` (evidence: `source-340`)
- `function_call` `env` in `config/database.php:128` (evidence: `source-341`)
- `function_call` `env` in `config/database.php:129` (evidence: `source-342`)
- `function_call` `env` in `config/elasticsearch.php:16` (evidence: `source-343`)
- `function_call` `env` in `config/elasticsearch.php:19` (evidence: `source-344`)
- `function_call` `env` in `config/elasticsearch.php:20` (evidence: `source-345`)
- `function_call` `env` in `config/elasticsearch.php:29` (evidence: `source-346`)
- `function_call` `env` in `config/elasticsearch.php:32` (evidence: `source-347`)
- `function_call` `env` in `config/elasticsearch.php:39` (evidence: `source-348`)
- `function_call` `env` in `config/elasticsearch.php:44` (evidence: `source-349`)
- `function_call` `env` in `config/elasticsearch.php:49` (evidence: `source-350`)
- `function_call` `env` in `config/elasticsearch.php:50` (evidence: `source-351`)
- `function_call` `env` in `config/filesystems.php:16` (evidence: `source-352`)
- `function_call` `env` in `config/filesystems.php:29` (evidence: `source-353`)
- `function_call` `storage_path` in `config/filesystems.php:48` (evidence: `source-354`)
- `function_call` `storage_path` in `config/filesystems.php:53` (evidence: `source-355`)
- `function_call` `storage_path` in `config/filesystems.php:58` (evidence: `source-356`)
- `function_call` `env` in `config/filesystems.php:59` (evidence: `source-357`)
- `function_call` `env` in `config/filesystems.php:65` (evidence: `source-358`)
- `function_call` `env` in `config/filesystems.php:66` (evidence: `source-359`)
- `function_call` `env` in `config/filesystems.php:67` (evidence: `source-360`)
- `function_call` `env` in `config/filesystems.php:68` (evidence: `source-361`)
- `function_call` `env` in `config/filesystems.php:69` (evidence: `source-362`)
- `function_call` `env` in `config/hashing.php:32` (evidence: `source-363`)
- `function_call` `storage_path` in `config/imagecache.php:33` (evidence: `source-364`)
- `function_call` `public_path` in `config/imagecache.php:34` (evidence: `source-365`)
- `namespace_import` `Monolog\Handler\StreamHandler` in `config/logging.php:3` (evidence: `source-366`)
- `function_call` `env` in `config/logging.php:18` (evidence: `source-367`)
- `function_call` `storage_path` in `config/logging.php:43` (evidence: `source-368`)
- `function_call` `storage_path` in `config/logging.php:49` (evidence: `source-369`)
- `function_call` `env` in `config/logging.php:56` (evidence: `source-370`)
- `class_constant_access` `Monolog\Handler\StreamHandler` in `config/logging.php:64` (evidence: `source-371`)
- `function_call` `env` in `config/mail.php:15` (evidence: `source-372`)
- `function_call` `env` in `config/mail.php:37` (evidence: `source-373`)
- `function_call` `env` in `config/mail.php:38` (evidence: `source-374`)
- `function_call` `env` in `config/mail.php:39` (evidence: `source-375`)
- `function_call` `env` in `config/mail.php:40` (evidence: `source-376`)
- `function_call` `env` in `config/mail.php:41` (evidence: `source-377`)
- `function_call` `env` in `config/mail.php:60` (evidence: `source-378`)
- `function_call` `env` in `config/mail.php:65` (evidence: `source-379`)
- `function_call` `env` in `config/mail.php:92` (evidence: `source-380`)
- `function_call` `env` in `config/mail.php:93` (evidence: `source-381`)
- `function_call` `env` in `config/mail.php:105` (evidence: `source-382`)
- `function_call` `env` in `config/mail.php:106` (evidence: `source-383`)
- `function_call` `env` in `config/mail.php:120` (evidence: `source-384`)
- `function_call` `env` in `config/mail.php:121` (evidence: `source-385`)
- `function_call` `resource_path` in `config/mail.php:138` (evidence: `source-386`)
- `function_call` `env` in `config/openai.php:15` (evidence: `source-387`)
- `function_call` `env` in `config/openai.php:16` (evidence: `source-388`)
- `function_call` `env` in `config/openai.php:27` (evidence: `source-389`)
- `function_call` `env` in `config/queue.php:16` (evidence: `source-390`)
- `function_call` `env` in `config/queue.php:53` (evidence: `source-391`)
- `function_call` `env` in `config/queue.php:54` (evidence: `source-392`)
- `function_call` `env` in `config/queue.php:55` (evidence: `source-393`)
- `function_call` `env` in `config/queue.php:56` (evidence: `source-394`)
- `function_call` `env` in `config/queue.php:57` (evidence: `source-395`)
- `function_call` `env` in `config/queue.php:82` (evidence: `source-396`)
- `function_call` `env` in `config/queue.php:83` (evidence: `source-397`)
- `class_constant_access` `League\Fractal\Serializer\DataArraySerializer` in `config/repository.php:37` (evidence: `source-398`)
- `function_call` `app` in `config/repository.php:275` (evidence: `source-399`)
- `function_call` `app` in `config/repository.php:277` (evidence: `source-400`)
- `function_call` `env` in `config/responsecache.php:7` (evidence: `source-401`)
- `class_constant_access` `Spatie\ResponseCache\CacheProfiles\CacheAllSuccessfulGetRequests` in `config/responsecache.php:16` (evidence: `source-402`)
- `function_call` `env` in `config/responsecache.php:23` (evidence: `source-403`)
- `function_call` `env` in `config/responsecache.php:24` (evidence: `source-404`)
- `function_call` `env` in `config/responsecache.php:31` (evidence: `source-405`)
- `function_call` `env` in `config/responsecache.php:38` (evidence: `source-406`)
- `function_call` `env` in `config/responsecache.php:44` (evidence: `source-407`)
- `function_call` `env` in `config/responsecache.php:52` (evidence: `source-408`)
- `function_call` `env` in `config/responsecache.php:58` (evidence: `source-409`)
- `function_call` `env` in `config/responsecache.php:65` (evidence: `source-410`)
- `class_constant_access` `Spatie\ResponseCache\Replacers\CsrfTokenReplacer` in `config/responsecache.php:72` (evidence: `source-411`)
- `class_constant_access` `Webkul\FPC\Hasher\DefaultHasher` in `config/responsecache.php:88` (evidence: `source-412`)
- `class_constant_access` `Spatie\ResponseCache\Serializers\DefaultSerializer` in `config/responsecache.php:93` (evidence: `source-413`)
- `namespace_import` `Laravel\Sanctum\Sanctum` in `config/sanctum.php:3` (evidence: `source-414`)
- `function_call` `explode` in `config/sanctum.php:18` (evidence: `source-415`)
- `function_call` `env` in `config/sanctum.php:18` (evidence: `source-416`)
- `function_call` `sprintf` in `config/sanctum.php:18` (evidence: `source-417`)
- `static_call` `Laravel\Sanctum\Sanctum` in `config/sanctum.php:21` (evidence: `source-418`)
- `class_constant_access` `App\Http\Middleware\VerifyCsrfToken` in `config/sanctum.php:63` (evidence: `source-419`)
- `class_constant_access` `App\Http\Middleware\EncryptCookies` in `config/sanctum.php:64` (evidence: `source-420`)
- `function_call` `env` in `config/services.php:18` (evidence: `source-421`)
- `function_call` `env` in `config/services.php:19` (evidence: `source-422`)
- `function_call` `env` in `config/services.php:23` (evidence: `source-423`)
- `function_call` `env` in `config/services.php:24` (evidence: `source-424`)
- `function_call` `env` in `config/services.php:25` (evidence: `source-425`)
- `function_call` `env` in `config/services.php:29` (evidence: `source-426`)
- `function_call` `env` in `config/services.php:36` (evidence: `source-427`)
- `function_call` `env` in `config/services.php:41` (evidence: `source-428`)
- `function_call` `env` in `config/services.php:43` (evidence: `source-429`)
- `class_constant_access` `App\User` in `config/services.php:48` (evidence: `source-430`)
- `function_call` `env` in `config/services.php:49` (evidence: `source-431`)
- `function_call` `env` in `config/services.php:50` (evidence: `source-432`)
- `function_call` `env` in `config/services.php:54` (evidence: `source-433`)
- `function_call` `env` in `config/services.php:55` (evidence: `source-434`)
- `function_call` `env` in `config/services.php:56` (evidence: `source-435`)
- `function_call` `env` in `config/services.php:60` (evidence: `source-436`)
- `function_call` `env` in `config/services.php:61` (evidence: `source-437`)
- `function_call` `env` in `config/services.php:62` (evidence: `source-438`)
- `function_call` `env` in `config/services.php:66` (evidence: `source-439`)
- `function_call` `env` in `config/services.php:67` (evidence: `source-440`)
- `function_call` `env` in `config/services.php:68` (evidence: `source-441`)
- `function_call` `env` in `config/services.php:72` (evidence: `source-442`)
- `function_call` `env` in `config/services.php:73` (evidence: `source-443`)
- `function_call` `env` in `config/services.php:74` (evidence: `source-444`)
- `function_call` `env` in `config/services.php:78` (evidence: `source-445`)
- `function_call` `env` in `config/services.php:79` (evidence: `source-446`)
- `function_call` `env` in `config/services.php:80` (evidence: `source-447`)
- `function_call` `env` in `config/session.php:19` (evidence: `source-448`)
- `function_call` `env` in `config/session.php:32` (evidence: `source-449`)
- `function_call` `storage_path` in `config/session.php:60` (evidence: `source-450`)
- `function_call` `env` in `config/session.php:73` (evidence: `source-451`)
- `function_call` `env` in `config/session.php:99` (evidence: `source-452`)
- `function_call` `env` in `config/session.php:125` (evidence: `source-453`)
- `static_call` `Illuminate\Support\Str` in `config/session.php:127` (evidence: `source-454`)
- `function_call` `env` in `config/session.php:127` (evidence: `source-455`)
- `function_call` `env` in `config/session.php:154` (evidence: `source-456`)
- `function_call` `env` in `config/session.php:167` (evidence: `source-457`)
- `namespace_import` `GuzzleHttp\RequestOptions` in `config/sitemap.php:3` (evidence: `source-458`)
- `namespace_import` `Spatie\Sitemap\Crawler\Profile` in `config/sitemap.php:4` (evidence: `source-459`)
- `class_constant_access` `GuzzleHttp\RequestOptions` in `config/sitemap.php:19` (evidence: `source-460`)
- `class_constant_access` `GuzzleHttp\RequestOptions` in `config/sitemap.php:25` (evidence: `source-461`)
- `class_constant_access` `GuzzleHttp\RequestOptions` in `config/sitemap.php:30` (evidence: `source-462`)
- `class_constant_access` `GuzzleHttp\RequestOptions` in `config/sitemap.php:35` (evidence: `source-463`)
- `class_constant_access` `Spatie\Sitemap\Crawler\Profile` in `config/sitemap.php:55` (evidence: `source-464`)
- `class_constant_access` `Astrotomic\Translatable\Validation\RuleFactory` in `config/translatable.php:145` (evidence: `source-465`)
- `function_call` `resource_path` in `config/view.php:27` (evidence: `source-466`)
- `function_call` `realpath` in `config/view.php:41` (evidence: `source-467`)
- `function_call` `storage_path` in `config/view.php:41` (evidence: `source-468`)
- `class_constant_access` `Shetabit\Visitor\Drivers\JenssegersAgent` in `config/visitor.php:34` (evidence: `source-469`)
- `class_constant_access` `Shetabit\Visitor\Drivers\UAParser` in `config/visitor.php:35` (evidence: `source-470`)
- `namespace_import` `App\Models\User` in `database/factories/UserFactory.php:5` (evidence: `source-471`)
- `namespace_import` `Illuminate\Database\Eloquent\Factories\Factory` in `database/factories/UserFactory.php:6` (evidence: `source-472`)
- `namespace_import` `Illuminate\Support\Str` in `database/factories/UserFactory.php:7` (evidence: `source-473`)
- `inheritance` `Illuminate\Database\Eloquent\Factories\Factory` in `database/factories/UserFactory.php:9` (evidence: `source-474`)
- `class_constant_access` `App\Models\User` in `database/factories/UserFactory.php:16` (evidence: `source-475`)
- `function_call` `preg_replace` in `database/factories/UserFactory.php:26` (evidence: `source-476`)
- `function_call` `now` in `database/factories/UserFactory.php:28` (evidence: `source-477`)
- `static_call` `Illuminate\Support\Str` in `database/factories/UserFactory.php:30` (evidence: `source-478`)
- `namespace_import` `Illuminate\Database\Migrations\Migration` in `database/migrations/2014_10_12_000000_create_users_table.php:3` (evidence: `source-479`)
- `namespace_import` `Illuminate\Database\Schema\Blueprint` in `database/migrations/2014_10_12_000000_create_users_table.php:4` (evidence: `source-480`)
- `namespace_import` `Illuminate\Support\Facades\Schema` in `database/migrations/2014_10_12_000000_create_users_table.php:5` (evidence: `source-481`)
- `inheritance` `Illuminate\Database\Migrations\Migration` in `database/migrations/2014_10_12_000000_create_users_table.php:7` (evidence: `source-482`)
- `static_call` `Illuminate\Support\Facades\Schema` in `database/migrations/2014_10_12_000000_create_users_table.php:16` (evidence: `source-483`)
- `static_call` `Illuminate\Support\Facades\Schema` in `database/migrations/2014_10_12_000000_create_users_table.php:33` (evidence: `source-484`)
- `namespace_import` `Illuminate\Database\Migrations\Migration` in `database/migrations/2014_10_12_100000_create_password_resets_table.php:3` (evidence: `source-485`)
- `namespace_import` `Illuminate\Database\Schema\Blueprint` in `database/migrations/2014_10_12_100000_create_password_resets_table.php:4` (evidence: `source-486`)
- `namespace_import` `Illuminate\Support\Facades\Schema` in `database/migrations/2014_10_12_100000_create_password_resets_table.php:5` (evidence: `source-487`)
- `inheritance` `Illuminate\Database\Migrations\Migration` in `database/migrations/2014_10_12_100000_create_password_resets_table.php:7` (evidence: `source-488`)
- `static_call` `Illuminate\Support\Facades\Schema` in `database/migrations/2014_10_12_100000_create_password_resets_table.php:16` (evidence: `source-489`)
- `static_call` `Illuminate\Support\Facades\Schema` in `database/migrations/2014_10_12_100000_create_password_resets_table.php:30` (evidence: `source-490`)
- `namespace_import` `Illuminate\Database\Migrations\Migration` in `database/migrations/2019_12_14_000001_create_personal_access_tokens_table.php:3` (evidence: `source-491`)
- `namespace_import` `Illuminate\Database\Schema\Blueprint` in `database/migrations/2019_12_14_000001_create_personal_access_tokens_table.php:4` (evidence: `source-492`)
- `namespace_import` `Illuminate\Support\Facades\Schema` in `database/migrations/2019_12_14_000001_create_personal_access_tokens_table.php:5` (evidence: `source-493`)
- `inheritance` `Illuminate\Database\Migrations\Migration` in `database/migrations/2019_12_14_000001_create_personal_access_tokens_table.php:7` (evidence: `source-494`)
- `static_call` `Illuminate\Support\Facades\Schema` in `database/migrations/2019_12_14_000001_create_personal_access_tokens_table.php:14` (evidence: `source-495`)
- `static_call` `Illuminate\Support\Facades\Schema` in `database/migrations/2019_12_14_000001_create_personal_access_tokens_table.php:31` (evidence: `source-496`)
- `namespace_import` `Illuminate\Database\Migrations\Migration` in `database/migrations/2020_12_27_121950_create_jobs_table.php:3` (evidence: `source-497`)
- `namespace_import` `Illuminate\Database\Schema\Blueprint` in `database/migrations/2020_12_27_121950_create_jobs_table.php:4` (evidence: `source-498`)
- `namespace_import` `Illuminate\Support\Facades\Schema` in `database/migrations/2020_12_27_121950_create_jobs_table.php:5` (evidence: `source-499`)
- `inheritance` `Illuminate\Database\Migrations\Migration` in `database/migrations/2020_12_27_121950_create_jobs_table.php:7` (evidence: `source-500`)
- `static_call` `Illuminate\Support\Facades\Schema` in `database/migrations/2020_12_27_121950_create_jobs_table.php:16` (evidence: `source-501`)
- `static_call` `Illuminate\Support\Facades\Schema` in `database/migrations/2020_12_27_121950_create_jobs_table.php:34` (evidence: `source-502`)
- `namespace_import` `Illuminate\Database\Migrations\Migration` in `database/migrations/2022_03_15_160510_create_failed_jobs_table.php:3` (evidence: `source-503`)
- `namespace_import` `Illuminate\Database\Schema\Blueprint` in `database/migrations/2022_03_15_160510_create_failed_jobs_table.php:4` (evidence: `source-504`)
- `namespace_import` `Illuminate\Support\Facades\Schema` in `database/migrations/2022_03_15_160510_create_failed_jobs_table.php:5` (evidence: `source-505`)
- `inheritance` `Illuminate\Database\Migrations\Migration` in `database/migrations/2022_03_15_160510_create_failed_jobs_table.php:7` (evidence: `source-506`)
- `static_call` `Illuminate\Support\Facades\Schema` in `database/migrations/2022_03_15_160510_create_failed_jobs_table.php:16` (evidence: `source-507`)
- `static_call` `Illuminate\Support\Facades\Schema` in `database/migrations/2022_03_15_160510_create_failed_jobs_table.php:34` (evidence: `source-508`)
- `namespace_import` `Illuminate\Database\Migrations\Migration` in `database/migrations/2022_10_04_144444_create_job_batches_table.php:3` (evidence: `source-509`)
- `namespace_import` `Illuminate\Database\Schema\Blueprint` in `database/migrations/2022_10_04_144444_create_job_batches_table.php:4` (evidence: `source-510`)
- `namespace_import` `Illuminate\Support\Facades\Schema` in `database/migrations/2022_10_04_144444_create_job_batches_table.php:5` (evidence: `source-511`)
- `inheritance` `Illuminate\Database\Migrations\Migration` in `database/migrations/2022_10_04_144444_create_job_batches_table.php:7` (evidence: `source-512`)
- `static_call` `Illuminate\Support\Facades\Schema` in `database/migrations/2022_10_04_144444_create_job_batches_table.php:16` (evidence: `source-513`)
- `static_call` `Illuminate\Support\Facades\Schema` in `database/migrations/2022_10_04_144444_create_job_batches_table.php:37` (evidence: `source-514`)
- `namespace_import` `Illuminate\Database\Migrations\Migration` in `database/migrations/2023_10_05_163612_create_visits_table.php:3` (evidence: `source-515`)
- `namespace_import` `Illuminate\Database\Schema\Blueprint` in `database/migrations/2023_10_05_163612_create_visits_table.php:4` (evidence: `source-516`)
- `namespace_import` `Illuminate\Support\Facades\Schema` in `database/migrations/2023_10_05_163612_create_visits_table.php:5` (evidence: `source-517`)
- `inheritance` `Illuminate\Database\Migrations\Migration` in `database/migrations/2023_10_05_163612_create_visits_table.php:7` (evidence: `source-518`)
- `static_call` `Illuminate\Support\Facades\Schema` in `database/migrations/2023_10_05_163612_create_visits_table.php:16` (evidence: `source-519`)
- `function_call` `config` in `database/migrations/2023_10_05_163612_create_visits_table.php:16` (evidence: `source-520`)
- `static_call` `Illuminate\Support\Facades\Schema` in `database/migrations/2023_10_05_163612_create_visits_table.php:42` (evidence: `source-521`)
- `function_call` `config` in `database/migrations/2023_10_05_163612_create_visits_table.php:42` (evidence: `source-522`)
- `config_reference` `visitor.table_name` in `database/migrations/2023_10_05_163612_create_visits_table.php:16` (evidence: `source-523`)
- `config_reference` `visitor.table_name` in `database/migrations/2023_10_05_163612_create_visits_table.php:42` (evidence: `source-524`)
- `namespace_import` `Illuminate\Database\Seeder` in `database/seeders/DatabaseSeeder.php:5` (evidence: `source-525`)
- `namespace_import` `Webkul\Installer\Database\Seeders\DatabaseSeeder` in `database/seeders/DatabaseSeeder.php:6` (evidence: `source-526`)
- `inheritance` `Illuminate\Database\Seeder` in `database/seeders/DatabaseSeeder.php:8` (evidence: `source-527`)
- `class_constant_access` `Webkul\Installer\Database\Seeders\DatabaseSeeder` in `database/seeders/DatabaseSeeder.php:17` (evidence: `source-528`)
- `namespace_import` `Diglactic\Breadcrumbs\Breadcrumbs` in `routes/breadcrumbs.php:3` (evidence: `source-529`)
- `namespace_import` `Diglactic\Breadcrumbs\Generator` in `routes/breadcrumbs.php:4` (evidence: `source-530`)
- `static_call` `Diglactic\Breadcrumbs\Breadcrumbs` in `routes/breadcrumbs.php:7` (evidence: `source-531`)
- `function_call` `trans` in `routes/breadcrumbs.php:8` (evidence: `source-532`)
- `function_call` `route` in `routes/breadcrumbs.php:8` (evidence: `source-533`)
- `static_call` `Diglactic\Breadcrumbs\Breadcrumbs` in `routes/breadcrumbs.php:12` (evidence: `source-534`)
- `function_call` `trans` in `routes/breadcrumbs.php:14` (evidence: `source-535`)
- `function_call` `route` in `routes/breadcrumbs.php:14` (evidence: `source-536`)
- `static_call` `Diglactic\Breadcrumbs\Breadcrumbs` in `routes/breadcrumbs.php:18` (evidence: `source-537`)
- `function_call` `trans` in `routes/breadcrumbs.php:20` (evidence: `source-538`)
- `function_call` `route` in `routes/breadcrumbs.php:20` (evidence: `source-539`)
- `static_call` `Diglactic\Breadcrumbs\Breadcrumbs` in `routes/breadcrumbs.php:24` (evidence: `source-540`)
- `function_call` `trans` in `routes/breadcrumbs.php:26` (evidence: `source-541`)
- `function_call` `route` in `routes/breadcrumbs.php:26` (evidence: `source-542`)
- `static_call` `Diglactic\Breadcrumbs\Breadcrumbs` in `routes/breadcrumbs.php:30` (evidence: `source-543`)
- `function_call` `trans` in `routes/breadcrumbs.php:32` (evidence: `source-544`)
- `function_call` `route` in `routes/breadcrumbs.php:32` (evidence: `source-545`)
- `static_call` `Diglactic\Breadcrumbs\Breadcrumbs` in `routes/breadcrumbs.php:36` (evidence: `source-546`)
- `function_call` `trans` in `routes/breadcrumbs.php:38` (evidence: `source-547`)
- `function_call` `route` in `routes/breadcrumbs.php:38` (evidence: `source-548`)
- `static_call` `Diglactic\Breadcrumbs\Breadcrumbs` in `routes/breadcrumbs.php:42` (evidence: `source-549`)
- `function_call` `trans` in `routes/breadcrumbs.php:44` (evidence: `source-550`)
- `function_call` `route` in `routes/breadcrumbs.php:44` (evidence: `source-551`)
- `static_call` `Diglactic\Breadcrumbs\Breadcrumbs` in `routes/breadcrumbs.php:48` (evidence: `source-552`)
- `function_call` `trans` in `routes/breadcrumbs.php:50` (evidence: `source-553`)
- `function_call` `route` in `routes/breadcrumbs.php:50` (evidence: `source-554`)
- `static_call` `Diglactic\Breadcrumbs\Breadcrumbs` in `routes/breadcrumbs.php:53` (evidence: `source-555`)
- `function_call` `trans` in `routes/breadcrumbs.php:55` (evidence: `source-556`)
- `function_call` `route` in `routes/breadcrumbs.php:55` (evidence: `source-557`)
- `static_call` `Diglactic\Breadcrumbs\Breadcrumbs` in `routes/breadcrumbs.php:59` (evidence: `source-558`)
- `function_call` `trans` in `routes/breadcrumbs.php:61` (evidence: `source-559`)
- `function_call` `route` in `routes/breadcrumbs.php:61` (evidence: `source-560`)
- `static_call` `Diglactic\Breadcrumbs\Breadcrumbs` in `routes/breadcrumbs.php:65` (evidence: `source-561`)
- `function_call` `trans` in `routes/breadcrumbs.php:67` (evidence: `source-562`)
- `function_call` `route` in `routes/breadcrumbs.php:67` (evidence: `source-563`)
- `static_call` `Diglactic\Breadcrumbs\Breadcrumbs` in `routes/breadcrumbs.php:71` (evidence: `source-564`)
- `function_call` `trans` in `routes/breadcrumbs.php:73` (evidence: `source-565`)
- `function_call` `route` in `routes/breadcrumbs.php:73` (evidence: `source-566`)
- `static_call` `Diglactic\Breadcrumbs\Breadcrumbs` in `routes/breadcrumbs.php:77` (evidence: `source-567`)
- `function_call` `trans` in `routes/breadcrumbs.php:79` (evidence: `source-568`)
- `function_call` `route` in `routes/breadcrumbs.php:79` (evidence: `source-569`)
- `static_call` `Diglactic\Breadcrumbs\Breadcrumbs` in `routes/breadcrumbs.php:83` (evidence: `source-570`)
- `function_call` `trans` in `routes/breadcrumbs.php:85` (evidence: `source-571`)
- `function_call` `route` in `routes/breadcrumbs.php:85` (evidence: `source-572`)
- `static_call` `Diglactic\Breadcrumbs\Breadcrumbs` in `routes/breadcrumbs.php:89` (evidence: `source-573`)
- `function_call` `trans` in `routes/breadcrumbs.php:91` (evidence: `source-574`)
- `function_call` `route` in `routes/breadcrumbs.php:91` (evidence: `source-575`)
- `static_call` `Diglactic\Breadcrumbs\Breadcrumbs` in `routes/breadcrumbs.php:95` (evidence: `source-576`)
- `function_call` `route` in `routes/breadcrumbs.php:97` (evidence: `source-577`)
- `static_call` `Broadcast` in `routes/channels.php:14` (evidence: `source-578`)
- `namespace_import` `Illuminate\Foundation\Inspiring` in `routes/console.php:3` (evidence: `source-579`)
- `static_call` `Artisan` in `routes/console.php:16` (evidence: `source-580`)
- `static_call` `Illuminate\Foundation\Inspiring` in `routes/console.php:17` (evidence: `source-581`)
- `namespace_import` `Illuminate\Contracts\Console\Kernel` in `tests/CreatesApplication.php:5` (evidence: `source-582`)
- `namespace_import` `Illuminate\Foundation\Application` in `tests/CreatesApplication.php:6` (evidence: `source-583`)
- `class_constant_access` `Illuminate\Contracts\Console\Kernel` in `tests/CreatesApplication.php:17` (evidence: `source-584`)
- `function_call` `uses` in `tests/Pest.php:14` (evidence: `source-585`)
- `class_constant_access` `Webkul\Admin\Tests\AdminTestCase` in `tests/Pest.php:14` (evidence: `source-586`)
- `function_call` `uses` in `tests/Pest.php:15` (evidence: `source-587`)
- `class_constant_access` `Webkul\Core\Tests\CoreTestCase` in `tests/Pest.php:15` (evidence: `source-588`)
- `function_call` `uses` in `tests/Pest.php:16` (evidence: `source-589`)
- `class_constant_access` `Webkul\DataGrid\Tests\DataGridTestCase` in `tests/Pest.php:16` (evidence: `source-590`)
- `function_call` `uses` in `tests/Pest.php:17` (evidence: `source-591`)
- `class_constant_access` `Webkul\Shop\Tests\ShopTestCase` in `tests/Pest.php:17` (evidence: `source-592`)
- `function_call` `expect` in `tests/Pest.php:30` (evidence: `source-593`)
- `namespace_import` `Illuminate\Foundation\Testing\DatabaseTransactions` in `tests/TestCase.php:5` (evidence: `source-594`)
- `namespace_import` `Illuminate\Foundation\Testing\TestCase` in `tests/TestCase.php:6` (evidence: `source-595`)
- `inheritance` `Illuminate\Foundation\Testing\TestCase` in `tests/TestCase.php:8` (evidence: `source-596`)
- `trait_reference` `Tests\CreatesApplication` in `tests/TestCase.php:10` (evidence: `source-597`)
- `trait_reference` `Illuminate\Foundation\Testing\DatabaseTransactions` in `tests/TestCase.php:10` (evidence: `source-598`)

## Actionable Source Impact
- `source-impact-b36c59766e3ff74375a6` `medium` impact for `laravel/framework` (`exact` ownership; `framework_rule`; stage references: `direct-final only`): The usage is referenced by active laravel compatibility guidance. Composer autoload metadata assigns the symbol to laravel/framework. (evidence: `source-89`, `laravel-request-forgery-guidance-1`, `ownership-1`)
  - `inheritance` `Illuminate\Foundation\Http\Middleware\VerifyCsrfToken` in `app/Http/Middleware/VerifyCsrfToken.php:7` (evidence: `source-89`)

## Framework Findings
- `laravel` `high`: Update the root laravel/framework constraint from `^10.0` to a constraint compatible with Laravel 13. (evidence: `laravel-framework-constraint-1`)
  - applies to hops: `12 -> 13`
- `laravel` `high`: Update or replace incompatible illuminate/support constraints before targeting Laravel 11: astrotomic/laravel-translatable, barryvdh/laravel-debugbar, barryvdh/laravel-dompdf, kalnoy/nestedset, maatwebsite/excel, prettus/l5-repository, prettus/laravel-validation, shetabit/visitor, spatie/laravel-responsecache, spatie/laravel-sitemap. (evidence: `old-illuminate-consumer-1`, `old-illuminate-consumer-2`, `old-illuminate-consumer-3`, `old-illuminate-consumer-4`, `old-illuminate-consumer-5`, `old-illuminate-consumer-6`, `old-illuminate-consumer-7`, `old-illuminate-consumer-8`, `old-illuminate-consumer-9`, `old-illuminate-consumer-10`)
  - applies to hops: `10 -> 11`
- `laravel` `high`: Update or replace incompatible illuminate/support constraints before targeting Laravel 12: konekt/concord, laravel/socialite, laravel/tinker, laravel/ui, spatie/laravel-ignition. (evidence: `old-illuminate-consumer-11`, `old-illuminate-consumer-12`, `old-illuminate-consumer-13`, `old-illuminate-consumer-14`, `old-illuminate-consumer-15`)
  - applies to hops: `11 -> 12`
- `laravel` `medium`: nunomaduro/collision v7.10.0 is outside the encoded Laravel 11 review range `^8.1`; review its upgrade or replacement. (evidence: `laravel-package-nunomaduro_collision-1`, `laravel-package-guidance-1`)
  - applies to hops: `10 -> 11`
- `laravel` `high`: laravel/sanctum v3.3.3 is outside the encoded Laravel 11 review range `^4.0`; review its upgrade or replacement. (evidence: `laravel-package-laravel_sanctum-1`, `laravel-package-guidance-2`)
  - applies to hops: `10 -> 11`
- `laravel` `medium`: phpunit/phpunit 10.5.5 is outside the encoded Laravel 11 review range `^10.5.35|^11.0.1|^12.0.1`; review its upgrade or replacement. (evidence: `laravel-package-phpunit_phpunit-1`, `laravel-package-guidance-3`)
  - applies to hops: `10 -> 11`
- `laravel` `low`: Review and remove doctrine/dbal if it was only installed for Laravel schema operations; Laravel 11 no longer depends on it. (evidence: `laravel-advisory-doctrine_dbal-1`, `laravel-package-advisory-1`)
  - applies to hops: `10 -> 11`
- `laravel` `high`: Publish the laravel/sanctum migrations before deploying the Laravel 11 upgrade; this package no longer loads its migrations automatically. (evidence: `laravel-advisory-laravel_sanctum-1`, `laravel-package-advisory-2`)
  - applies to hops: `10 -> 11`
- `laravel` `high`: phpunit/phpunit 10.5.5 is outside the encoded Laravel 12 review range `^10.5.35|^11.0|^12.0.1`; review its upgrade or replacement. (evidence: `laravel-package-phpunit_phpunit-2`, `laravel-package-guidance-4`)
  - applies to hops: `11 -> 12`
- `laravel` `high`: pestphp/pest v2.31.0 is outside the encoded Laravel 12 review range `^3.0|^4.0`; review its upgrade or replacement. (evidence: `laravel-package-pestphp_pest-1`, `laravel-package-guidance-5`)
  - applies to hops: `11 -> 12`
- `laravel` `medium`: nesbot/carbon 2.72.1 is outside the encoded Laravel 12 review range `^3.0`; review its upgrade or replacement. (evidence: `laravel-package-nesbot_carbon-1`, `laravel-package-guidance-6`)
  - applies to hops: `11 -> 12`
- `laravel` `medium`: nunomaduro/collision v7.10.0 is outside the encoded Laravel 12 review range `^8.6`; review its upgrade or replacement. (evidence: `laravel-package-nunomaduro_collision-2`, `laravel-package-guidance-7`)
  - applies to hops: `11 -> 12`
- `laravel` `high`: laravel/tinker v2.9.0 is outside the encoded Laravel 13 review range `^3.0`; review its upgrade or replacement. (evidence: `laravel-package-laravel_tinker-1`, `laravel-package-guidance-8`)
  - applies to hops: `12 -> 13`
- `laravel` `high`: phpunit/phpunit 10.5.5 is outside the encoded Laravel 13 review range `^11.5.50|^12.0|^13.0.3`; review its upgrade or replacement. (evidence: `laravel-package-phpunit_phpunit-3`, `laravel-package-guidance-9`)
  - applies to hops: `12 -> 13`
- `laravel` `high`: pestphp/pest v2.31.0 is outside the encoded Laravel 13 review range `^4.0|^5.0`; review its upgrade or replacement. (evidence: `laravel-package-pestphp_pest-2`, `laravel-package-guidance-10`)
  - applies to hops: `12 -> 13`
- `laravel` `medium`: nunomaduro/collision v7.10.0 is outside the encoded Laravel 13 review range `^8.6`; review its upgrade or replacement. (evidence: `laravel-package-nunomaduro_collision-3`, `laravel-package-guidance-11`)
  - applies to hops: `12 -> 13`
- `laravel` `medium`: Review 1 detected direct reference to VerifyCsrfToken or ValidateCsrfToken for PreventRequestForgery when targeting Laravel 13; deprecated aliases remain available. (evidence: `laravel-request-forgery-guidance-1`, `source-89`)
  - applies to hops: `12 -> 13`

## Staged Plan
1. **laravel-10-to-11** — Stop at laravel-10-to-11; its transition is not proved and must be rerun.; executed stage `laravel-10-to-11` (evidence: `stage-plan-1`, `laravel-stage-target-1`, `laravel-stage-remediation-2`, `laravel-stage-remediation-1`, `laravel-stage-remediation-3`, `stage-attempt-1`, `stage-root-change-1`, `stage-attempt-2`, `stage-root-change-2`, `stage-root-change-3`, `stage-attempt-3`, `stage-root-change-4`, `stage-root-change-5`, `stage-root-change-6`, `stage-root-change-7`, `old-illuminate-consumer-1`, `old-illuminate-consumer-2`, `old-illuminate-consumer-3`, `old-illuminate-consumer-4`, `old-illuminate-consumer-5`, `old-illuminate-consumer-6`, `old-illuminate-consumer-7`, `old-illuminate-consumer-8`, `old-illuminate-consumer-9`, `old-illuminate-consumer-10`, `laravel-package-nunomaduro_collision-1`, `laravel-package-guidance-1`, `laravel-package-laravel_sanctum-1`, `laravel-package-guidance-2`, `laravel-package-phpunit_phpunit-1`, `laravel-package-guidance-3`, `laravel-advisory-doctrine_dbal-1`, `laravel-package-advisory-1`, `laravel-advisory-laravel_sanctum-1`, `laravel-package-advisory-2`, `lock-metadata-3`, `lock-metadata-5`, `lock-metadata-7`, `lock-metadata-4`, `lock-metadata-6`, `lock-metadata-8`, `solver-6`, `solver-7`, `solver-8`)
   - [laravel-10-to-11] Resolve every active blocker and rerun this complete stage; do not advance.
   - [laravel-10-to-11] Replace or remove `intervention/imagecache`.
   - [laravel-10-to-11] Replace or remove `paypal/paypal-checkout-sdk`.
   - [laravel-10-to-11] Upgrade or replace `diglactic/laravel-breadcrumbs`.
   - [laravel-10-to-11] Choose a `laravel/framework` version compatible with the transitive constraint.
   - [laravel-10-to-11] Upgrade or replace `openai-php/laravel`.
   - [laravel-10-to-11] Upgrade or replace `laravel/sanctum`.
   - [laravel-10-to-11] Choose a `illuminate/console` version compatible with the transitive constraint.
   - [laravel-10-to-11] Remove or replace `nunomaduro/collision`.
   - [laravel-10-to-11] Choose versions whose replace/provide rules can coexist.
   - [laravel-10-to-11] Remove or replace `pestphp/pest`.

## Risk And Effort
- Risk: `high`
- Risk drivers:
  - No successful direct target resolution was observed; the risk grade is not a verified low-risk conclusion.
  - Assessment incomplete: some metadata, source, adapter, or input checks were unavailable; review uncertainties before interpreting the risk grade.
  - Staged assessment is incomplete; skipped or unknown transitions have no verified compatibility conclusion.
  - Risk level grades observed dependency, framework, and source findings only; it does not verify application runtime safety.
  - Composer resolution is blocked.
  - Abandoned packages require replacement or removal.
  - Framework compatibility findings require review.
  - Executed stage laravel-10-to-11 retains an active Composer blocker.
- Effort: `6-32` hours (low confidence)
- Effort components:
  - `dependency_resolution`: `3-8` hours
  - `source_changes`: `1-16` hours
  - `tests_and_debugging`: `2-8` hours
- Effort assumptions:
  - Hours are an uncalibrated planning heuristic for reported dependency, source-change, and test/debugging work, not a project quote.
  - Unobserved migration, deployment, runtime failures, and business validation work are excluded.
  - The range cannot price an unselected dependency transition.
  - Work in unobserved inputs is excluded from the hour range.
  - The range does not price unexecuted staged transitions.
  - Aggregate effort counts each exact package transition, framework finding, and source occurrence once; scenario and repeated-hop counts are excluded.

## Test Guidance
- **composer-validation** (`required`): Validate the edited Composer manifest before dependency installation. Command: `composer validate --strict`.
- **project-test-suite** (`required`): Identify and run the project test suite; no Composer test script was detected. Command: project-specific command required.
- **platform-requirements** (`required`): Confirm the installed dependencies satisfy PHP 8.3.0 and the deployment extensions. Command: `composer check-platform-reqs`.
- **focused-regressions** (`recommended`): Add or run focused regression coverage for the reported source and framework findings. Command: project-specific command required.

## Uncertainties
- Locked package "barryvdh/laravel-debugbar" files mapping was unavailable, so its symbols could not be indexed.
- Locked package "dompdf/dompdf" classmap mapping was unavailable, so its symbols could not be indexed.
- Locked package "ezyang/htmlpurifier" files mapping was unavailable, so its symbols could not be indexed.
- Locked package "guzzlehttp/guzzle" files mapping was unavailable, so its symbols could not be indexed.
- Locked package "hamcrest/hamcrest-php" classmap mapping was unavailable, so its symbols could not be indexed.
- Locked package "konekt/concord" files mapping was unavailable, so its symbols could not be indexed.
- Locked package "laminas/laminas-diactoros" files mapping was unavailable, so its symbols could not be indexed.
- Locked package "laravel/framework" files mapping was unavailable, so its symbols could not be indexed.
- Locked package "laravel/prompts" files mapping was unavailable, so its symbols could not be indexed.
- Locked package "league/flysystem-local" autoload.psr-4 contains a dynamic or unsupported mapping and could not be indexed completely.
- Locked package "mobiledetect/mobiledetectlib" classmap mapping was unavailable, so its symbols could not be indexed.
- Locked package "mockery/mockery" files mapping was unavailable, so its symbols could not be indexed.
- Locked package "mpdf/mpdf" files mapping was unavailable, so its symbols could not be indexed.
- Locked package "myclabs/deep-copy" files mapping was unavailable, so its symbols could not be indexed.
- Locked package "nette/schema" classmap mapping was unavailable, so its symbols could not be indexed.
- Locked package "nette/utils" classmap mapping was unavailable, so its symbols could not be indexed.
- Locked package "nunomaduro/collision" files mapping was unavailable, so its symbols could not be indexed.
- Locked package "nunomaduro/termwind" files mapping was unavailable, so its symbols could not be indexed.
- Locked package "openai-php/client" files mapping was unavailable, so its symbols could not be indexed.
- Locked package "opis/closure" files mapping was unavailable, so its symbols could not be indexed.
- Locked package "paragonie/sodium_compat" files mapping was unavailable, so its symbols could not be indexed.
- Locked package "pestphp/pest" files mapping was unavailable, so its symbols could not be indexed.
- Locked package "pestphp/pest-plugin-arch" files mapping was unavailable, so its symbols could not be indexed.
- Locked package "pestphp/pest-plugin-laravel" files mapping was unavailable, so its symbols could not be indexed.
- Locked package "phar-io/manifest" classmap mapping was unavailable, so its symbols could not be indexed.
- Locked package "phar-io/version" classmap mapping was unavailable, so its symbols could not be indexed.
- Locked package "phpunit/php-code-coverage" classmap mapping was unavailable, so its symbols could not be indexed.
- Locked package "phpunit/php-file-iterator" classmap mapping was unavailable, so its symbols could not be indexed.
- Locked package "phpunit/php-invoker" classmap mapping was unavailable, so its symbols could not be indexed.
- Locked package "phpunit/php-text-template" classmap mapping was unavailable, so its symbols could not be indexed.
- Locked package "phpunit/php-timer" classmap mapping was unavailable, so its symbols could not be indexed.
- Locked package "phpunit/phpunit" classmap mapping was unavailable, so its symbols could not be indexed.
- Locked package "phpunit/phpunit" files mapping was unavailable, so its symbols could not be indexed.
- Locked package "psy/psysh" files mapping was unavailable, so its symbols could not be indexed.
- Locked package "ralouphie/getallheaders" files mapping was unavailable, so its symbols could not be indexed.
- Locked package "ramsey/uuid" files mapping was unavailable, so its symbols could not be indexed.
- Locked package "sebastian/cli-parser" classmap mapping was unavailable, so its symbols could not be indexed.
- Locked package "sebastian/code-unit" classmap mapping was unavailable, so its symbols could not be indexed.
- Locked package "sebastian/code-unit-reverse-lookup" classmap mapping was unavailable, so its symbols could not be indexed.
- Locked package "sebastian/comparator" classmap mapping was unavailable, so its symbols could not be indexed.
- Locked package "sebastian/complexity" classmap mapping was unavailable, so its symbols could not be indexed.
- Locked package "sebastian/diff" classmap mapping was unavailable, so its symbols could not be indexed.
- Locked package "sebastian/environment" classmap mapping was unavailable, so its symbols could not be indexed.
- Locked package "sebastian/exporter" classmap mapping was unavailable, so its symbols could not be indexed.
- Locked package "sebastian/global-state" classmap mapping was unavailable, so its symbols could not be indexed.
- Locked package "sebastian/lines-of-code" classmap mapping was unavailable, so its symbols could not be indexed.
- Locked package "sebastian/object-enumerator" classmap mapping was unavailable, so its symbols could not be indexed.
- Locked package "sebastian/object-reflector" classmap mapping was unavailable, so its symbols could not be indexed.
- Locked package "sebastian/recursion-context" classmap mapping was unavailable, so its symbols could not be indexed.
- Locked package "sebastian/type" classmap mapping was unavailable, so its symbols could not be indexed.
- Locked package "sebastian/version" classmap mapping was unavailable, so its symbols could not be indexed.
- Locked package "shetabit/visitor" files mapping was unavailable, so its symbols could not be indexed.
- Locked package "spatie/flare-client-php" files mapping was unavailable, so its symbols could not be indexed.
- Locked package "spatie/laravel-ignition" files mapping was unavailable, so its symbols could not be indexed.
- Locked package "symfony/console" autoload.psr-4 contains a dynamic or unsupported mapping and could not be indexed completely.
- Locked package "symfony/css-selector" autoload.psr-4 contains a dynamic or unsupported mapping and could not be indexed completely.
- Locked package "symfony/deprecation-contracts" files mapping was unavailable, so its symbols could not be indexed.
- Locked package "symfony/dom-crawler" autoload.psr-4 contains a dynamic or unsupported mapping and could not be indexed completely.
- Locked package "symfony/error-handler" autoload.psr-4 contains a dynamic or unsupported mapping and could not be indexed completely.
- Locked package "symfony/event-dispatcher" autoload.psr-4 contains a dynamic or unsupported mapping and could not be indexed completely.
- Locked package "symfony/event-dispatcher-contracts" autoload.psr-4 contains a dynamic or unsupported mapping and could not be indexed completely.
- Locked package "symfony/finder" autoload.psr-4 contains a dynamic or unsupported mapping and could not be indexed completely.
- Locked package "symfony/http-foundation" autoload.psr-4 contains a dynamic or unsupported mapping and could not be indexed completely.
- Locked package "symfony/http-kernel" autoload.psr-4 contains a dynamic or unsupported mapping and could not be indexed completely.
- Locked package "symfony/mailer" autoload.psr-4 contains a dynamic or unsupported mapping and could not be indexed completely.
- Locked package "symfony/mime" autoload.psr-4 contains a dynamic or unsupported mapping and could not be indexed completely.
- Locked package "symfony/polyfill-ctype" autoload.psr-4 contains a dynamic or unsupported mapping and could not be indexed completely.
- Locked package "symfony/polyfill-ctype" files mapping was unavailable, so its symbols could not be indexed.
- Locked package "symfony/polyfill-intl-grapheme" autoload.psr-4 contains a dynamic or unsupported mapping and could not be indexed completely.
- Locked package "symfony/polyfill-intl-grapheme" files mapping was unavailable, so its symbols could not be indexed.
- Locked package "symfony/polyfill-intl-idn" autoload.psr-4 contains a dynamic or unsupported mapping and could not be indexed completely.
- Locked package "symfony/polyfill-intl-idn" files mapping was unavailable, so its symbols could not be indexed.
- Locked package "symfony/polyfill-intl-normalizer" autoload.psr-4 contains a dynamic or unsupported mapping and could not be indexed completely.
- Locked package "symfony/polyfill-intl-normalizer" classmap mapping was unavailable, so its symbols could not be indexed.
- Locked package "symfony/polyfill-intl-normalizer" files mapping was unavailable, so its symbols could not be indexed.
- Locked package "symfony/polyfill-mbstring" autoload.psr-4 contains a dynamic or unsupported mapping and could not be indexed completely.
- Locked package "symfony/polyfill-mbstring" files mapping was unavailable, so its symbols could not be indexed.
- Locked package "symfony/polyfill-php72" autoload.psr-4 contains a dynamic or unsupported mapping and could not be indexed completely.
- Locked package "symfony/polyfill-php72" files mapping was unavailable, so its symbols could not be indexed.
- Locked package "symfony/polyfill-php80" autoload.psr-4 contains a dynamic or unsupported mapping and could not be indexed completely.
- Locked package "symfony/polyfill-php80" classmap mapping was unavailable, so its symbols could not be indexed.
- Locked package "symfony/polyfill-php80" files mapping was unavailable, so its symbols could not be indexed.
- Locked package "symfony/polyfill-php83" autoload.psr-4 contains a dynamic or unsupported mapping and could not be indexed completely.
- Locked package "symfony/polyfill-php83" classmap mapping was unavailable, so its symbols could not be indexed.
- Locked package "symfony/polyfill-php83" files mapping was unavailable, so its symbols could not be indexed.
- Locked package "symfony/polyfill-uuid" autoload.psr-4 contains a dynamic or unsupported mapping and could not be indexed completely.
- Locked package "symfony/polyfill-uuid" files mapping was unavailable, so its symbols could not be indexed.
- Locked package "symfony/process" autoload.psr-4 contains a dynamic or unsupported mapping and could not be indexed completely.
- Locked package "symfony/psr-http-message-bridge" autoload.psr-4 contains a dynamic or unsupported mapping and could not be indexed completely.
- Locked package "symfony/routing" autoload.psr-4 contains a dynamic or unsupported mapping and could not be indexed completely.
- Locked package "symfony/service-contracts" autoload.psr-4 contains a dynamic or unsupported mapping and could not be indexed completely.
- Locked package "symfony/string" autoload.psr-4 contains a dynamic or unsupported mapping and could not be indexed completely.
- Locked package "symfony/string" files mapping was unavailable, so its symbols could not be indexed.
- Locked package "symfony/translation" autoload.psr-4 contains a dynamic or unsupported mapping and could not be indexed completely.
- Locked package "symfony/translation" files mapping was unavailable, so its symbols could not be indexed.
- Locked package "symfony/translation-contracts" autoload.psr-4 contains a dynamic or unsupported mapping and could not be indexed completely.
- Locked package "symfony/uid" autoload.psr-4 contains a dynamic or unsupported mapping and could not be indexed completely.
- Locked package "symfony/var-dumper" autoload.psr-4 contains a dynamic or unsupported mapping and could not be indexed completely.
- Locked package "symfony/var-dumper" files mapping was unavailable, so its symbols could not be indexed.
- Locked package "theseer/tokenizer" classmap mapping was unavailable, so its symbols could not be indexed.
- Dependency resolution does not prove application runtime compatibility; the project test suite must run on the target runtime.
- No Composer "test" script was found, so the project's canonical test command is unknown.
- Composer modeled only the listed extension assumptions; every unlisted extension still came from the analyzer runtime.
- Extension ext-bcmath was assumed present without a version; Composer used a conservative presence-only sentinel, so exact extension version compatibility remains uncertain and related solver failures are advisory rather than reproducible blockers.
- Extension ext-curl was assumed present without a version; Composer used a conservative presence-only sentinel, so exact extension version compatibility remains uncertain and related solver failures are advisory rather than reproducible blockers.
- Extension ext-exif was assumed present without a version; Composer used a conservative presence-only sentinel, so exact extension version compatibility remains uncertain and related solver failures are advisory rather than reproducible blockers.
- Extension ext-fileinfo was assumed present without a version; Composer used a conservative presence-only sentinel, so exact extension version compatibility remains uncertain and related solver failures are advisory rather than reproducible blockers.
- Extension ext-gd was assumed present without a version; Composer used a conservative presence-only sentinel, so exact extension version compatibility remains uncertain and related solver failures are advisory rather than reproducible blockers.
- Extension ext-imagick was assumed present without a version; Composer used a conservative presence-only sentinel, so exact extension version compatibility remains uncertain and related solver failures are advisory rather than reproducible blockers.
- Extension ext-mbstring was assumed present without a version; Composer used a conservative presence-only sentinel, so exact extension version compatibility remains uncertain and related solver failures are advisory rather than reproducible blockers.
- Extension ext-openssl was assumed present without a version; Composer used a conservative presence-only sentinel, so exact extension version compatibility remains uncertain and related solver failures are advisory rather than reproducible blockers.
- Extension ext-pdo was assumed present without a version; Composer used a conservative presence-only sentinel, so exact extension version compatibility remains uncertain and related solver failures are advisory rather than reproducible blockers.
- Extension ext-xml was assumed present without a version; Composer used a conservative presence-only sentinel, so exact extension version compatibility remains uncertain and related solver failures are advisory rather than reproducible blockers.
- Extension ext-zip was assumed present without a version; Composer used a conservative presence-only sentinel, so exact extension version compatibility remains uncertain and related solver failures are advisory rather than reproducible blockers.
- Compatible Composer execution may inherit global configuration, credentials, proxies, caches, repository access, and other analyzer-host state.

## Evidence
- `lock-metadata-1` (`E2`, high confidence): Composer lock metadata marks intervention/imagecache as abandoned. Context: `{"package":"intervention/imagecache","locked_version":"2.6.0","direct":true,"abandoned_alternative":null,"abandoned_alternative_type":null}`
- `lock-metadata-2` (`E2`, high confidence): Composer lock metadata marks paypal/paypal-checkout-sdk as abandoned. Context: `{"package":"paypal/paypal-checkout-sdk","locked_version":"1.0.1","direct":true,"abandoned_alternative":null,"abandoned_alternative_type":null}`
- `solver-1` (`E1`, high confidence): Composer scenario "exact-target" failed. Context: ``{"scenario":"exact-target","targets":[{"package":"laravel/framework","constraint":"^13.0"},{"package":"php","constraint":"8.3.0"}],"exit_code":2,"output_excerpt":"Loading composer repositories with package information\nUpdating dependencies\nYour requirements could not be resolved to an installable set of packages.\n\n  Problem 1\n    - Root composer.json requires PHP extension ext-calendar * but it is missing from your system. Install or enable PHP's calendar extension.\n\n      Alternatively you can require one of these packages that provide the extension (or parts of it):\n      Keep in mind that the suggestions are automated and may not be valid or safe to use\n      - fisharebest/ext-calendar Implementation of the Arabic (Hijri), French, Gregorian, Jewish, Julian and Persian (Jalali) calenda\n      - condorcet-php/php-calendars Pure PHP implementation of the Arabic (Hijri), French, Gregorian, Jewish, Julian and Persian (Jalali\n\n  Problem 2\n    - Root composer.json requires PHP extension ext-intl * but it is missing from your system. Install or enable PHP's intl extension.\n\n      Alternatively you can require one of these packages that provide the extension (or parts of it):\n      Keep in mind that the suggestions are automated and may not be valid or safe to use\n      - phuture/continuum A forward-compatibility layer bringing tomorrow\u2019s PHP features to today\u2019s runtimes.\n\n  Problem 3\n    - Root composer.json requires PHP extension ext-pdo_mysql * but it is missing from your system. Install or enable PHP's pdo_mysql extension.\n  Problem 4\n    - Root composer.json requires laravel/framework ^13.0, found laravel/framework[v13.0.0, ..., v13.37.0] but these were not loaded, because they are affected by security advisories (\"PKSA-d5tc-s1qs-h781\", \"PKSA-m5cs-t1y6-qpcs\", \"PKSA-3r5d-mb8f-1qw9\", \"PKSA-mdq4-51ck-6kdq\"). Go to [REDACTED_URL] to find advisory details. To ignore the advisories, add their IDs to the \"policy.advisories.ignore-id\" config or add the package to \"policy.advisories.ignore\". To turn the feature off entirely, you can set \"policy.advisories.block\" to false.\n  Problem 5\n    - diglactic/laravel-breadcrumbs is locked to ","diagnostics":[{"package":"laravel/framework","constraint":"^13.0","command":["[COMPOSER_EXECUTABLE]","prohibits","laravel/framework","^13.0","--tree","--locked","--no-scripts","--no-plugins","--no-interaction"],"exit_code":1,"outcome":"success","stdout_excerpt":"laravel/framework v10.41.0 The Laravel Framework.\n|--astrotomic/laravel-translatable v11.12.1 (requires illuminate/contracts ^8.0 || ^9.0 || ^10.0)\n|  `--bagisto/bagisto (requires astrotomic/laravel-translatable ^11.0.0)\n|--astrotomic/laravel-translatable v11.12.1 (requires illuminate/database ^8.0 || ^9.0 || ^10.0) (circular dependency aborted here)\n|--astrotomic/laravel-translatable v11.12.1 (requires illuminate/support ^8.0 || ^9.0 || ^10.0) (circular dependency aborted here)\n|--barryvdh/laravel-dompdf v2.0.1 (requires illuminate/support ^6|^7|^8|^9|^10)\n|  `--bagisto/bagisto (requires barryvdh/laravel-dompdf ^2.0.0)\n|--diglactic/laravel-breadcrumbs v8.1.1 (requires laravel/framework ^6.0 || ^7.0 || ^8.0 || ^9.0 || ^10.0)\n|  `--bagisto/bagisto (requires diglactic/laravel-breadcrumbs ^8.0)\n|--intervention/imagecache 2.6.0 (requires illuminate/cache ^5.5|~6|~7|~8|~9|~10)\n|  `--bagisto/bagisto (requires intervention/imagecache ^2.5.2)\n|--intervention/imagecache 2.6.0 (requires illuminate/filesystem ^5.5|~6|~7|~8|~9|~10) (circular dependency aborted here)\n|--kalnoy/nestedset v6.0.3 (requires illuminate/database ^7.0|^8.0|^9.0|^10.0)\n|  `--bagisto/bagisto (requires kalnoy/nestedset ^6.0)\n|--kalnoy/nestedset v6.0.3 (requires illuminate/events ^7.0|^8.0|^9.0|^10.0) (circular dependency aborted here)\n|--kalnoy/nestedset v6.0.3 (requires illuminate/support ^7.0|^8.0|^9.0|^10.0) (circular dependency aborted here)\n|--konekt/concord 1.14.0 (requires illuminate/console ^9.2|^10.0|^11.0)\n|  `--bagisto/bagisto (requires konekt/concord ^1.2)\n|--konekt/concord 1.14.0 (requires illuminate/support ^9.2|^10.0|^11.0) (circular dependency aborted here)\n|--konekt/enum-eloquent 1.9.3 (requires illuminate/database ^8.75|9.*|10.*|11.*)\n|  `--konekt/concord 1.14.0 (requires konekt/enum-eloquent ^1.7)\n|     `--bagisto/bagisto (requires konekt/concord ^1.2)\n|--laravel/octane v2.3.0 (requires laravel/framework ^10.10.1|^11.0)\n|  `--bagisto/bagisto (requires laravel/octane ^2.0)\n|--laravel/prompts v0.1.15 (requires illuminate/collections ^10.0|^11.0)\n|  |--laravel/framework v10.41.0 (requires laravel/prompts ^0.1.9) (circular dependency aborted here)\n|  `--laravel/framework v13.37.0 (requires laravel/prompts ^0.3.25) (circular dependency aborted here)\n|--laravel/sanctum v3.3.3 (requires illuminate/console ^9.21|^10.0)\n|  `--bagisto/bagisto (requires laravel/sanctum ^3.2)\n|--laravel/sanctum v3.3.3 (requires illuminate/contracts ^9.21|^10.0) (circular dependency aborted here)\n|--laravel/sanctum v3.3.3 (requires illuminate/database ^9.21|^10.0) (circular dependency aborted here)\n|--laravel/sanctum v3.3.3 (requires illuminate/support ^9.21|^10.0) (circular dependency aborted here)\n|--laravel/socialite v5.11.0 (requires illuminate/contracts ^6.0|^7.0|^8.0|^9.0|^10.0|^11.0)\n|  `--bagisto/bagisto (requires laravel/socialite ^5.0)\n|--laravel/socialite v5.11.0 (requires illuminate/http ^6.0|^7.0|^8.0|^9.0|^10.0|^11.0) (circular dependency aborted here)\n|--laravel/socialite v5.11.0 (requires illuminate/support ^6.0|^7.0|^8.0|^9.0|^10.0|^11.0) (circular dependency aborted here)\n|--laravel/tinker v2.9.0 (requires illuminate/console ^6.0|^7.0|^8.0|^9.0|^10.0|^11.0)\n|  `--bagisto/bagisto (requires laravel/tinker ^2.0)\n|--laravel/tinker v2.9.0 (requires illuminate/contracts ^6.0|^7.0|^8.0|^9.0|^10.0|^11.0) (circular dependency aborted here)\n|--laravel/tinker v2.9.0 (requires illuminate/support ^6.0|^7.0|^8.0|^9.0|^10.0|^11.0) (circular dependency aborted here)\n|--laravel/ui v4.4.0 (requires illuminate/console ^9.21|^10.0|^11.0)\n|  `--bagisto/bagisto (requires laravel/ui ^4.0)\n|--laravel/ui v4.4.0 (requires illuminate/filesystem ^9.21|^10.0|^11.0) (circular dependency aborted here)\n|--laravel/ui v4.4.0 (requires illuminate/support ^9.21|^10.0|^11.0) (circular dependency aborted here)\n|--laravel/ui v4.4.0 (requires illuminate/validation ^9.21|^10.0|^11.0) (circular dependency aborted here)\n|--maatwebsite/excel 3.1.52 (requires i\n[TRUNCATED: 14235 bytes of output omitted]","stderr_excerpt":"Not finding what you were looking for? Try calling `composer require \"laravel/framework:^13.0\" --dry-run` to get another view on the problem.\n"},{"package":"php","constraint":"8.3.0","command":["[COMPOSER_EXECUTABLE]","prohibits","php","8.3.0","--tree","--locked","--no-scripts","--no-plugins","--no-interaction"],"exit_code":0,"outcome":"success","stdout_excerpt":"","stderr_excerpt":"There is no installed package depending on \"php\" in versions not matching 8.3.0\n"}]}``
- `solver-2` (`E1`, high confidence): Composer scenario "target-with-all-dependencies" failed. Context: ``{"scenario":"target-with-all-dependencies","targets":[{"package":"laravel/framework","constraint":"^13.0"},{"package":"php","constraint":"8.3.0"}],"exit_code":2,"output_excerpt":"Loading composer repositories with package information\nUpdating dependencies\nYour requirements could not be resolved to an installable set of packages.\n\n  Problem 1\n    - Root composer.json requires PHP extension ext-calendar * but it is missing from your system. Install or enable PHP's calendar extension.\n\n      Alternatively you can require one of these packages that provide the extension (or parts of it):\n      Keep in mind that the suggestions are automated and may not be valid or safe to use\n      - fisharebest/ext-calendar Implementation of the Arabic (Hijri), French, Gregorian, Jewish, Julian and Persian (Jalali) calenda\n      - condorcet-php/php-calendars Pure PHP implementation of the Arabic (Hijri), French, Gregorian, Jewish, Julian and Persian (Jalali\n\n  Problem 2\n    - Root composer.json requires PHP extension ext-intl * but it is missing from your system. Install or enable PHP's intl extension.\n\n      Alternatively you can require one of these packages that provide the extension (or parts of it):\n      Keep in mind that the suggestions are automated and may not be valid or safe to use\n      - phuture/continuum A forward-compatibility layer bringing tomorrow\u2019s PHP features to today\u2019s runtimes.\n\n  Problem 3\n    - Root composer.json requires PHP extension ext-pdo_mysql * but it is missing from your system. Install or enable PHP's pdo_mysql extension.\n  Problem 4\n    - Root composer.json requires laravel/framework ^13.0, found laravel/framework[v13.0.0, ..., v13.37.0] but these were not loaded, because they are affected by security advisories (\"PKSA-d5tc-s1qs-h781\", \"PKSA-m5cs-t1y6-qpcs\", \"PKSA-3r5d-mb8f-1qw9\", \"PKSA-mdq4-51ck-6kdq\"). Go to [REDACTED_URL] to find advisory details. To ignore the advisories, add their IDs to the \"policy.advisories.ignore-id\" config or add the package to \"policy.advisories.ignore\". To turn the feature off entirely, you can set \"policy.advisories.block\" to false.\n  Problem 5\n    - diglactic/laravel-breadcrumbs is locked to ","diagnostics":[{"package":"laravel/framework","constraint":"^13.0","command":["[COMPOSER_EXECUTABLE]","prohibits","laravel/framework","^13.0","--tree","--locked","--no-scripts","--no-plugins","--no-interaction"],"exit_code":1,"outcome":"success","stdout_excerpt":"laravel/framework v10.41.0 The Laravel Framework.\n|--astrotomic/laravel-translatable v11.12.1 (requires illuminate/contracts ^8.0 || ^9.0 || ^10.0)\n|  `--bagisto/bagisto (requires astrotomic/laravel-translatable ^11.0.0)\n|--astrotomic/laravel-translatable v11.12.1 (requires illuminate/database ^8.0 || ^9.0 || ^10.0) (circular dependency aborted here)\n|--astrotomic/laravel-translatable v11.12.1 (requires illuminate/support ^8.0 || ^9.0 || ^10.0) (circular dependency aborted here)\n|--barryvdh/laravel-dompdf v2.0.1 (requires illuminate/support ^6|^7|^8|^9|^10)\n|  `--bagisto/bagisto (requires barryvdh/laravel-dompdf ^2.0.0)\n|--diglactic/laravel-breadcrumbs v8.1.1 (requires laravel/framework ^6.0 || ^7.0 || ^8.0 || ^9.0 || ^10.0)\n|  `--bagisto/bagisto (requires diglactic/laravel-breadcrumbs ^8.0)\n|--intervention/imagecache 2.6.0 (requires illuminate/cache ^5.5|~6|~7|~8|~9|~10)\n|  `--bagisto/bagisto (requires intervention/imagecache ^2.5.2)\n|--intervention/imagecache 2.6.0 (requires illuminate/filesystem ^5.5|~6|~7|~8|~9|~10) (circular dependency aborted here)\n|--kalnoy/nestedset v6.0.3 (requires illuminate/database ^7.0|^8.0|^9.0|^10.0)\n|  `--bagisto/bagisto (requires kalnoy/nestedset ^6.0)\n|--kalnoy/nestedset v6.0.3 (requires illuminate/events ^7.0|^8.0|^9.0|^10.0) (circular dependency aborted here)\n|--kalnoy/nestedset v6.0.3 (requires illuminate/support ^7.0|^8.0|^9.0|^10.0) (circular dependency aborted here)\n|--konekt/concord 1.14.0 (requires illuminate/console ^9.2|^10.0|^11.0)\n|  `--bagisto/bagisto (requires konekt/concord ^1.2)\n|--konekt/concord 1.14.0 (requires illuminate/support ^9.2|^10.0|^11.0) (circular dependency aborted here)\n|--konekt/enum-eloquent 1.9.3 (requires illuminate/database ^8.75|9.*|10.*|11.*)\n|  `--konekt/concord 1.14.0 (requires konekt/enum-eloquent ^1.7)\n|     `--bagisto/bagisto (requires konekt/concord ^1.2)\n|--laravel/octane v2.3.0 (requires laravel/framework ^10.10.1|^11.0)\n|  `--bagisto/bagisto (requires laravel/octane ^2.0)\n|--laravel/prompts v0.1.15 (requires illuminate/collections ^10.0|^11.0)\n|  |--laravel/framework v10.41.0 (requires laravel/prompts ^0.1.9) (circular dependency aborted here)\n|  `--laravel/framework v13.37.0 (requires laravel/prompts ^0.3.25) (circular dependency aborted here)\n|--laravel/sanctum v3.3.3 (requires illuminate/console ^9.21|^10.0)\n|  `--bagisto/bagisto (requires laravel/sanctum ^3.2)\n|--laravel/sanctum v3.3.3 (requires illuminate/contracts ^9.21|^10.0) (circular dependency aborted here)\n|--laravel/sanctum v3.3.3 (requires illuminate/database ^9.21|^10.0) (circular dependency aborted here)\n|--laravel/sanctum v3.3.3 (requires illuminate/support ^9.21|^10.0) (circular dependency aborted here)\n|--laravel/socialite v5.11.0 (requires illuminate/contracts ^6.0|^7.0|^8.0|^9.0|^10.0|^11.0)\n|  `--bagisto/bagisto (requires laravel/socialite ^5.0)\n|--laravel/socialite v5.11.0 (requires illuminate/http ^6.0|^7.0|^8.0|^9.0|^10.0|^11.0) (circular dependency aborted here)\n|--laravel/socialite v5.11.0 (requires illuminate/support ^6.0|^7.0|^8.0|^9.0|^10.0|^11.0) (circular dependency aborted here)\n|--laravel/tinker v2.9.0 (requires illuminate/console ^6.0|^7.0|^8.0|^9.0|^10.0|^11.0)\n|  `--bagisto/bagisto (requires laravel/tinker ^2.0)\n|--laravel/tinker v2.9.0 (requires illuminate/contracts ^6.0|^7.0|^8.0|^9.0|^10.0|^11.0) (circular dependency aborted here)\n|--laravel/tinker v2.9.0 (requires illuminate/support ^6.0|^7.0|^8.0|^9.0|^10.0|^11.0) (circular dependency aborted here)\n|--laravel/ui v4.4.0 (requires illuminate/console ^9.21|^10.0|^11.0)\n|  `--bagisto/bagisto (requires laravel/ui ^4.0)\n|--laravel/ui v4.4.0 (requires illuminate/filesystem ^9.21|^10.0|^11.0) (circular dependency aborted here)\n|--laravel/ui v4.4.0 (requires illuminate/support ^9.21|^10.0|^11.0) (circular dependency aborted here)\n|--laravel/ui v4.4.0 (requires illuminate/validation ^9.21|^10.0|^11.0) (circular dependency aborted here)\n|--maatwebsite/excel 3.1.52 (requires i\n[TRUNCATED: 14235 bytes of output omitted]","stderr_excerpt":"Not finding what you were looking for? Try calling `composer require \"laravel/framework:^13.0\" --dry-run` to get another view on the problem.\n"},{"package":"php","constraint":"8.3.0","command":["[COMPOSER_EXECUTABLE]","prohibits","php","8.3.0","--tree","--locked","--no-scripts","--no-plugins","--no-interaction"],"exit_code":0,"outcome":"success","stdout_excerpt":"","stderr_excerpt":"There is no installed package depending on \"php\" in versions not matching 8.3.0\n"}]}``
- `solver-3` (`E1`, high confidence): Composer scenario "minimal-changes" failed. Context: ``{"scenario":"minimal-changes","targets":[{"package":"laravel/framework","constraint":"^13.0"},{"package":"php","constraint":"8.3.0"}],"exit_code":2,"output_excerpt":"Loading composer repositories with package information\nUpdating dependencies\nYour requirements could not be resolved to an installable set of packages.\n\n  Problem 1\n    - Root composer.json requires PHP extension ext-calendar * but it is missing from your system. Install or enable PHP's calendar extension.\n\n      Alternatively you can require one of these packages that provide the extension (or parts of it):\n      Keep in mind that the suggestions are automated and may not be valid or safe to use\n      - fisharebest/ext-calendar Implementation of the Arabic (Hijri), French, Gregorian, Jewish, Julian and Persian (Jalali) calenda\n      - condorcet-php/php-calendars Pure PHP implementation of the Arabic (Hijri), French, Gregorian, Jewish, Julian and Persian (Jalali\n\n  Problem 2\n    - Root composer.json requires PHP extension ext-intl * but it is missing from your system. Install or enable PHP's intl extension.\n\n      Alternatively you can require one of these packages that provide the extension (or parts of it):\n      Keep in mind that the suggestions are automated and may not be valid or safe to use\n      - phuture/continuum A forward-compatibility layer bringing tomorrow\u2019s PHP features to today\u2019s runtimes.\n\n  Problem 3\n    - Root composer.json requires PHP extension ext-pdo_mysql * but it is missing from your system. Install or enable PHP's pdo_mysql extension.\n  Problem 4\n    - Root composer.json requires laravel/framework ^13.0, found laravel/framework[v13.0.0, ..., v13.37.0] but these were not loaded, because they are affected by security advisories (\"PKSA-d5tc-s1qs-h781\", \"PKSA-m5cs-t1y6-qpcs\", \"PKSA-3r5d-mb8f-1qw9\", \"PKSA-mdq4-51ck-6kdq\"). Go to [REDACTED_URL] to find advisory details. To ignore the advisories, add their IDs to the \"policy.advisories.ignore-id\" config or add the package to \"policy.advisories.ignore\". To turn the feature off entirely, you can set \"policy.advisories.block\" to false.\n  Problem 5\n    - diglactic/laravel-breadcrumbs is locked to ","diagnostics":[{"package":"laravel/framework","constraint":"^13.0","command":["[COMPOSER_EXECUTABLE]","prohibits","laravel/framework","^13.0","--tree","--locked","--no-scripts","--no-plugins","--no-interaction"],"exit_code":1,"outcome":"success","stdout_excerpt":"laravel/framework v10.41.0 The Laravel Framework.\n|--astrotomic/laravel-translatable v11.12.1 (requires illuminate/contracts ^8.0 || ^9.0 || ^10.0)\n|  `--bagisto/bagisto (requires astrotomic/laravel-translatable ^11.0.0)\n|--astrotomic/laravel-translatable v11.12.1 (requires illuminate/database ^8.0 || ^9.0 || ^10.0) (circular dependency aborted here)\n|--astrotomic/laravel-translatable v11.12.1 (requires illuminate/support ^8.0 || ^9.0 || ^10.0) (circular dependency aborted here)\n|--barryvdh/laravel-dompdf v2.0.1 (requires illuminate/support ^6|^7|^8|^9|^10)\n|  `--bagisto/bagisto (requires barryvdh/laravel-dompdf ^2.0.0)\n|--diglactic/laravel-breadcrumbs v8.1.1 (requires laravel/framework ^6.0 || ^7.0 || ^8.0 || ^9.0 || ^10.0)\n|  `--bagisto/bagisto (requires diglactic/laravel-breadcrumbs ^8.0)\n|--intervention/imagecache 2.6.0 (requires illuminate/cache ^5.5|~6|~7|~8|~9|~10)\n|  `--bagisto/bagisto (requires intervention/imagecache ^2.5.2)\n|--intervention/imagecache 2.6.0 (requires illuminate/filesystem ^5.5|~6|~7|~8|~9|~10) (circular dependency aborted here)\n|--kalnoy/nestedset v6.0.3 (requires illuminate/database ^7.0|^8.0|^9.0|^10.0)\n|  `--bagisto/bagisto (requires kalnoy/nestedset ^6.0)\n|--kalnoy/nestedset v6.0.3 (requires illuminate/events ^7.0|^8.0|^9.0|^10.0) (circular dependency aborted here)\n|--kalnoy/nestedset v6.0.3 (requires illuminate/support ^7.0|^8.0|^9.0|^10.0) (circular dependency aborted here)\n|--konekt/concord 1.14.0 (requires illuminate/console ^9.2|^10.0|^11.0)\n|  `--bagisto/bagisto (requires konekt/concord ^1.2)\n|--konekt/concord 1.14.0 (requires illuminate/support ^9.2|^10.0|^11.0) (circular dependency aborted here)\n|--konekt/enum-eloquent 1.9.3 (requires illuminate/database ^8.75|9.*|10.*|11.*)\n|  `--konekt/concord 1.14.0 (requires konekt/enum-eloquent ^1.7)\n|     `--bagisto/bagisto (requires konekt/concord ^1.2)\n|--laravel/octane v2.3.0 (requires laravel/framework ^10.10.1|^11.0)\n|  `--bagisto/bagisto (requires laravel/octane ^2.0)\n|--laravel/prompts v0.1.15 (requires illuminate/collections ^10.0|^11.0)\n|  |--laravel/framework v10.41.0 (requires laravel/prompts ^0.1.9) (circular dependency aborted here)\n|  `--laravel/framework v13.37.0 (requires laravel/prompts ^0.3.25) (circular dependency aborted here)\n|--laravel/sanctum v3.3.3 (requires illuminate/console ^9.21|^10.0)\n|  `--bagisto/bagisto (requires laravel/sanctum ^3.2)\n|--laravel/sanctum v3.3.3 (requires illuminate/contracts ^9.21|^10.0) (circular dependency aborted here)\n|--laravel/sanctum v3.3.3 (requires illuminate/database ^9.21|^10.0) (circular dependency aborted here)\n|--laravel/sanctum v3.3.3 (requires illuminate/support ^9.21|^10.0) (circular dependency aborted here)\n|--laravel/socialite v5.11.0 (requires illuminate/contracts ^6.0|^7.0|^8.0|^9.0|^10.0|^11.0)\n|  `--bagisto/bagisto (requires laravel/socialite ^5.0)\n|--laravel/socialite v5.11.0 (requires illuminate/http ^6.0|^7.0|^8.0|^9.0|^10.0|^11.0) (circular dependency aborted here)\n|--laravel/socialite v5.11.0 (requires illuminate/support ^6.0|^7.0|^8.0|^9.0|^10.0|^11.0) (circular dependency aborted here)\n|--laravel/tinker v2.9.0 (requires illuminate/console ^6.0|^7.0|^8.0|^9.0|^10.0|^11.0)\n|  `--bagisto/bagisto (requires laravel/tinker ^2.0)\n|--laravel/tinker v2.9.0 (requires illuminate/contracts ^6.0|^7.0|^8.0|^9.0|^10.0|^11.0) (circular dependency aborted here)\n|--laravel/tinker v2.9.0 (requires illuminate/support ^6.0|^7.0|^8.0|^9.0|^10.0|^11.0) (circular dependency aborted here)\n|--laravel/ui v4.4.0 (requires illuminate/console ^9.21|^10.0|^11.0)\n|  `--bagisto/bagisto (requires laravel/ui ^4.0)\n|--laravel/ui v4.4.0 (requires illuminate/filesystem ^9.21|^10.0|^11.0) (circular dependency aborted here)\n|--laravel/ui v4.4.0 (requires illuminate/support ^9.21|^10.0|^11.0) (circular dependency aborted here)\n|--laravel/ui v4.4.0 (requires illuminate/validation ^9.21|^10.0|^11.0) (circular dependency aborted here)\n|--maatwebsite/excel 3.1.52 (requires i\n[TRUNCATED: 14235 bytes of output omitted]","stderr_excerpt":"Not finding what you were looking for? Try calling `composer require \"laravel/framework:^13.0\" --dry-run` to get another view on the problem.\n"},{"package":"php","constraint":"8.3.0","command":["[COMPOSER_EXECUTABLE]","prohibits","php","8.3.0","--tree","--locked","--no-scripts","--no-plugins","--no-interaction"],"exit_code":0,"outcome":"success","stdout_excerpt":"","stderr_excerpt":"There is no installed package depending on \"php\" in versions not matching 8.3.0\n"}]}``
- `solver-4` (`E1`, high confidence): Composer scenario "target-platform-only" failed. Context: `{"scenario":"target-platform-only","targets":[{"package":"php","constraint":"8.3.0"}],"exit_code":2,"output_excerpt":"Loading composer repositories with package information\nUpdating dependencies\nYour requirements could not be resolved to an installable set of packages.\n\n  Problem 1\n    - Root composer.json requires PHP extension ext-calendar * but it is missing from your system. Install or enable PHP's calendar extension.\n\n      Alternatively you can require one of these packages that provide the extension (or parts of it):\n      Keep in mind that the suggestions are automated and may not be valid or safe to use\n      - fisharebest/ext-calendar Implementation of the Arabic (Hijri), French, Gregorian, Jewish, Julian and Persian (Jalali) calenda\n      - condorcet-php/php-calendars Pure PHP implementation of the Arabic (Hijri), French, Gregorian, Jewish, Julian and Persian (Jalali\n\n  Problem 2\n    - Root composer.json requires PHP extension ext-intl * but it is missing from your system. Install or enable PHP's intl extension.\n\n      Alternatively you can require one of these packages that provide the extension (or parts of it):\n      Keep in mind that the suggestions are automated and may not be valid or safe to use\n      - phuture/continuum A forward-compatibility layer bringing tomorrow\u2019s PHP features to today\u2019s runtimes.\n\n  Problem 3\n    - Root composer.json requires PHP extension ext-pdo_mysql * but it is missing from your system. Install or enable PHP's pdo_mysql extension.\n  Problem 4\n    - Root composer.json requires enshrined/svg-sanitize ^0.16.0, found enshrined/svg-sanitize[0.16.0] but these were not loaded, because they are affected by security advisories (\"PKSA-8j6w-3kr7-s9xk\", \"PKSA-6j95-1jtb-x6wc\", \"PKSA-cbx2-m9db-bmzd\", \"PKSA-4g5g-4rkv-myqs\"). Go to [REDACTED_URL] to find advisory details. To ignore the advisories, add their IDs to the \"policy.advisories.ignore-id\" config or add the package to \"policy.advisories.ignore\". To turn the feature off entirely, you can set \"policy.advisories.block\" to false.\n  Problem 5\n    - Root composer.json requires laravel/framework ^","diagnostics":[{"package":"php","constraint":"8.3.0","command":["[COMPOSER_EXECUTABLE]","prohibits","php","8.3.0","--tree","--locked","--no-scripts","--no-plugins","--no-interaction"],"exit_code":0,"outcome":"success","stdout_excerpt":"","stderr_excerpt":"There is no installed package depending on \"php\" in versions not matching 8.3.0\n"}]}`
- `solver-5` (`E1`, high confidence): Composer scenario "staged-targets" failed. Context: ``{"scenario":"staged-targets","targets":[{"package":"laravel/framework","constraint":"^13.0"},{"package":"php","constraint":"8.1.0"}],"exit_code":2,"output_excerpt":"Loading composer repositories with package information\nUpdating dependencies\nYour requirements could not be resolved to an installable set of packages.\n\n  Problem 1\n    - Root composer.json requires PHP extension ext-calendar * but it is missing from your system. Install or enable PHP's calendar extension.\n\n      Alternatively you can require one of these packages that provide the extension (or parts of it):\n      Keep in mind that the suggestions are automated and may not be valid or safe to use\n      - fisharebest/ext-calendar Implementation of the Arabic (Hijri), French, Gregorian, Jewish, Julian and Persian (Jalali) calenda\n      - condorcet-php/php-calendars Pure PHP implementation of the Arabic (Hijri), French, Gregorian, Jewish, Julian and Persian (Jalali\n\n  Problem 2\n    - Root composer.json requires PHP extension ext-intl * but it is missing from your system. Install or enable PHP's intl extension.\n\n      Alternatively you can require one of these packages that provide the extension (or parts of it):\n      Keep in mind that the suggestions are automated and may not be valid or safe to use\n      - phuture/continuum A forward-compatibility layer bringing tomorrow\u2019s PHP features to today\u2019s runtimes.\n\n  Problem 3\n    - Root composer.json requires PHP extension ext-pdo_mysql * but it is missing from your system. Install or enable PHP's pdo_mysql extension.\n  Problem 4\n    - Root composer.json requires laravel/framework ^13.0, found laravel/framework[v13.0.0, ..., v13.37.0] but these were not loaded, because they are affected by security advisories (\"PKSA-d5tc-s1qs-h781\", \"PKSA-m5cs-t1y6-qpcs\", \"PKSA-3r5d-mb8f-1qw9\", \"PKSA-mdq4-51ck-6kdq\"). Go to [REDACTED_URL] to find advisory details. To ignore the advisories, add their IDs to the \"policy.advisories.ignore-id\" config or add the package to \"policy.advisories.ignore\". To turn the feature off entirely, you can set \"policy.advisories.block\" to false.\n  Problem 5\n    - diglactic/laravel-breadcrumbs is locked to ","diagnostics":[{"package":"laravel/framework","constraint":"^13.0","command":["[COMPOSER_EXECUTABLE]","prohibits","laravel/framework","^13.0","--tree","--locked","--no-scripts","--no-plugins","--no-interaction"],"exit_code":1,"outcome":"success","stdout_excerpt":"laravel/framework v10.41.0 The Laravel Framework.\n|--astrotomic/laravel-translatable v11.12.1 (requires illuminate/contracts ^8.0 || ^9.0 || ^10.0)\n|  `--bagisto/bagisto (requires astrotomic/laravel-translatable ^11.0.0)\n|--astrotomic/laravel-translatable v11.12.1 (requires illuminate/database ^8.0 || ^9.0 || ^10.0) (circular dependency aborted here)\n|--astrotomic/laravel-translatable v11.12.1 (requires illuminate/support ^8.0 || ^9.0 || ^10.0) (circular dependency aborted here)\n|--barryvdh/laravel-dompdf v2.0.1 (requires illuminate/support ^6|^7|^8|^9|^10)\n|  `--bagisto/bagisto (requires barryvdh/laravel-dompdf ^2.0.0)\n|--diglactic/laravel-breadcrumbs v8.1.1 (requires laravel/framework ^6.0 || ^7.0 || ^8.0 || ^9.0 || ^10.0)\n|  `--bagisto/bagisto (requires diglactic/laravel-breadcrumbs ^8.0)\n|--intervention/imagecache 2.6.0 (requires illuminate/cache ^5.5|~6|~7|~8|~9|~10)\n|  `--bagisto/bagisto (requires intervention/imagecache ^2.5.2)\n|--intervention/imagecache 2.6.0 (requires illuminate/filesystem ^5.5|~6|~7|~8|~9|~10) (circular dependency aborted here)\n|--kalnoy/nestedset v6.0.3 (requires illuminate/database ^7.0|^8.0|^9.0|^10.0)\n|  `--bagisto/bagisto (requires kalnoy/nestedset ^6.0)\n|--kalnoy/nestedset v6.0.3 (requires illuminate/events ^7.0|^8.0|^9.0|^10.0) (circular dependency aborted here)\n|--kalnoy/nestedset v6.0.3 (requires illuminate/support ^7.0|^8.0|^9.0|^10.0) (circular dependency aborted here)\n|--konekt/concord 1.14.0 (requires illuminate/console ^9.2|^10.0|^11.0)\n|  `--bagisto/bagisto (requires konekt/concord ^1.2)\n|--konekt/concord 1.14.0 (requires illuminate/support ^9.2|^10.0|^11.0) (circular dependency aborted here)\n|--konekt/enum-eloquent 1.9.3 (requires illuminate/database ^8.75|9.*|10.*|11.*)\n|  `--konekt/concord 1.14.0 (requires konekt/enum-eloquent ^1.7)\n|     `--bagisto/bagisto (requires konekt/concord ^1.2)\n|--laravel/octane v2.3.0 (requires laravel/framework ^10.10.1|^11.0)\n|  `--bagisto/bagisto (requires laravel/octane ^2.0)\n|--laravel/prompts v0.1.15 (requires illuminate/collections ^10.0|^11.0)\n|  |--laravel/framework v10.41.0 (requires laravel/prompts ^0.1.9) (circular dependency aborted here)\n|  `--laravel/framework v13.37.0 (requires laravel/prompts ^0.3.25) (circular dependency aborted here)\n|--laravel/sanctum v3.3.3 (requires illuminate/console ^9.21|^10.0)\n|  `--bagisto/bagisto (requires laravel/sanctum ^3.2)\n|--laravel/sanctum v3.3.3 (requires illuminate/contracts ^9.21|^10.0) (circular dependency aborted here)\n|--laravel/sanctum v3.3.3 (requires illuminate/database ^9.21|^10.0) (circular dependency aborted here)\n|--laravel/sanctum v3.3.3 (requires illuminate/support ^9.21|^10.0) (circular dependency aborted here)\n|--laravel/socialite v5.11.0 (requires illuminate/contracts ^6.0|^7.0|^8.0|^9.0|^10.0|^11.0)\n|  `--bagisto/bagisto (requires laravel/socialite ^5.0)\n|--laravel/socialite v5.11.0 (requires illuminate/http ^6.0|^7.0|^8.0|^9.0|^10.0|^11.0) (circular dependency aborted here)\n|--laravel/socialite v5.11.0 (requires illuminate/support ^6.0|^7.0|^8.0|^9.0|^10.0|^11.0) (circular dependency aborted here)\n|--laravel/tinker v2.9.0 (requires illuminate/console ^6.0|^7.0|^8.0|^9.0|^10.0|^11.0)\n|  `--bagisto/bagisto (requires laravel/tinker ^2.0)\n|--laravel/tinker v2.9.0 (requires illuminate/contracts ^6.0|^7.0|^8.0|^9.0|^10.0|^11.0) (circular dependency aborted here)\n|--laravel/tinker v2.9.0 (requires illuminate/support ^6.0|^7.0|^8.0|^9.0|^10.0|^11.0) (circular dependency aborted here)\n|--laravel/ui v4.4.0 (requires illuminate/console ^9.21|^10.0|^11.0)\n|  `--bagisto/bagisto (requires laravel/ui ^4.0)\n|--laravel/ui v4.4.0 (requires illuminate/filesystem ^9.21|^10.0|^11.0) (circular dependency aborted here)\n|--laravel/ui v4.4.0 (requires illuminate/support ^9.21|^10.0|^11.0) (circular dependency aborted here)\n|--laravel/ui v4.4.0 (requires illuminate/validation ^9.21|^10.0|^11.0) (circular dependency aborted here)\n|--maatwebsite/excel 3.1.52 (requires i\n[TRUNCATED: 14235 bytes of output omitted]","stderr_excerpt":"Not finding what you were looking for? Try calling `composer require \"laravel/framework:^13.0\" --dry-run` to get another view on the problem.\n"}]}``
- `laravel-stage-target-1` (`E4`, high confidence): Laravel adapter metadata supplies the exact package target for stage 10 to 11. Context: `{"stage_id":"laravel-10-to-11","package":"laravel/framework","constraint":"^11.0","analysis_php":"8.3.0","minimum_php_constraint":"^8.2","analysis_php_provenance":"final_target_php_exact_value_checked_against_adapter_constraint","sources":["https://laravel.com/docs/11.x/upgrade","https://github.com/laravel/framework/blob/e353708c960ec5066d76b0da4b81c8a68d183b93/composer.json"]}`
- `laravel-stage-remediation-1` (`E4`, medium confidence): Laravel adapter metadata permits an analyzer-only root constraint candidate for nunomaduro/collision in stage laravel-10-to-11. Context: `{"stage_id":"laravel-10-to-11","package":"nunomaduro/collision","constraint":"^8.1","sources":["https://laravel.com/docs/11.x/upgrade"]}`
- `laravel-stage-remediation-2` (`E4`, medium confidence): Laravel adapter metadata permits an analyzer-only root constraint candidate for laravel/sanctum in stage laravel-10-to-11. Context: `{"stage_id":"laravel-10-to-11","package":"laravel/sanctum","constraint":"^4.0","sources":["https://laravel.com/docs/11.x/upgrade"]}`
- `laravel-stage-remediation-3` (`E4`, medium confidence): Laravel adapter metadata permits an analyzer-only root constraint candidate for phpunit/phpunit in stage laravel-10-to-11. Context: `{"stage_id":"laravel-10-to-11","package":"phpunit/phpunit","constraint":"^10.5.35|^11.0.1|^12.0.1","sources":["https://github.com/laravel/laravel/blob/ecf6de4992d70dd37c21676be6b8ba4743151e63/composer.json","https://github.com/laravel/framework/blob/e353708c960ec5066d76b0da4b81c8a68d183b93/composer.json"]}`
- `laravel-stage-target-2` (`E4`, high confidence): Laravel adapter metadata supplies the exact package target for stage 11 to 12. Context: `{"stage_id":"laravel-11-to-12","package":"laravel/framework","constraint":"^12.0","analysis_php":"8.3.0","minimum_php_constraint":"^8.2","analysis_php_provenance":"final_target_php_exact_value_checked_against_adapter_constraint","sources":["https://laravel.com/docs/12.x/upgrade","https://github.com/laravel/framework/blob/5260836df1b953a558d9b810880f20db15568c01/composer.json"]}`
- `laravel-stage-remediation-4` (`E4`, medium confidence): Laravel adapter metadata permits an analyzer-only root constraint candidate for phpunit/phpunit in stage laravel-11-to-12. Context: `{"stage_id":"laravel-11-to-12","package":"phpunit/phpunit","constraint":"^10.5.35|^11.0|^12.0.1","sources":["https://github.com/laravel/docs/blob/5b8c610735c8af96a3bda4e37a820b27dc40aee9/upgrade.md","https://github.com/laravel/framework/blob/5260836df1b953a558d9b810880f20db15568c01/composer.json"]}`
- `laravel-stage-remediation-5` (`E4`, medium confidence): Laravel adapter metadata permits an analyzer-only root constraint candidate for pestphp/pest in stage laravel-11-to-12. Context: `{"stage_id":"laravel-11-to-12","package":"pestphp/pest","constraint":"^3.0|^4.0","sources":["https://laravel.com/docs/12.x/upgrade","https://github.com/pestphp/pest-plugin-laravel/blob/3057a36669ff11416cc0dc2b521b3aec58c488d0/composer.json"]}`
- `laravel-stage-remediation-6` (`E4`, medium confidence): Laravel adapter metadata permits an analyzer-only root constraint candidate for nunomaduro/collision in stage laravel-11-to-12. Context: `{"stage_id":"laravel-11-to-12","package":"nunomaduro/collision","constraint":"^8.6","sources":["https://github.com/laravel/laravel/blob/12.x/composer.json"]}`
- `laravel-stage-target-3` (`E4`, high confidence): Laravel adapter metadata supplies the exact package target for stage 12 to 13. Context: `{"stage_id":"laravel-12-to-13","package":"laravel/framework","constraint":"^13.0","analysis_php":"8.3.0","minimum_php_constraint":"^8.3","analysis_php_provenance":"final_target_php_exact_value_checked_against_adapter_constraint","sources":["https://github.com/laravel/docs/blob/9c5a062c14069bab9054b558829e282f9593a065/upgrade.md","https://github.com/laravel/framework/blob/8df67f9d176d1d0375a866d8c6780be95ce0336e/composer.json"]}`
- `laravel-stage-remediation-7` (`E4`, medium confidence): Laravel adapter metadata permits an analyzer-only root constraint candidate for laravel/tinker in stage laravel-12-to-13. Context: `{"stage_id":"laravel-12-to-13","package":"laravel/tinker","constraint":"^3.0","sources":["https://github.com/laravel/docs/blob/9c5a062c14069bab9054b558829e282f9593a065/upgrade.md"]}`
- `laravel-stage-remediation-8` (`E4`, medium confidence): Laravel adapter metadata permits an analyzer-only root constraint candidate for phpunit/phpunit in stage laravel-12-to-13. Context: `{"stage_id":"laravel-12-to-13","package":"phpunit/phpunit","constraint":"^11.5.50|^12.0|^13.0.3","sources":["https://github.com/laravel/docs/blob/9c5a062c14069bab9054b558829e282f9593a065/upgrade.md","https://github.com/laravel/laravel/blob/c926b8ca7fa01e71852e19141f2bdd7fabfb6ade/composer.json","https://github.com/laravel/framework/blob/8df67f9d176d1d0375a866d8c6780be95ce0336e/composer.json"]}`
- `laravel-stage-remediation-9` (`E4`, medium confidence): Laravel adapter metadata permits an analyzer-only root constraint candidate for pestphp/pest in stage laravel-12-to-13. Context: `{"stage_id":"laravel-12-to-13","package":"pestphp/pest","constraint":"^4.0|^5.0","sources":["https://github.com/laravel/docs/blob/9c5a062c14069bab9054b558829e282f9593a065/upgrade.md","https://github.com/pestphp/pest-plugin-laravel/blob/3057a36669ff11416cc0dc2b521b3aec58c488d0/composer.json","https://github.com/pestphp/pest-plugin-laravel/blob/d1564646e3198f1b607e64a36501d6edff7d104e/composer.json"]}`
- `laravel-stage-remediation-10` (`E4`, medium confidence): Laravel adapter metadata permits an analyzer-only root constraint candidate for nunomaduro/collision in stage laravel-12-to-13. Context: `{"stage_id":"laravel-12-to-13","package":"nunomaduro/collision","constraint":"^8.6","sources":["https://github.com/laravel/laravel/blob/c926b8ca7fa01e71852e19141f2bdd7fabfb6ade/composer.json"]}`
- `stage-attempt-1` (`E1`, high confidence): Executed Composer attempt 1 for stage laravel-10-to-11. Context: `{"stage_id":"laravel-10-to-11","attempt":1,"strategy":"target_only","scenario":"laravel-10-to-11-attempt-1-target_only","outcome":"solver_failure"}`
- `lock-metadata-3` (`E2`, high confidence): Composer lock metadata marks intervention/imagecache as abandoned. Context: `{"package":"intervention/imagecache","locked_version":"2.6.0","direct":true,"abandoned_alternative":null,"abandoned_alternative_type":null}`
- `lock-metadata-4` (`E2`, high confidence): Composer lock metadata marks paypal/paypal-checkout-sdk as abandoned. Context: `{"package":"paypal/paypal-checkout-sdk","locked_version":"1.0.1","direct":true,"abandoned_alternative":null,"abandoned_alternative_type":null}`
- `solver-6` (`E1`, high confidence): Composer scenario "laravel-10-to-11-attempt-1-target_only" failed. Context: ``{"scenario":"laravel-10-to-11-attempt-1-target_only","targets":[{"package":"laravel/framework","constraint":"^11.0"},{"package":"php","constraint":"8.3.0"}],"exit_code":2,"output_excerpt":"Loading composer repositories with package information\nUpdating dependencies\nYour requirements could not be resolved to an installable set of packages.\n\n  Problem 1\n    - Root composer.json requires PHP extension ext-calendar * but it is missing from your system. Install or enable PHP's calendar extension.\n\n      Alternatively you can require one of these packages that provide the extension (or parts of it):\n      Keep in mind that the suggestions are automated and may not be valid or safe to use\n      - fisharebest/ext-calendar Implementation of the Arabic (Hijri), French, Gregorian, Jewish, Julian and Persian (Jalali) calenda\n      - condorcet-php/php-calendars Pure PHP implementation of the Arabic (Hijri), French, Gregorian, Jewish, Julian and Persian (Jalali\n\n  Problem 2\n    - Root composer.json requires PHP extension ext-intl * but it is missing from your system. Install or enable PHP's intl extension.\n\n      Alternatively you can require one of these packages that provide the extension (or parts of it):\n      Keep in mind that the suggestions are automated and may not be valid or safe to use\n      - phuture/continuum A forward-compatibility layer bringing tomorrow\u2019s PHP features to today\u2019s runtimes.\n\n  Problem 3\n    - Root composer.json requires PHP extension ext-pdo_mysql * but it is missing from your system. Install or enable PHP's pdo_mysql extension.\n  Problem 4\n    - Root composer.json requires laravel/framework ^11.0, found laravel/framework[v11.0.0, ..., v11.57.0] but these were not loaded, because they are affected by security advisories (\"PKSA-d5tc-s1qs-h781\", \"PKSA-m5cs-t1y6-qpcs\", \"PKSA-3r5d-mb8f-1qw9\", \"PKSA-mdq4-51ck-6kdq\", \"PKSA-8qx3-n5y5-vvnd\", \"PKSA-q46n-4fdk-zjr4\", \"PKSA-qzrn-rnz3-85w1\", \"PKSA-w7xr-vk7n-rstm\"). Go to [REDACTED_URL] to find advisory details. To ignore the advisories, add their IDs to the \"policy.advisories.ignore-id\" config or add the package to \"policy.advisories.ignore\". To turn the feature off entirely, you can set \"poli","diagnostics":[{"package":"laravel/framework","constraint":"^11.0","command":["[COMPOSER_EXECUTABLE]","prohibits","laravel/framework","^11.0","--tree","--locked","--no-scripts","--no-plugins","--no-interaction"],"exit_code":1,"outcome":"success","stdout_excerpt":"laravel/framework v10.41.0 The Laravel Framework.\n|--astrotomic/laravel-translatable v11.12.1 (requires illuminate/contracts ^8.0 || ^9.0 || ^10.0)\n|  `--bagisto/bagisto (requires astrotomic/laravel-translatable ^11.0.0)\n|--astrotomic/laravel-translatable v11.12.1 (requires illuminate/database ^8.0 || ^9.0 || ^10.0) (circular dependency aborted here)\n|--astrotomic/laravel-translatable v11.12.1 (requires illuminate/support ^8.0 || ^9.0 || ^10.0) (circular dependency aborted here)\n|--barryvdh/laravel-dompdf v2.0.1 (requires illuminate/support ^6|^7|^8|^9|^10)\n|  `--bagisto/bagisto (requires barryvdh/laravel-dompdf ^2.0.0)\n|--diglactic/laravel-breadcrumbs v8.1.1 (requires laravel/framework ^6.0 || ^7.0 || ^8.0 || ^9.0 || ^10.0)\n|  `--bagisto/bagisto (requires diglactic/laravel-breadcrumbs ^8.0)\n|--intervention/imagecache 2.6.0 (requires illuminate/cache ^5.5|~6|~7|~8|~9|~10)\n|  `--bagisto/bagisto (requires intervention/imagecache ^2.5.2)\n|--intervention/imagecache 2.6.0 (requires illuminate/filesystem ^5.5|~6|~7|~8|~9|~10) (circular dependency aborted here)\n|--kalnoy/nestedset v6.0.3 (requires illuminate/database ^7.0|^8.0|^9.0|^10.0)\n|  `--bagisto/bagisto (requires kalnoy/nestedset ^6.0)\n|--kalnoy/nestedset v6.0.3 (requires illuminate/events ^7.0|^8.0|^9.0|^10.0) (circular dependency aborted here)\n|--kalnoy/nestedset v6.0.3 (requires illuminate/support ^7.0|^8.0|^9.0|^10.0) (circular dependency aborted here)\n|--laravel/sanctum v3.3.3 (requires illuminate/console ^9.21|^10.0)\n|  `--bagisto/bagisto (requires laravel/sanctum ^3.2)\n|--laravel/sanctum v3.3.3 (requires illuminate/contracts ^9.21|^10.0) (circular dependency aborted here)\n|--laravel/sanctum v3.3.3 (requires illuminate/database ^9.21|^10.0) (circular dependency aborted here)\n|--laravel/sanctum v3.3.3 (requires illuminate/support ^9.21|^10.0) (circular dependency aborted here)\n|--maatwebsite/excel 3.1.52 (requires illuminate/support 5.8.*||^6.0||^7.0||^8.0||^9.0||^10.0)\n|  `--bagisto/bagisto (requires maatwebsite/excel ^3.1.46)\n|--openai-php/laravel v0.7.8 (requires laravel/framework ^9.46.0|^10.14.1)\n|  `--bagisto/bagisto (requires openai-php/laravel ^0.7.8)\n|--prettus/l5-repository 2.9.0 (requires illuminate/config ~5.0|~6.0|~7.0|^8.0|^9.0|^10.0)\n|  `--bagisto/bagisto (requires prettus/l5-repository ^2.6)\n|--prettus/l5-repository 2.9.0 (requires illuminate/console ~5.0|~6.0|~7.0|^8.0|^9.0|^10.0) (circular dependency aborted here)\n|--prettus/l5-repository 2.9.0 (requires illuminate/database ~5.0|~6.0|~7.0|^8.0|^9.0|^10.0) (circular dependency aborted here)\n|--prettus/l5-repository 2.9.0 (requires illuminate/filesystem ~5.0|~6.0|~7.0|^8.0|^9.0|^10.0) (circular dependency aborted here)\n|--prettus/l5-repository 2.9.0 (requires illuminate/http ~5.0|~6.0|~7.0|^8.0|^9.0|^10.0) (circular dependency aborted here)\n|--prettus/l5-repository 2.9.0 (requires illuminate/pagination ~5.0|~6.0|~7.0|^8.0|^9.0|^10.0) (circular dependency aborted here)\n|--prettus/l5-repository 2.9.0 (requires illuminate/support ~5.0|~6.0|~7.0|^8.0|^9.0|^10.0) (circular dependency aborted here)\n|--prettus/l5-repository 2.9.0 (requires illuminate/validation ~5.0|~6.0|~7.0|^8.0|^9.0|^10.0) (circular dependency aborted here)\n|--prettus/laravel-validation 1.5.0 (requires illuminate/support ~5.4|^6.0|^7.0|^8.0|^9.0|^10.0)\n|  `--prettus/l5-repository 2.9.0 (requires prettus/laravel-validation ~1.1|~1.2|~1.3|~1.4)\n|     `--bagisto/bagisto (requires prettus/l5-repository ^2.6)\n|--prettus/laravel-validation 1.5.0 (requires illuminate/validation ~5.4|^6.0|^7.0|^8.0|^9.0|^10.0) (circular dependency aborted here)\n|--shetabit/visitor v4.1.0 (requires illuminate/support ^5.1|6.*|7.*|8.*|9.*|10.*)\n|  `--bagisto/bagisto (requires shetabit/visitor ^4.1)\n|--spatie/crawler 7.1.3 (requires illuminate/collections ^8.38|^9.0|^10.0)\n|  `--spatie/laravel-sitemap 6.4.0 (requires spatie/crawler ^7.0)\n|     `--bagisto/bagisto (requires spatie/laravel-sitemap ^6.2)\n|--spatie/laravel-responsecac\n[TRUNCATED: 9965 bytes of output omitted]","stderr_excerpt":"Not finding what you were looking for? Try calling `composer require \"laravel/framework:^11.0\" --dry-run` to get another view on the problem.\n"},{"package":"php","constraint":"8.3.0","command":["[COMPOSER_EXECUTABLE]","prohibits","php","8.3.0","--tree","--locked","--no-scripts","--no-plugins","--no-interaction"],"exit_code":0,"outcome":"success","stdout_excerpt":"","stderr_excerpt":"There is no installed package depending on \"php\" in versions not matching 8.3.0\n"}]}``
- `stage-root-change-1` (`E2`, high confidence): Recorded an analyzer-only root constraint change for stage laravel-10-to-11. Context: `{"stage_id":"laravel-10-to-11","package":"laravel/framework","from_constraint":"^10.0","to_constraint":"^11.0","supporting_evidence":["laravel-stage-target-1"]}`
- `stage-attempt-2` (`E1`, high confidence): Executed Composer attempt 2 for stage laravel-10-to-11. Context: `{"stage_id":"laravel-10-to-11","attempt":2,"strategy":"root_constraint_remediation","scenario":"laravel-10-to-11-attempt-2-root_constraint_remediation","outcome":"solver_failure"}`
- `lock-metadata-5` (`E2`, high confidence): Composer lock metadata marks intervention/imagecache as abandoned. Context: `{"package":"intervention/imagecache","locked_version":"2.6.0","direct":true,"abandoned_alternative":null,"abandoned_alternative_type":null}`
- `lock-metadata-6` (`E2`, high confidence): Composer lock metadata marks paypal/paypal-checkout-sdk as abandoned. Context: `{"package":"paypal/paypal-checkout-sdk","locked_version":"1.0.1","direct":true,"abandoned_alternative":null,"abandoned_alternative_type":null}`
- `solver-7` (`E1`, high confidence): Composer scenario "laravel-10-to-11-attempt-2-root_constraint_remediation" failed. Context: ``{"scenario":"laravel-10-to-11-attempt-2-root_constraint_remediation","targets":[{"package":"laravel/framework","constraint":"^11.0"},{"package":"laravel/sanctum","constraint":"^4.0"},{"package":"php","constraint":"8.3.0"}],"exit_code":2,"output_excerpt":"Loading composer repositories with package information\nUpdating dependencies\nYour requirements could not be resolved to an installable set of packages.\n\n  Problem 1\n    - Root composer.json requires PHP extension ext-calendar * but it is missing from your system. Install or enable PHP's calendar extension.\n\n      Alternatively you can require one of these packages that provide the extension (or parts of it):\n      Keep in mind that the suggestions are automated and may not be valid or safe to use\n      - fisharebest/ext-calendar Implementation of the Arabic (Hijri), French, Gregorian, Jewish, Julian and Persian (Jalali) calenda\n      - condorcet-php/php-calendars Pure PHP implementation of the Arabic (Hijri), French, Gregorian, Jewish, Julian and Persian (Jalali\n\n  Problem 2\n    - Root composer.json requires PHP extension ext-intl * but it is missing from your system. Install or enable PHP's intl extension.\n\n      Alternatively you can require one of these packages that provide the extension (or parts of it):\n      Keep in mind that the suggestions are automated and may not be valid or safe to use\n      - phuture/continuum A forward-compatibility layer bringing tomorrow\u2019s PHP features to today\u2019s runtimes.\n\n  Problem 3\n    - Root composer.json requires PHP extension ext-pdo_mysql * but it is missing from your system. Install or enable PHP's pdo_mysql extension.\n  Problem 4\n    - Root composer.json requires laravel/framework ^11.0, found laravel/framework[v11.0.0, ..., v11.57.0] but these were not loaded, because they are affected by security advisories (\"PKSA-d5tc-s1qs-h781\", \"PKSA-m5cs-t1y6-qpcs\", \"PKSA-3r5d-mb8f-1qw9\", \"PKSA-mdq4-51ck-6kdq\", \"PKSA-8qx3-n5y5-vvnd\", \"PKSA-q46n-4fdk-zjr4\", \"PKSA-qzrn-rnz3-85w1\", \"PKSA-w7xr-vk7n-rstm\"). Go to [REDACTED_URL] to find advisory details. To ignore the advisories, add their IDs to the \"policy.advisories.ignore-id\" config or add the package to \"policy.advisories.ignore\". To turn the feature off entirely, you can set \"poli","diagnostics":[{"package":"laravel/framework","constraint":"^11.0","command":["[COMPOSER_EXECUTABLE]","prohibits","laravel/framework","^11.0","--tree","--locked","--no-scripts","--no-plugins","--no-interaction"],"exit_code":1,"outcome":"success","stdout_excerpt":"laravel/framework v10.41.0 The Laravel Framework.\n|--astrotomic/laravel-translatable v11.12.1 (requires illuminate/contracts ^8.0 || ^9.0 || ^10.0)\n|  `--bagisto/bagisto (requires astrotomic/laravel-translatable ^11.0.0)\n|--astrotomic/laravel-translatable v11.12.1 (requires illuminate/database ^8.0 || ^9.0 || ^10.0) (circular dependency aborted here)\n|--astrotomic/laravel-translatable v11.12.1 (requires illuminate/support ^8.0 || ^9.0 || ^10.0) (circular dependency aborted here)\n|--barryvdh/laravel-dompdf v2.0.1 (requires illuminate/support ^6|^7|^8|^9|^10)\n|  `--bagisto/bagisto (requires barryvdh/laravel-dompdf ^2.0.0)\n|--diglactic/laravel-breadcrumbs v8.1.1 (requires laravel/framework ^6.0 || ^7.0 || ^8.0 || ^9.0 || ^10.0)\n|  `--bagisto/bagisto (requires diglactic/laravel-breadcrumbs ^8.0)\n|--intervention/imagecache 2.6.0 (requires illuminate/cache ^5.5|~6|~7|~8|~9|~10)\n|  `--bagisto/bagisto (requires intervention/imagecache ^2.5.2)\n|--intervention/imagecache 2.6.0 (requires illuminate/filesystem ^5.5|~6|~7|~8|~9|~10) (circular dependency aborted here)\n|--kalnoy/nestedset v6.0.3 (requires illuminate/database ^7.0|^8.0|^9.0|^10.0)\n|  `--bagisto/bagisto (requires kalnoy/nestedset ^6.0)\n|--kalnoy/nestedset v6.0.3 (requires illuminate/events ^7.0|^8.0|^9.0|^10.0) (circular dependency aborted here)\n|--kalnoy/nestedset v6.0.3 (requires illuminate/support ^7.0|^8.0|^9.0|^10.0) (circular dependency aborted here)\n|--laravel/sanctum v3.3.3 (requires illuminate/console ^9.21|^10.0)\n|  `--bagisto/bagisto (requires laravel/sanctum ^4.0)\n|--laravel/sanctum v3.3.3 (requires illuminate/contracts ^9.21|^10.0) (circular dependency aborted here)\n|--laravel/sanctum v3.3.3 (requires illuminate/database ^9.21|^10.0) (circular dependency aborted here)\n|--laravel/sanctum v3.3.3 (requires illuminate/support ^9.21|^10.0) (circular dependency aborted here)\n|--maatwebsite/excel 3.1.52 (requires illuminate/support 5.8.*||^6.0||^7.0||^8.0||^9.0||^10.0)\n|  `--bagisto/bagisto (requires maatwebsite/excel ^3.1.46)\n|--openai-php/laravel v0.7.8 (requires laravel/framework ^9.46.0|^10.14.1)\n|  `--bagisto/bagisto (requires openai-php/laravel ^0.7.8)\n|--prettus/l5-repository 2.9.0 (requires illuminate/config ~5.0|~6.0|~7.0|^8.0|^9.0|^10.0)\n|  `--bagisto/bagisto (requires prettus/l5-repository ^2.6)\n|--prettus/l5-repository 2.9.0 (requires illuminate/console ~5.0|~6.0|~7.0|^8.0|^9.0|^10.0) (circular dependency aborted here)\n|--prettus/l5-repository 2.9.0 (requires illuminate/database ~5.0|~6.0|~7.0|^8.0|^9.0|^10.0) (circular dependency aborted here)\n|--prettus/l5-repository 2.9.0 (requires illuminate/filesystem ~5.0|~6.0|~7.0|^8.0|^9.0|^10.0) (circular dependency aborted here)\n|--prettus/l5-repository 2.9.0 (requires illuminate/http ~5.0|~6.0|~7.0|^8.0|^9.0|^10.0) (circular dependency aborted here)\n|--prettus/l5-repository 2.9.0 (requires illuminate/pagination ~5.0|~6.0|~7.0|^8.0|^9.0|^10.0) (circular dependency aborted here)\n|--prettus/l5-repository 2.9.0 (requires illuminate/support ~5.0|~6.0|~7.0|^8.0|^9.0|^10.0) (circular dependency aborted here)\n|--prettus/l5-repository 2.9.0 (requires illuminate/validation ~5.0|~6.0|~7.0|^8.0|^9.0|^10.0) (circular dependency aborted here)\n|--prettus/laravel-validation 1.5.0 (requires illuminate/support ~5.4|^6.0|^7.0|^8.0|^9.0|^10.0)\n|  `--prettus/l5-repository 2.9.0 (requires prettus/laravel-validation ~1.1|~1.2|~1.3|~1.4)\n|     `--bagisto/bagisto (requires prettus/l5-repository ^2.6)\n|--prettus/laravel-validation 1.5.0 (requires illuminate/validation ~5.4|^6.0|^7.0|^8.0|^9.0|^10.0) (circular dependency aborted here)\n|--shetabit/visitor v4.1.0 (requires illuminate/support ^5.1|6.*|7.*|8.*|9.*|10.*)\n|  `--bagisto/bagisto (requires shetabit/visitor ^4.1)\n|--spatie/crawler 7.1.3 (requires illuminate/collections ^8.38|^9.0|^10.0)\n|  `--spatie/laravel-sitemap 6.4.0 (requires spatie/crawler ^7.0)\n|     `--bagisto/bagisto (requires spatie/laravel-sitemap ^6.2)\n|--spatie/laravel-responsecac\n[TRUNCATED: 9965 bytes of output omitted]","stderr_excerpt":"Not finding what you were looking for? Try calling `composer require \"laravel/framework:^11.0\" --dry-run` to get another view on the problem.\n"},{"package":"laravel/sanctum","constraint":"^4.0","command":["[COMPOSER_EXECUTABLE]","prohibits","laravel/sanctum","^4.0","--tree","--locked","--no-scripts","--no-plugins","--no-interaction"],"exit_code":1,"outcome":"success","stdout_excerpt":"laravel/sanctum v3.3.3 Laravel Sanctum provides a featherweight authentication system for SPAs and simple APIs.\n|--laravel/sanctum v4.3.3 (requires illuminate/console ^11.0|^12.0|^13.0) (circular dependency aborted here)\n|--bagisto/bagisto (does not require illuminate/console but v10.41.0 is installed) (circular dependency aborted here)\n|--laravel/sanctum v4.3.3 (requires illuminate/contracts ^11.0|^12.0|^13.0) (circular dependency aborted here)\n|--bagisto/bagisto (does not require illuminate/contracts but v10.41.0 is installed) (circular dependency aborted here)\n|--laravel/sanctum v4.3.3 (requires illuminate/database ^11.0|^12.0|^13.0) (circular dependency aborted here)\n|--bagisto/bagisto (does not require illuminate/database but v10.41.0 is installed) (circular dependency aborted here)\n|--laravel/sanctum v4.3.3 (requires illuminate/support ^11.0|^12.0|^13.0) (circular dependency aborted here)\n|--bagisto/bagisto (does not require illuminate/support but v10.41.0 is installed) (circular dependency aborted here)\n|--laravel/sanctum v4.3.3 (requires symfony/console ^7.0|^8.0) (circular dependency aborted here)\n`--bagisto/bagisto (does not require symfony/console but v6.4.2 is installed) (circular dependency aborted here)\n","stderr_excerpt":"Not finding what you were looking for? Try calling `composer require \"laravel/sanctum:^4.0\" --dry-run` to get another view on the problem.\n"},{"package":"php","constraint":"8.3.0","command":["[COMPOSER_EXECUTABLE]","prohibits","php","8.3.0","--tree","--locked","--no-scripts","--no-plugins","--no-interaction"],"exit_code":0,"outcome":"success","stdout_excerpt":"","stderr_excerpt":"There is no installed package depending on \"php\" in versions not matching 8.3.0\n"}]}``
- `stage-root-change-2` (`E2`, high confidence): Recorded an analyzer-only root constraint change for stage laravel-10-to-11. Context: `{"stage_id":"laravel-10-to-11","package":"laravel/framework","from_constraint":"^10.0","to_constraint":"^11.0","supporting_evidence":["laravel-stage-target-1"]}`
- `stage-root-change-3` (`E2`, high confidence): Recorded an analyzer-only root constraint change for stage laravel-10-to-11. Context: `{"stage_id":"laravel-10-to-11","package":"laravel/sanctum","from_constraint":"^3.2","to_constraint":"^4.0","supporting_evidence":["laravel-stage-remediation-2"]}`
- `stage-attempt-3` (`E1`, high confidence): Executed Composer attempt 3 for stage laravel-10-to-11. Context: `{"stage_id":"laravel-10-to-11","attempt":3,"strategy":"root_and_locked_package_remediation","scenario":"laravel-10-to-11-attempt-3-root_and_locked_package_remediation","outcome":"solver_failure"}`
- `lock-metadata-7` (`E2`, high confidence): Composer lock metadata marks intervention/imagecache as abandoned. Context: `{"package":"intervention/imagecache","locked_version":"2.6.0","direct":true,"abandoned_alternative":null,"abandoned_alternative_type":null}`
- `lock-metadata-8` (`E2`, high confidence): Composer lock metadata marks paypal/paypal-checkout-sdk as abandoned. Context: `{"package":"paypal/paypal-checkout-sdk","locked_version":"1.0.1","direct":true,"abandoned_alternative":null,"abandoned_alternative_type":null}`
- `solver-8` (`E1`, high confidence): Composer scenario "laravel-10-to-11-attempt-3-root_and_locked_package_remediation" failed. Context: ``{"scenario":"laravel-10-to-11-attempt-3-root_and_locked_package_remediation","targets":[{"package":"laravel/framework","constraint":"^11.0"},{"package":"laravel/sanctum","constraint":"^4.0"},{"package":"nunomaduro/collision","constraint":"^8.1"},{"package":"php","constraint":"8.3.0"},{"package":"phpunit/phpunit","constraint":"^10.5.35|^11.0.1|^12.0.1"}],"exit_code":2,"output_excerpt":"Loading composer repositories with package information\nUpdating dependencies\nYour requirements could not be resolved to an installable set of packages.\n\n  Problem 1\n    - Root composer.json requires PHP extension ext-calendar * but it is missing from your system. Install or enable PHP's calendar extension.\n\n      Alternatively you can require one of these packages that provide the extension (or parts of it):\n      Keep in mind that the suggestions are automated and may not be valid or safe to use\n      - fisharebest/ext-calendar Implementation of the Arabic (Hijri), French, Gregorian, Jewish, Julian and Persian (Jalali) calenda\n      - condorcet-php/php-calendars Pure PHP implementation of the Arabic (Hijri), French, Gregorian, Jewish, Julian and Persian (Jalali\n\n  Problem 2\n    - Root composer.json requires PHP extension ext-intl * but it is missing from your system. Install or enable PHP's intl extension.\n\n      Alternatively you can require one of these packages that provide the extension (or parts of it):\n      Keep in mind that the suggestions are automated and may not be valid or safe to use\n      - phuture/continuum A forward-compatibility layer bringing tomorrow\u2019s PHP features to today\u2019s runtimes.\n\n  Problem 3\n    - Root composer.json requires PHP extension ext-pdo_mysql * but it is missing from your system. Install or enable PHP's pdo_mysql extension.\n  Problem 4\n    - Root composer.json requires laravel/framework ^11.0, found laravel/framework[v11.0.0, ..., v11.57.0] but these were not loaded, because they are affected by security advisories (\"PKSA-d5tc-s1qs-h781\", \"PKSA-m5cs-t1y6-qpcs\", \"PKSA-3r5d-mb8f-1qw9\", \"PKSA-mdq4-51ck-6kdq\", \"PKSA-8qx3-n5y5-vvnd\", \"PKSA-q46n-4fdk-zjr4\", \"PKSA-qzrn-rnz3-85w1\", \"PKSA-w7xr-vk7n-rstm\"). Go to [REDACTED_URL] to find advisory details. To ignore the advisories, add their IDs to the \"policy.advisories.ignore-id\" config or add the package to \"policy.advisories.ignore\". To turn the feature off entirely, you can set \"poli","diagnostics":[{"package":"laravel/framework","constraint":"^11.0","command":["[COMPOSER_EXECUTABLE]","prohibits","laravel/framework","^11.0","--tree","--locked","--no-scripts","--no-plugins","--no-interaction"],"exit_code":1,"outcome":"success","stdout_excerpt":"laravel/framework v10.41.0 The Laravel Framework.\n|--astrotomic/laravel-translatable v11.12.1 (requires illuminate/contracts ^8.0 || ^9.0 || ^10.0)\n|  `--bagisto/bagisto (requires astrotomic/laravel-translatable ^11.0.0)\n|--astrotomic/laravel-translatable v11.12.1 (requires illuminate/database ^8.0 || ^9.0 || ^10.0) (circular dependency aborted here)\n|--astrotomic/laravel-translatable v11.12.1 (requires illuminate/support ^8.0 || ^9.0 || ^10.0) (circular dependency aborted here)\n|--barryvdh/laravel-dompdf v2.0.1 (requires illuminate/support ^6|^7|^8|^9|^10)\n|  `--bagisto/bagisto (requires barryvdh/laravel-dompdf ^2.0.0)\n|--diglactic/laravel-breadcrumbs v8.1.1 (requires laravel/framework ^6.0 || ^7.0 || ^8.0 || ^9.0 || ^10.0)\n|  `--bagisto/bagisto (requires diglactic/laravel-breadcrumbs ^8.0)\n|--intervention/imagecache 2.6.0 (requires illuminate/cache ^5.5|~6|~7|~8|~9|~10)\n|  `--bagisto/bagisto (requires intervention/imagecache ^2.5.2)\n|--intervention/imagecache 2.6.0 (requires illuminate/filesystem ^5.5|~6|~7|~8|~9|~10) (circular dependency aborted here)\n|--kalnoy/nestedset v6.0.3 (requires illuminate/database ^7.0|^8.0|^9.0|^10.0)\n|  `--bagisto/bagisto (requires kalnoy/nestedset ^6.0)\n|--kalnoy/nestedset v6.0.3 (requires illuminate/events ^7.0|^8.0|^9.0|^10.0) (circular dependency aborted here)\n|--kalnoy/nestedset v6.0.3 (requires illuminate/support ^7.0|^8.0|^9.0|^10.0) (circular dependency aborted here)\n|--laravel/sanctum v3.3.3 (requires illuminate/console ^9.21|^10.0)\n|  `--bagisto/bagisto (requires laravel/sanctum ^4.0)\n|--laravel/sanctum v3.3.3 (requires illuminate/contracts ^9.21|^10.0) (circular dependency aborted here)\n|--laravel/sanctum v3.3.3 (requires illuminate/database ^9.21|^10.0) (circular dependency aborted here)\n|--laravel/sanctum v3.3.3 (requires illuminate/support ^9.21|^10.0) (circular dependency aborted here)\n|--maatwebsite/excel 3.1.52 (requires illuminate/support 5.8.*||^6.0||^7.0||^8.0||^9.0||^10.0)\n|  `--bagisto/bagisto (requires maatwebsite/excel ^3.1.46)\n|--openai-php/laravel v0.7.8 (requires laravel/framework ^9.46.0|^10.14.1)\n|  `--bagisto/bagisto (requires openai-php/laravel ^0.7.8)\n|--prettus/l5-repository 2.9.0 (requires illuminate/config ~5.0|~6.0|~7.0|^8.0|^9.0|^10.0)\n|  `--bagisto/bagisto (requires prettus/l5-repository ^2.6)\n|--prettus/l5-repository 2.9.0 (requires illuminate/console ~5.0|~6.0|~7.0|^8.0|^9.0|^10.0) (circular dependency aborted here)\n|--prettus/l5-repository 2.9.0 (requires illuminate/database ~5.0|~6.0|~7.0|^8.0|^9.0|^10.0) (circular dependency aborted here)\n|--prettus/l5-repository 2.9.0 (requires illuminate/filesystem ~5.0|~6.0|~7.0|^8.0|^9.0|^10.0) (circular dependency aborted here)\n|--prettus/l5-repository 2.9.0 (requires illuminate/http ~5.0|~6.0|~7.0|^8.0|^9.0|^10.0) (circular dependency aborted here)\n|--prettus/l5-repository 2.9.0 (requires illuminate/pagination ~5.0|~6.0|~7.0|^8.0|^9.0|^10.0) (circular dependency aborted here)\n|--prettus/l5-repository 2.9.0 (requires illuminate/support ~5.0|~6.0|~7.0|^8.0|^9.0|^10.0) (circular dependency aborted here)\n|--prettus/l5-repository 2.9.0 (requires illuminate/validation ~5.0|~6.0|~7.0|^8.0|^9.0|^10.0) (circular dependency aborted here)\n|--prettus/laravel-validation 1.5.0 (requires illuminate/support ~5.4|^6.0|^7.0|^8.0|^9.0|^10.0)\n|  `--prettus/l5-repository 2.9.0 (requires prettus/laravel-validation ~1.1|~1.2|~1.3|~1.4)\n|     `--bagisto/bagisto (requires prettus/l5-repository ^2.6)\n|--prettus/laravel-validation 1.5.0 (requires illuminate/validation ~5.4|^6.0|^7.0|^8.0|^9.0|^10.0) (circular dependency aborted here)\n|--shetabit/visitor v4.1.0 (requires illuminate/support ^5.1|6.*|7.*|8.*|9.*|10.*)\n|  `--bagisto/bagisto (requires shetabit/visitor ^4.1)\n|--spatie/crawler 7.1.3 (requires illuminate/collections ^8.38|^9.0|^10.0)\n|  `--spatie/laravel-sitemap 6.4.0 (requires spatie/crawler ^7.0)\n|     `--bagisto/bagisto (requires spatie/laravel-sitemap ^6.2)\n|--spatie/laravel-responsecac\n[TRUNCATED: 9965 bytes of output omitted]","stderr_excerpt":"Not finding what you were looking for? Try calling `composer require \"laravel/framework:^11.0\" --dry-run` to get another view on the problem.\n"},{"package":"laravel/sanctum","constraint":"^4.0","command":["[COMPOSER_EXECUTABLE]","prohibits","laravel/sanctum","^4.0","--tree","--locked","--no-scripts","--no-plugins","--no-interaction"],"exit_code":1,"outcome":"success","stdout_excerpt":"laravel/sanctum v3.3.3 Laravel Sanctum provides a featherweight authentication system for SPAs and simple APIs.\n|--laravel/sanctum v4.3.3 (requires illuminate/console ^11.0|^12.0|^13.0) (circular dependency aborted here)\n|--bagisto/bagisto (does not require illuminate/console but v10.41.0 is installed) (circular dependency aborted here)\n|--laravel/sanctum v4.3.3 (requires illuminate/contracts ^11.0|^12.0|^13.0) (circular dependency aborted here)\n|--bagisto/bagisto (does not require illuminate/contracts but v10.41.0 is installed) (circular dependency aborted here)\n|--laravel/sanctum v4.3.3 (requires illuminate/database ^11.0|^12.0|^13.0) (circular dependency aborted here)\n|--bagisto/bagisto (does not require illuminate/database but v10.41.0 is installed) (circular dependency aborted here)\n|--laravel/sanctum v4.3.3 (requires illuminate/support ^11.0|^12.0|^13.0) (circular dependency aborted here)\n|--bagisto/bagisto (does not require illuminate/support but v10.41.0 is installed) (circular dependency aborted here)\n|--laravel/sanctum v4.3.3 (requires symfony/console ^7.0|^8.0) (circular dependency aborted here)\n`--bagisto/bagisto (does not require symfony/console but v6.4.2 is installed) (circular dependency aborted here)\n","stderr_excerpt":"Not finding what you were looking for? Try calling `composer require \"laravel/sanctum:^4.0\" --dry-run` to get another view on the problem.\n"},{"package":"nunomaduro/collision","constraint":"^8.1","command":["[COMPOSER_EXECUTABLE]","prohibits","nunomaduro/collision","^8.1","--tree","--locked","--no-scripts","--no-plugins","--no-interaction"],"exit_code":1,"outcome":"success","stdout_excerpt":"nunomaduro/collision v7.10.0 Cli error handling for console/command-line PHP applications.\n|--nunomaduro/collision v8.9.5 (conflicts laravel/framework <11.48.0 || >=14.0.0) (circular dependency aborted here)\n|--nunomaduro/collision v8.9.5 (conflicts phpunit/phpunit <11.5.50 || >=14.0.0) (circular dependency aborted here)\n|--nunomaduro/collision v8.9.5 (requires filp/whoops ^2.18.4) (circular dependency aborted here)\n|--bagisto/bagisto (does not require filp/whoops but 2.15.4 is installed) (circular dependency aborted here)\n|--nunomaduro/collision v8.9.5 (requires nunomaduro/termwind ^2.4.0) (circular dependency aborted here)\n|--bagisto/bagisto (does not require nunomaduro/termwind but v1.15.1 is installed) (circular dependency aborted here)\n|--nunomaduro/collision v8.9.5 (requires symfony/console ^7.4.14 || ^8.1.1) (circular dependency aborted here)\n`--bagisto/bagisto (does not require symfony/console but v6.4.2 is installed) (circular dependency aborted here)\n","stderr_excerpt":"Not finding what you were looking for? Try calling `composer require --dev \"nunomaduro/collision:^8.1\" --dry-run` to get another view on the problem.\n"},{"package":"php","constraint":"8.3.0","command":["[COMPOSER_EXECUTABLE]","prohibits","php","8.3.0","--tree","--locked","--no-scripts","--no-plugins","--no-interaction"],"exit_code":0,"outcome":"success","stdout_excerpt":"","stderr_excerpt":"There is no installed package depending on \"php\" in versions not matching 8.3.0\n"},{"package":"phpunit/phpunit","constraint":"^10.5.35|^11.0.1|^12.0.1","command":["[COMPOSER_EXECUTABLE]","prohibits","phpunit/phpunit","^10.5.35|^11.0.1|^12.0.1","--tree","--locked","--no-scripts","--no-plugins","--no-interaction"],"exit_code":1,"outcome":"success","stdout_excerpt":"phpunit/phpunit 10.5.5 The PHP Unit Testing framework.\n|--pestphp/pest v2.31.0 (conflicts phpunit/phpunit >10.5.5) (circular dependency aborted here)\n|--phpunit/phpunit 12.5.40 (requires myclabs/deep-copy ^1.14.0) (circular dependency aborted here)\n|--bagisto/bagisto (does not require myclabs/deep-copy but 1.11.1 is installed) (circular dependency aborted here)\n|--phpunit/phpunit 12.5.40 (requires phar-io/manifest ^2.0.4) (circular dependency aborted here)\n|--bagisto/bagisto (does not require phar-io/manifest but 2.0.3 is installed) (circular dependency aborted here)\n|--phpunit/phpunit 12.5.40 (requires phpunit/php-code-coverage ^12.5.8) (circular dependency aborted here)\n|--bagisto/bagisto (does not require phpunit/php-code-coverage but 10.1.11 is installed) (circular dependency aborted here)\n|--phpunit/phpunit 12.5.40 (requires phpunit/php-file-iterator ^6.0.2) (circular dependency aborted here)\n|--bagisto/bagisto (does not require phpunit/php-file-iterator but 4.1.0 is installed) (circular dependency aborted here)\n|--phpunit/phpunit 12.5.40 (requires phpunit/php-invoker ^6.0.0) (circular dependency aborted here)\n|--bagisto/bagisto (does not require phpunit/php-invoker but 4.0.0 is installed) (circular dependency aborted here)\n|--phpunit/phpunit 12.5.40 (requires phpunit/php-text-template ^5.0.1) (circular dependency aborted here)\n|--bagisto/bagisto (does not require phpunit/php-text-template but 3.0.1 is installed) (circular dependency aborted here)\n|--phpunit/phpunit 12.5.40 (requires phpunit/php-timer ^8.0.0) (circular dependency aborted here)\n|--bagisto/bagisto (does not require phpunit/php-timer but 6.0.0 is installed) (circular dependency aborted here)\n|--phpunit/phpunit 12.5.40 (requires sebastian/cli-parser ^4.2.1) (circular dependency aborted here)\n|--bagisto/bagisto (does not require sebastian/cli-parser but 2.0.0 is installed) (circular dependency aborted here)\n|--phpunit/phpunit 12.5.40 (requires sebastian/comparator ^7.1.8) (circular dependency aborted here)\n|--bagisto/bagisto (does not require sebastian/comparator but 5.0.1 is installed) (circular dependency aborted here)\n|--phpunit/phpunit 12.5.40 (requires sebastian/diff ^7.0.1) (circular dependency aborted here)\n|--bagisto/bagisto (does not require sebastian/diff but 5.1.0 is installed) (circular dependency aborted here)\n|--phpunit/phpunit 12.5.40 (requires sebastian/environment ^8.1.2) (circular dependency aborted here)\n|--bagisto/bagisto (does not require sebastian/environment but 6.0.1 is installed) (circular dependency aborted here)\n|--phpunit/phpunit 12.5.40 (requires sebastian/exporter ^7.0.3) (circular dependency aborted here)\n|--bagisto/bagisto (does not require sebastian/exporter but 5.1.1 is installed) (circular dependency aborted here)\n|--phpunit/phpunit 12.5.40 (requires sebastian/global-state ^8.0.3) (circular dependency aborted here)\n|--bagisto/bagisto (does not require sebastian/global-state but 6.0.1 is installed) (circular dependency aborted here)\n|--phpunit/phpunit 12.5.40 (requires sebastian/object-enumerator ^7.0.0) (circular dependency aborted here)\n|--bagisto/bagisto (does not require sebastian/object-enumerator but 5.0.0 is installed) (circular dependency aborted here)\n|--phpunit/phpunit 12.5.40 (requires sebastian/recursion-context ^7.0.1) (circular dependency aborted here)\n|--bagisto/bagisto (does not require sebastian/recursion-context but 5.0.0 is installed) (circular dependency aborted here)\n|--phpunit/phpunit 12.5.40 (requires sebastian/type ^6.0.4) (circular dependency aborted here)\n|--bagisto/bagisto (does not require sebastian/type but 4.0.0 is installed) (circular dependency aborted here)\n|--phpunit/phpunit 12.5.40 (requires sebastian/version ^6.0.1) (circular dependency aborted here)\n`--bagisto/bagisto (does not require sebastian/version but 4.0.1 is installed) (circular dependency aborted here)\n","stderr_excerpt":"Not finding what you were looking for? Try calling `composer require --dev \"phpunit/phpunit:^10.5.35|^11.0.1|^12.0.1\" --dry-run` to get another view on the problem.\n"}]}``
- `stage-root-change-4` (`E2`, high confidence): Recorded an analyzer-only root constraint change for stage laravel-10-to-11. Context: `{"stage_id":"laravel-10-to-11","package":"laravel/framework","from_constraint":"^10.0","to_constraint":"^11.0","supporting_evidence":["laravel-stage-target-1"]}`
- `stage-root-change-5` (`E2`, high confidence): Recorded an analyzer-only root constraint change for stage laravel-10-to-11. Context: `{"stage_id":"laravel-10-to-11","package":"laravel/sanctum","from_constraint":"^3.2","to_constraint":"^4.0","supporting_evidence":["laravel-stage-remediation-2"]}`
- `stage-root-change-6` (`E2`, high confidence): Recorded an analyzer-only root constraint change for stage laravel-10-to-11. Context: `{"stage_id":"laravel-10-to-11","package":"nunomaduro/collision","from_constraint":"^7.0","to_constraint":"^8.1","supporting_evidence":["laravel-stage-remediation-1"]}`
- `stage-root-change-7` (`E2`, high confidence): Recorded an analyzer-only root constraint change for stage laravel-10-to-11. Context: `{"stage_id":"laravel-10-to-11","package":"phpunit/phpunit","from_constraint":"^10.0","to_constraint":"^10.5.35|^11.0.1|^12.0.1","supporting_evidence":["laravel-stage-remediation-3"]}`
- `stage-skipped-1` (`E1`, high confidence): Stage laravel-11-to-12 was skipped after the preceding stage stopped the candidate-state chain. Context: `{"stage_id":"laravel-11-to-12","preceding_status":"blocked","reason":"previous_stage_blocked"}`
- `stage-skipped-2` (`E1`, high confidence): Stage laravel-12-to-13 was skipped after the preceding stage stopped the candidate-state chain. Context: `{"stage_id":"laravel-12-to-13","preceding_status":"blocked","reason":"previous_stage_blocked"}`
- `source-1` (`E3`, high confidence): Detected Illuminate\Console\Scheduling\Schedule in app/Console/Kernel.php. Context: `{"file":"app/Console/Kernel.php","line":5,"usage_type":"namespace_import"}`
- `source-2` (`E3`, high confidence): Detected Illuminate\Foundation\Console\Kernel in app/Console/Kernel.php. Context: `{"file":"app/Console/Kernel.php","line":6,"usage_type":"namespace_import"}`
- `source-3` (`E3`, high confidence): Detected Illuminate\Foundation\Console\Kernel in app/Console/Kernel.php. Context: `{"file":"app/Console/Kernel.php","line":8,"usage_type":"inheritance"}`
- `source-4` (`E3`, high confidence): Detected base_path in app/Console/Kernel.php. Context: `{"file":"app/Console/Kernel.php","line":43,"usage_type":"function_call"}`
- `source-5` (`E3`, high confidence): Detected Illuminate\Foundation\Exceptions\Handler in app/Exceptions/Handler.php. Context: `{"file":"app/Exceptions/Handler.php","line":5,"usage_type":"namespace_import"}`
- `source-6` (`E3`, high confidence): Detected Throwable in app/Exceptions/Handler.php. Context: `{"file":"app/Exceptions/Handler.php","line":6,"usage_type":"namespace_import"}`
- `source-7` (`E3`, high confidence): Detected Illuminate\Foundation\Exceptions\Handler in app/Exceptions/Handler.php. Context: `{"file":"app/Exceptions/Handler.php","line":8,"usage_type":"inheritance"}`
- `source-8` (`E3`, high confidence): Detected Illuminate\Foundation\Auth\Access\AuthorizesRequests in app/Http/Controllers/Controller.php. Context: `{"file":"app/Http/Controllers/Controller.php","line":5,"usage_type":"namespace_import"}`
- `source-9` (`E3`, high confidence): Detected Illuminate\Foundation\Bus\DispatchesJobs in app/Http/Controllers/Controller.php. Context: `{"file":"app/Http/Controllers/Controller.php","line":6,"usage_type":"namespace_import"}`
- `source-10` (`E3`, high confidence): Detected Illuminate\Foundation\Validation\ValidatesRequests in app/Http/Controllers/Controller.php. Context: `{"file":"app/Http/Controllers/Controller.php","line":7,"usage_type":"namespace_import"}`
- `source-11` (`E3`, high confidence): Detected Illuminate\Routing\Controller in app/Http/Controllers/Controller.php. Context: `{"file":"app/Http/Controllers/Controller.php","line":8,"usage_type":"namespace_import"}`
- `source-12` (`E3`, high confidence): Detected Illuminate\Routing\Controller in app/Http/Controllers/Controller.php. Context: `{"file":"app/Http/Controllers/Controller.php","line":10,"usage_type":"inheritance"}`
- `source-13` (`E3`, high confidence): Detected Illuminate\Foundation\Auth\Access\AuthorizesRequests in app/Http/Controllers/Controller.php. Context: `{"file":"app/Http/Controllers/Controller.php","line":12,"usage_type":"trait_reference"}`
- `source-14` (`E3`, high confidence): Detected Illuminate\Foundation\Bus\DispatchesJobs in app/Http/Controllers/Controller.php. Context: `{"file":"app/Http/Controllers/Controller.php","line":12,"usage_type":"trait_reference"}`
- `source-15` (`E3`, high confidence): Detected Illuminate\Foundation\Validation\ValidatesRequests in app/Http/Controllers/Controller.php. Context: `{"file":"app/Http/Controllers/Controller.php","line":12,"usage_type":"trait_reference"}`
- `source-16` (`E3`, high confidence): Detected Illuminate\Foundation\Http\Kernel in app/Http/Kernel.php. Context: `{"file":"app/Http/Kernel.php","line":5,"usage_type":"namespace_import"}`
- `source-17` (`E3`, high confidence): Detected Illuminate\Foundation\Http\Kernel in app/Http/Kernel.php. Context: `{"file":"app/Http/Kernel.php","line":7,"usage_type":"inheritance"}`
- `source-18` (`E3`, high confidence): Detected App\Http\Middleware\TrustProxies in app/Http/Kernel.php. Context: `{"file":"app/Http/Kernel.php","line":18,"usage_type":"class_constant_access"}`
- `source-19` (`E3`, high confidence): Detected Illuminate\Http\Middleware\HandleCors in app/Http/Kernel.php. Context: `{"file":"app/Http/Kernel.php","line":19,"usage_type":"class_constant_access"}`
- `source-20` (`E3`, high confidence): Detected Webkul\Core\Http\Middleware\CheckForMaintenanceMode in app/Http/Kernel.php. Context: `{"file":"app/Http/Kernel.php","line":20,"usage_type":"class_constant_access"}`
- `source-21` (`E3`, high confidence): Detected Illuminate\Foundation\Http\Middleware\ValidatePostSize in app/Http/Kernel.php. Context: `{"file":"app/Http/Kernel.php","line":21,"usage_type":"class_constant_access"}`
- `source-22` (`E3`, high confidence): Detected App\Http\Middleware\TrimStrings in app/Http/Kernel.php. Context: `{"file":"app/Http/Kernel.php","line":22,"usage_type":"class_constant_access"}`
- `source-23` (`E3`, high confidence): Detected Webkul\Core\Http\Middleware\SecureHeaders in app/Http/Kernel.php. Context: `{"file":"app/Http/Kernel.php","line":23,"usage_type":"class_constant_access"}`
- `source-24` (`E3`, high confidence): Detected Webkul\Installer\Http\Middleware\CanInstall in app/Http/Kernel.php. Context: `{"file":"app/Http/Kernel.php","line":24,"usage_type":"class_constant_access"}`
- `source-25` (`E3`, high confidence): Detected App\Http\Middleware\EncryptCookies in app/Http/Kernel.php. Context: `{"file":"app/Http/Kernel.php","line":34,"usage_type":"class_constant_access"}`
- `source-26` (`E3`, high confidence): Detected Illuminate\Cookie\Middleware\AddQueuedCookiesToResponse in app/Http/Kernel.php. Context: `{"file":"app/Http/Kernel.php","line":35,"usage_type":"class_constant_access"}`
- `source-27` (`E3`, high confidence): Detected Illuminate\Session\Middleware\StartSession in app/Http/Kernel.php. Context: `{"file":"app/Http/Kernel.php","line":36,"usage_type":"class_constant_access"}`
- `source-28` (`E3`, high confidence): Detected Illuminate\View\Middleware\ShareErrorsFromSession in app/Http/Kernel.php. Context: `{"file":"app/Http/Kernel.php","line":37,"usage_type":"class_constant_access"}`
- `source-29` (`E3`, high confidence): Detected App\Http\Middleware\VerifyCsrfToken in app/Http/Kernel.php. Context: `{"file":"app/Http/Kernel.php","line":38,"usage_type":"class_constant_access"}`
- `source-30` (`E3`, high confidence): Detected Illuminate\Routing\Middleware\SubstituteBindings in app/Http/Kernel.php. Context: `{"file":"app/Http/Kernel.php","line":39,"usage_type":"class_constant_access"}`
- `source-31` (`E3`, high confidence): Detected Illuminate\Routing\Middleware\ThrottleRequests in app/Http/Kernel.php. Context: `{"file":"app/Http/Kernel.php","line":44,"usage_type":"class_constant_access"}`
- `source-32` (`E3`, high confidence): Detected Illuminate\Routing\Middleware\SubstituteBindings in app/Http/Kernel.php. Context: `{"file":"app/Http/Kernel.php","line":45,"usage_type":"class_constant_access"}`
- `source-33` (`E3`, high confidence): Detected Illuminate\Auth\Middleware\Authenticate in app/Http/Kernel.php. Context: `{"file":"app/Http/Kernel.php","line":57,"usage_type":"class_constant_access"}`
- `source-34` (`E3`, high confidence): Detected Illuminate\Auth\Middleware\AuthenticateWithBasicAuth in app/Http/Kernel.php. Context: `{"file":"app/Http/Kernel.php","line":58,"usage_type":"class_constant_access"}`
- `source-35` (`E3`, high confidence): Detected Illuminate\Session\Middleware\AuthenticateSession in app/Http/Kernel.php. Context: `{"file":"app/Http/Kernel.php","line":59,"usage_type":"class_constant_access"}`
- `source-36` (`E3`, high confidence): Detected Illuminate\Http\Middleware\SetCacheHeaders in app/Http/Kernel.php. Context: `{"file":"app/Http/Kernel.php","line":60,"usage_type":"class_constant_access"}`
- `source-37` (`E3`, high confidence): Detected Illuminate\Auth\Middleware\Authorize in app/Http/Kernel.php. Context: `{"file":"app/Http/Kernel.php","line":61,"usage_type":"class_constant_access"}`
- `source-38` (`E3`, high confidence): Detected App\Http\Middleware\RedirectIfAuthenticated in app/Http/Kernel.php. Context: `{"file":"app/Http/Kernel.php","line":62,"usage_type":"class_constant_access"}`
- `source-39` (`E3`, high confidence): Detected Illuminate\Routing\Middleware\ValidateSignature in app/Http/Kernel.php. Context: `{"file":"app/Http/Kernel.php","line":63,"usage_type":"class_constant_access"}`
- `source-40` (`E3`, high confidence): Detected Illuminate\Routing\Middleware\ThrottleRequests in app/Http/Kernel.php. Context: `{"file":"app/Http/Kernel.php","line":64,"usage_type":"class_constant_access"}`
- `source-41` (`E3`, high confidence): Detected Webkul\Shop\Http\Middleware\CacheResponse in app/Http/Kernel.php. Context: `{"file":"app/Http/Kernel.php","line":65,"usage_type":"class_constant_access"}`
- `source-42` (`E3`, high confidence): Detected App\Http\Middleware\TrustProxies in app/Http/Kernel.php. Context: `{"file":"app/Http/Kernel.php","line":18,"usage_type":"middleware_reference"}`
- `source-43` (`E3`, high confidence): Detected Illuminate\Http\Middleware\HandleCors in app/Http/Kernel.php. Context: `{"file":"app/Http/Kernel.php","line":19,"usage_type":"middleware_reference"}`
- `source-44` (`E3`, high confidence): Detected Webkul\Core\Http\Middleware\CheckForMaintenanceMode in app/Http/Kernel.php. Context: `{"file":"app/Http/Kernel.php","line":20,"usage_type":"middleware_reference"}`
- `source-45` (`E3`, high confidence): Detected Illuminate\Foundation\Http\Middleware\ValidatePostSize in app/Http/Kernel.php. Context: `{"file":"app/Http/Kernel.php","line":21,"usage_type":"middleware_reference"}`
- `source-46` (`E3`, high confidence): Detected App\Http\Middleware\TrimStrings in app/Http/Kernel.php. Context: `{"file":"app/Http/Kernel.php","line":22,"usage_type":"middleware_reference"}`
- `source-47` (`E3`, high confidence): Detected Webkul\Core\Http\Middleware\SecureHeaders in app/Http/Kernel.php. Context: `{"file":"app/Http/Kernel.php","line":23,"usage_type":"middleware_reference"}`
- `source-48` (`E3`, high confidence): Detected Webkul\Installer\Http\Middleware\CanInstall in app/Http/Kernel.php. Context: `{"file":"app/Http/Kernel.php","line":24,"usage_type":"middleware_reference"}`
- `source-49` (`E3`, high confidence): Detected App\Http\Middleware\EncryptCookies in app/Http/Kernel.php. Context: `{"file":"app/Http/Kernel.php","line":34,"usage_type":"middleware_reference"}`
- `source-50` (`E3`, high confidence): Detected Illuminate\Cookie\Middleware\AddQueuedCookiesToResponse in app/Http/Kernel.php. Context: `{"file":"app/Http/Kernel.php","line":35,"usage_type":"middleware_reference"}`
- `source-51` (`E3`, high confidence): Detected Illuminate\Session\Middleware\StartSession in app/Http/Kernel.php. Context: `{"file":"app/Http/Kernel.php","line":36,"usage_type":"middleware_reference"}`
- `source-52` (`E3`, high confidence): Detected Illuminate\View\Middleware\ShareErrorsFromSession in app/Http/Kernel.php. Context: `{"file":"app/Http/Kernel.php","line":37,"usage_type":"middleware_reference"}`
- `source-53` (`E3`, high confidence): Detected App\Http\Middleware\VerifyCsrfToken in app/Http/Kernel.php. Context: `{"file":"app/Http/Kernel.php","line":38,"usage_type":"middleware_reference"}`
- `source-54` (`E3`, high confidence): Detected Illuminate\Routing\Middleware\SubstituteBindings in app/Http/Kernel.php. Context: `{"file":"app/Http/Kernel.php","line":39,"usage_type":"middleware_reference"}`
- `source-55` (`E3`, high confidence): Detected Illuminate\Routing\Middleware\ThrottleRequests in app/Http/Kernel.php. Context: `{"file":"app/Http/Kernel.php","line":44,"usage_type":"middleware_reference"}`
- `source-56` (`E3`, high confidence): Detected Illuminate\Routing\Middleware\SubstituteBindings in app/Http/Kernel.php. Context: `{"file":"app/Http/Kernel.php","line":45,"usage_type":"middleware_reference"}`
- `source-57` (`E3`, high confidence): Detected Illuminate\Auth\Middleware\Authenticate in app/Http/Kernel.php. Context: `{"file":"app/Http/Kernel.php","line":57,"usage_type":"middleware_reference"}`
- `source-58` (`E3`, high confidence): Detected Illuminate\Auth\Middleware\AuthenticateWithBasicAuth in app/Http/Kernel.php. Context: `{"file":"app/Http/Kernel.php","line":58,"usage_type":"middleware_reference"}`
- `source-59` (`E3`, high confidence): Detected Illuminate\Session\Middleware\AuthenticateSession in app/Http/Kernel.php. Context: `{"file":"app/Http/Kernel.php","line":59,"usage_type":"middleware_reference"}`
- `source-60` (`E3`, high confidence): Detected Illuminate\Http\Middleware\SetCacheHeaders in app/Http/Kernel.php. Context: `{"file":"app/Http/Kernel.php","line":60,"usage_type":"middleware_reference"}`
- `source-61` (`E3`, high confidence): Detected Illuminate\Auth\Middleware\Authorize in app/Http/Kernel.php. Context: `{"file":"app/Http/Kernel.php","line":61,"usage_type":"middleware_reference"}`
- `source-62` (`E3`, high confidence): Detected App\Http\Middleware\RedirectIfAuthenticated in app/Http/Kernel.php. Context: `{"file":"app/Http/Kernel.php","line":62,"usage_type":"middleware_reference"}`
- `source-63` (`E3`, high confidence): Detected Illuminate\Routing\Middleware\ValidateSignature in app/Http/Kernel.php. Context: `{"file":"app/Http/Kernel.php","line":63,"usage_type":"middleware_reference"}`
- `source-64` (`E3`, high confidence): Detected Illuminate\Routing\Middleware\ThrottleRequests in app/Http/Kernel.php. Context: `{"file":"app/Http/Kernel.php","line":64,"usage_type":"middleware_reference"}`
- `source-65` (`E3`, high confidence): Detected Webkul\Shop\Http\Middleware\CacheResponse in app/Http/Kernel.php. Context: `{"file":"app/Http/Kernel.php","line":65,"usage_type":"middleware_reference"}`
- `source-66` (`E3`, high confidence): Detected Illuminate\Cookie\Middleware\EncryptCookies in app/Http/Middleware/EncryptCookies.php. Context: `{"file":"app/Http/Middleware/EncryptCookies.php","line":5,"usage_type":"namespace_import"}`
- `source-67` (`E3`, high confidence): Detected Illuminate\Cookie\Middleware\EncryptCookies in app/Http/Middleware/EncryptCookies.php. Context: `{"file":"app/Http/Middleware/EncryptCookies.php","line":7,"usage_type":"inheritance"}`
- `source-68` (`E3`, high confidence): Detected App\Providers\RouteServiceProvider in app/Http/Middleware/RedirectIfAuthenticated.php. Context: `{"file":"app/Http/Middleware/RedirectIfAuthenticated.php","line":5,"usage_type":"namespace_import"}`
- `source-69` (`E3`, high confidence): Detected Closure in app/Http/Middleware/RedirectIfAuthenticated.php. Context: `{"file":"app/Http/Middleware/RedirectIfAuthenticated.php","line":6,"usage_type":"namespace_import"}`
- `source-70` (`E3`, high confidence): Detected Illuminate\Http\Request in app/Http/Middleware/RedirectIfAuthenticated.php. Context: `{"file":"app/Http/Middleware/RedirectIfAuthenticated.php","line":7,"usage_type":"namespace_import"}`
- `source-71` (`E3`, high confidence): Detected Illuminate\Support\Facades\Auth in app/Http/Middleware/RedirectIfAuthenticated.php. Context: `{"file":"app/Http/Middleware/RedirectIfAuthenticated.php","line":8,"usage_type":"namespace_import"}`
- `source-72` (`E3`, high confidence): Detected Symfony\Component\HttpFoundation\Response in app/Http/Middleware/RedirectIfAuthenticated.php. Context: `{"file":"app/Http/Middleware/RedirectIfAuthenticated.php","line":9,"usage_type":"namespace_import"}`
- `source-73` (`E3`, high confidence): Detected Illuminate\Support\Facades\Auth in app/Http/Middleware/RedirectIfAuthenticated.php. Context: `{"file":"app/Http/Middleware/RedirectIfAuthenticated.php","line":23,"usage_type":"static_call"}`
- `source-74` (`E3`, high confidence): Detected redirect in app/Http/Middleware/RedirectIfAuthenticated.php. Context: `{"file":"app/Http/Middleware/RedirectIfAuthenticated.php","line":24,"usage_type":"function_call"}`
- `source-75` (`E3`, high confidence): Detected App\Providers\RouteServiceProvider in app/Http/Middleware/RedirectIfAuthenticated.php. Context: `{"file":"app/Http/Middleware/RedirectIfAuthenticated.php","line":24,"usage_type":"class_constant_access"}`
- `source-76` (`E3`, high confidence): Detected Illuminate\Foundation\Http\Middleware\TrimStrings in app/Http/Middleware/TrimStrings.php. Context: `{"file":"app/Http/Middleware/TrimStrings.php","line":5,"usage_type":"namespace_import"}`
- `source-77` (`E3`, high confidence): Detected Illuminate\Foundation\Http\Middleware\TrimStrings in app/Http/Middleware/TrimStrings.php. Context: `{"file":"app/Http/Middleware/TrimStrings.php","line":7,"usage_type":"inheritance"}`
- `source-78` (`E3`, high confidence): Detected Illuminate\Http\Middleware\TrustHosts in app/Http/Middleware/TrustHosts.php. Context: `{"file":"app/Http/Middleware/TrustHosts.php","line":5,"usage_type":"namespace_import"}`
- `source-79` (`E3`, high confidence): Detected Illuminate\Http\Middleware\TrustHosts in app/Http/Middleware/TrustHosts.php. Context: `{"file":"app/Http/Middleware/TrustHosts.php","line":7,"usage_type":"inheritance"}`
- `source-80` (`E3`, high confidence): Detected Illuminate\Http\Middleware\TrustProxies in app/Http/Middleware/TrustProxies.php. Context: `{"file":"app/Http/Middleware/TrustProxies.php","line":5,"usage_type":"namespace_import"}`
- `source-81` (`E3`, high confidence): Detected Illuminate\Http\Request in app/Http/Middleware/TrustProxies.php. Context: `{"file":"app/Http/Middleware/TrustProxies.php","line":6,"usage_type":"namespace_import"}`
- `source-82` (`E3`, high confidence): Detected Illuminate\Http\Middleware\TrustProxies in app/Http/Middleware/TrustProxies.php. Context: `{"file":"app/Http/Middleware/TrustProxies.php","line":8,"usage_type":"inheritance"}`
- `source-83` (`E3`, high confidence): Detected Illuminate\Http\Request in app/Http/Middleware/TrustProxies.php. Context: `{"file":"app/Http/Middleware/TrustProxies.php","line":23,"usage_type":"class_constant_access"}`
- `source-84` (`E3`, high confidence): Detected Illuminate\Http\Request in app/Http/Middleware/TrustProxies.php. Context: `{"file":"app/Http/Middleware/TrustProxies.php","line":24,"usage_type":"class_constant_access"}`
- `source-85` (`E3`, high confidence): Detected Illuminate\Http\Request in app/Http/Middleware/TrustProxies.php. Context: `{"file":"app/Http/Middleware/TrustProxies.php","line":25,"usage_type":"class_constant_access"}`
- `source-86` (`E3`, high confidence): Detected Illuminate\Http\Request in app/Http/Middleware/TrustProxies.php. Context: `{"file":"app/Http/Middleware/TrustProxies.php","line":26,"usage_type":"class_constant_access"}`
- `source-87` (`E3`, high confidence): Detected Illuminate\Http\Request in app/Http/Middleware/TrustProxies.php. Context: `{"file":"app/Http/Middleware/TrustProxies.php","line":27,"usage_type":"class_constant_access"}`
- `source-88` (`E3`, high confidence): Detected Illuminate\Foundation\Http\Middleware\VerifyCsrfToken in app/Http/Middleware/VerifyCsrfToken.php. Context: `{"file":"app/Http/Middleware/VerifyCsrfToken.php","line":5,"usage_type":"namespace_import"}`
- `source-89` (`E3`, high confidence): Detected Illuminate\Foundation\Http\Middleware\VerifyCsrfToken in app/Http/Middleware/VerifyCsrfToken.php. Context: `{"file":"app/Http/Middleware/VerifyCsrfToken.php","line":7,"usage_type":"inheritance"}`
- `source-90` (`E3`, high confidence): Detected Illuminate\Support\Facades\Artisan in app/Providers/AppServiceProvider.php. Context: `{"file":"app/Providers/AppServiceProvider.php","line":5,"usage_type":"namespace_import"}`
- `source-91` (`E3`, high confidence): Detected Illuminate\Support\Facades\ParallelTesting in app/Providers/AppServiceProvider.php. Context: `{"file":"app/Providers/AppServiceProvider.php","line":6,"usage_type":"namespace_import"}`
- `source-92` (`E3`, high confidence): Detected Illuminate\Support\Facades\Request in app/Providers/AppServiceProvider.php. Context: `{"file":"app/Providers/AppServiceProvider.php","line":7,"usage_type":"namespace_import"}`
- `source-93` (`E3`, high confidence): Detected Illuminate\Support\Facades\Schema in app/Providers/AppServiceProvider.php. Context: `{"file":"app/Providers/AppServiceProvider.php","line":8,"usage_type":"namespace_import"}`
- `source-94` (`E3`, high confidence): Detected Illuminate\Support\ServiceProvider in app/Providers/AppServiceProvider.php. Context: `{"file":"app/Providers/AppServiceProvider.php","line":9,"usage_type":"namespace_import"}`
- `source-95` (`E3`, high confidence): Detected Illuminate\Support\ServiceProvider in app/Providers/AppServiceProvider.php. Context: `{"file":"app/Providers/AppServiceProvider.php","line":11,"usage_type":"inheritance"}`
- `source-96` (`E3`, high confidence): Detected Illuminate\Support\Facades\Schema in app/Providers/AppServiceProvider.php. Context: `{"file":"app/Providers/AppServiceProvider.php","line":18,"usage_type":"static_call"}`
- `source-97` (`E3`, high confidence): Detected Illuminate\Support\Facades\ParallelTesting in app/Providers/AppServiceProvider.php. Context: `{"file":"app/Providers/AppServiceProvider.php","line":20,"usage_type":"static_call"}`
- `source-98` (`E3`, high confidence): Detected Illuminate\Support\Facades\Artisan in app/Providers/AppServiceProvider.php. Context: `{"file":"app/Providers/AppServiceProvider.php","line":21,"usage_type":"static_call"}`
- `source-99` (`E3`, high confidence): Detected array_map in app/Providers/AppServiceProvider.php. Context: `{"file":"app/Providers/AppServiceProvider.php","line":30,"usage_type":"function_call"}`
- `source-100` (`E3`, high confidence): Detected explode in app/Providers/AppServiceProvider.php. Context: `{"file":"app/Providers/AppServiceProvider.php","line":30,"usage_type":"function_call"}`
- `source-101` (`E3`, high confidence): Detected config in app/Providers/AppServiceProvider.php. Context: `{"file":"app/Providers/AppServiceProvider.php","line":30,"usage_type":"function_call"}`
- `source-102` (`E3`, high confidence): Detected array_filter in app/Providers/AppServiceProvider.php. Context: `{"file":"app/Providers/AppServiceProvider.php","line":32,"usage_type":"function_call"}`
- `source-103` (`E3`, high confidence): Detected in_array in app/Providers/AppServiceProvider.php. Context: `{"file":"app/Providers/AppServiceProvider.php","line":38,"usage_type":"function_call"}`
- `source-104` (`E3`, high confidence): Detected Illuminate\Support\Facades\Request in app/Providers/AppServiceProvider.php. Context: `{"file":"app/Providers/AppServiceProvider.php","line":38,"usage_type":"static_call"}`
- `source-105` (`E3`, high confidence): Detected Debugbar in app/Providers/AppServiceProvider.php. Context: `{"file":"app/Providers/AppServiceProvider.php","line":39,"usage_type":"static_call"}`
- `source-106` (`E3`, high confidence): Detected Debugbar in app/Providers/AppServiceProvider.php. Context: `{"file":"app/Providers/AppServiceProvider.php","line":41,"usage_type":"static_call"}`
- `source-107` (`E3`, high confidence): Detected App\Providers\AppServiceProvider in app/Providers/AppServiceProvider.php. Context: `{"file":"app/Providers/AppServiceProvider.php","line":11,"usage_type":"service_provider"}`
- `source-108` (`E3`, high confidence): Detected app.debug_allowed_ips in app/Providers/AppServiceProvider.php. Context: `{"file":"app/Providers/AppServiceProvider.php","line":30,"usage_type":"config_reference"}`
- `source-109` (`E3`, high confidence): Detected Illuminate\Foundation\Support\Providers\AuthServiceProvider in app/Providers/AuthServiceProvider.php. Context: `{"file":"app/Providers/AuthServiceProvider.php","line":6,"usage_type":"namespace_import"}`
- `source-110` (`E3`, high confidence): Detected Illuminate\Foundation\Support\Providers\AuthServiceProvider in app/Providers/AuthServiceProvider.php. Context: `{"file":"app/Providers/AuthServiceProvider.php","line":8,"usage_type":"inheritance"}`
- `source-111` (`E3`, high confidence): Detected Illuminate\Support\Facades\Broadcast in app/Providers/BroadcastServiceProvider.php. Context: `{"file":"app/Providers/BroadcastServiceProvider.php","line":5,"usage_type":"namespace_import"}`
- `source-112` (`E3`, high confidence): Detected Illuminate\Support\ServiceProvider in app/Providers/BroadcastServiceProvider.php. Context: `{"file":"app/Providers/BroadcastServiceProvider.php","line":6,"usage_type":"namespace_import"}`
- `source-113` (`E3`, high confidence): Detected Illuminate\Support\ServiceProvider in app/Providers/BroadcastServiceProvider.php. Context: `{"file":"app/Providers/BroadcastServiceProvider.php","line":8,"usage_type":"inheritance"}`
- `source-114` (`E3`, high confidence): Detected Illuminate\Support\Facades\Broadcast in app/Providers/BroadcastServiceProvider.php. Context: `{"file":"app/Providers/BroadcastServiceProvider.php","line":15,"usage_type":"static_call"}`
- `source-115` (`E3`, high confidence): Detected base_path in app/Providers/BroadcastServiceProvider.php. Context: `{"file":"app/Providers/BroadcastServiceProvider.php","line":17,"usage_type":"function_call"}`
- `source-116` (`E3`, high confidence): Detected App\Providers\BroadcastServiceProvider in app/Providers/BroadcastServiceProvider.php. Context: `{"file":"app/Providers/BroadcastServiceProvider.php","line":8,"usage_type":"service_provider"}`
- `source-117` (`E3`, high confidence): Detected Illuminate\Foundation\Support\Providers\EventServiceProvider in app/Providers/EventServiceProvider.php. Context: `{"file":"app/Providers/EventServiceProvider.php","line":5,"usage_type":"namespace_import"}`
- `source-118` (`E3`, high confidence): Detected Illuminate\Foundation\Support\Providers\EventServiceProvider in app/Providers/EventServiceProvider.php. Context: `{"file":"app/Providers/EventServiceProvider.php","line":7,"usage_type":"inheritance"}`
- `source-119` (`E3`, high confidence): Detected Illuminate\Cache\RateLimiting\Limit in app/Providers/RouteServiceProvider.php. Context: `{"file":"app/Providers/RouteServiceProvider.php","line":5,"usage_type":"namespace_import"}`
- `source-120` (`E3`, high confidence): Detected Illuminate\Foundation\Support\Providers\RouteServiceProvider in app/Providers/RouteServiceProvider.php. Context: `{"file":"app/Providers/RouteServiceProvider.php","line":6,"usage_type":"namespace_import"}`
- `source-121` (`E3`, high confidence): Detected Illuminate\Http\Request in app/Providers/RouteServiceProvider.php. Context: `{"file":"app/Providers/RouteServiceProvider.php","line":7,"usage_type":"namespace_import"}`
- `source-122` (`E3`, high confidence): Detected Illuminate\Support\Facades\RateLimiter in app/Providers/RouteServiceProvider.php. Context: `{"file":"app/Providers/RouteServiceProvider.php","line":8,"usage_type":"namespace_import"}`
- `source-123` (`E3`, high confidence): Detected Illuminate\Support\Facades\Route in app/Providers/RouteServiceProvider.php. Context: `{"file":"app/Providers/RouteServiceProvider.php","line":9,"usage_type":"namespace_import"}`
- `source-124` (`E3`, high confidence): Detected Illuminate\Foundation\Support\Providers\RouteServiceProvider in app/Providers/RouteServiceProvider.php. Context: `{"file":"app/Providers/RouteServiceProvider.php","line":11,"usage_type":"inheritance"}`
- `source-125` (`E3`, high confidence): Detected Illuminate\Support\Facades\RateLimiter in app/Providers/RouteServiceProvider.php. Context: `{"file":"app/Providers/RouteServiceProvider.php","line":27,"usage_type":"static_call"}`
- `source-126` (`E3`, high confidence): Detected Illuminate\Cache\RateLimiting\Limit in app/Providers/RouteServiceProvider.php. Context: `{"file":"app/Providers/RouteServiceProvider.php","line":28,"usage_type":"static_call"}`
- `source-127` (`E3`, high confidence): Detected Illuminate\Support\Facades\Route in app/Providers/RouteServiceProvider.php. Context: `{"file":"app/Providers/RouteServiceProvider.php","line":32,"usage_type":"static_call"}`
- `source-128` (`E3`, high confidence): Detected base_path in app/Providers/RouteServiceProvider.php. Context: `{"file":"app/Providers/RouteServiceProvider.php","line":34,"usage_type":"function_call"}`
- `source-129` (`E3`, high confidence): Detected Illuminate\Support\Facades\Route in app/Providers/RouteServiceProvider.php. Context: `{"file":"app/Providers/RouteServiceProvider.php","line":36,"usage_type":"static_call"}`
- `source-130` (`E3`, high confidence): Detected base_path in app/Providers/RouteServiceProvider.php. Context: `{"file":"app/Providers/RouteServiceProvider.php","line":37,"usage_type":"function_call"}`
- `source-131` (`E3`, high confidence): Detected Illuminate\Foundation\Application in bootstrap/app.php. Context: `{"file":"bootstrap/app.php","line":14,"usage_type":"instantiated_class"}`
- `source-132` (`E3`, high confidence): Detected realpath in bootstrap/app.php. Context: `{"file":"bootstrap/app.php","line":15,"usage_type":"function_call"}`
- `source-133` (`E3`, high confidence): Detected Illuminate\Contracts\Http\Kernel in bootstrap/app.php. Context: `{"file":"bootstrap/app.php","line":30,"usage_type":"class_constant_access"}`
- `source-134` (`E3`, high confidence): Detected App\Http\Kernel in bootstrap/app.php. Context: `{"file":"bootstrap/app.php","line":31,"usage_type":"class_constant_access"}`
- `source-135` (`E3`, high confidence): Detected Illuminate\Contracts\Console\Kernel in bootstrap/app.php. Context: `{"file":"bootstrap/app.php","line":35,"usage_type":"class_constant_access"}`
- `source-136` (`E3`, high confidence): Detected App\Console\Kernel in bootstrap/app.php. Context: `{"file":"bootstrap/app.php","line":36,"usage_type":"class_constant_access"}`
- `source-137` (`E3`, high confidence): Detected Illuminate\Contracts\Debug\ExceptionHandler in bootstrap/app.php. Context: `{"file":"bootstrap/app.php","line":40,"usage_type":"class_constant_access"}`
- `source-138` (`E3`, high confidence): Detected App\Exceptions\Handler in bootstrap/app.php. Context: `{"file":"bootstrap/app.php","line":41,"usage_type":"class_constant_access"}`
- `source-139` (`E3`, high confidence): Detected Illuminate\Support\Facades\Facade in config/app.php. Context: `{"file":"config/app.php","line":3,"usage_type":"namespace_import"}`
- `source-140` (`E3`, high confidence): Detected Illuminate\Support\ServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":4,"usage_type":"namespace_import"}`
- `source-141` (`E3`, high confidence): Detected env in config/app.php. Context: `{"file":"config/app.php","line":18,"usage_type":"function_call"}`
- `source-142` (`E3`, high confidence): Detected env in config/app.php. Context: `{"file":"config/app.php","line":31,"usage_type":"function_call"}`
- `source-143` (`E3`, high confidence): Detected env in config/app.php. Context: `{"file":"config/app.php","line":44,"usage_type":"function_call"}`
- `source-144` (`E3`, high confidence): Detected env in config/app.php. Context: `{"file":"config/app.php","line":56,"usage_type":"function_call"}`
- `source-145` (`E3`, high confidence): Detected env in config/app.php. Context: `{"file":"config/app.php","line":69,"usage_type":"function_call"}`
- `source-146` (`E3`, high confidence): Detected env in config/app.php. Context: `{"file":"config/app.php","line":81,"usage_type":"function_call"}`
- `source-147` (`E3`, high confidence): Detected env in config/app.php. Context: `{"file":"config/app.php","line":94,"usage_type":"function_call"}`
- `source-148` (`E3`, high confidence): Detected env in config/app.php. Context: `{"file":"config/app.php","line":107,"usage_type":"function_call"}`
- `source-149` (`E3`, high confidence): Detected env in config/app.php. Context: `{"file":"config/app.php","line":146,"usage_type":"function_call"}`
- `source-150` (`E3`, high confidence): Detected env in config/app.php. Context: `{"file":"config/app.php","line":170,"usage_type":"function_call"}`
- `source-151` (`E3`, high confidence): Detected Illuminate\Support\ServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":185,"usage_type":"static_call"}`
- `source-152` (`E3`, high confidence): Detected Astrotomic\Translatable\TranslatableServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":189,"usage_type":"class_constant_access"}`
- `source-153` (`E3`, high confidence): Detected Barryvdh\DomPDF\ServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":190,"usage_type":"class_constant_access"}`
- `source-154` (`E3`, high confidence): Detected Intervention\Image\ImageServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":191,"usage_type":"class_constant_access"}`
- `source-155` (`E3`, high confidence): Detected Konekt\Concord\ConcordServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":192,"usage_type":"class_constant_access"}`
- `source-156` (`E3`, high confidence): Detected Maatwebsite\Excel\ExcelServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":193,"usage_type":"class_constant_access"}`
- `source-157` (`E3`, high confidence): Detected Prettus\Repository\Providers\RepositoryServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":194,"usage_type":"class_constant_access"}`
- `source-158` (`E3`, high confidence): Detected App\Providers\AppServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":199,"usage_type":"class_constant_access"}`
- `source-159` (`E3`, high confidence): Detected App\Providers\AuthServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":200,"usage_type":"class_constant_access"}`
- `source-160` (`E3`, high confidence): Detected App\Providers\EventServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":202,"usage_type":"class_constant_access"}`
- `source-161` (`E3`, high confidence): Detected App\Providers\RouteServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":203,"usage_type":"class_constant_access"}`
- `source-162` (`E3`, high confidence): Detected Webkul\Admin\Providers\AdminServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":208,"usage_type":"class_constant_access"}`
- `source-163` (`E3`, high confidence): Detected Webkul\Attribute\Providers\AttributeServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":209,"usage_type":"class_constant_access"}`
- `source-164` (`E3`, high confidence): Detected Webkul\CartRule\Providers\CartRuleServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":210,"usage_type":"class_constant_access"}`
- `source-165` (`E3`, high confidence): Detected Webkul\CatalogRule\Providers\CatalogRuleServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":211,"usage_type":"class_constant_access"}`
- `source-166` (`E3`, high confidence): Detected Webkul\Category\Providers\CategoryServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":212,"usage_type":"class_constant_access"}`
- `source-167` (`E3`, high confidence): Detected Webkul\Checkout\Providers\CheckoutServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":213,"usage_type":"class_constant_access"}`
- `source-168` (`E3`, high confidence): Detected Webkul\CMS\Providers\CMSServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":214,"usage_type":"class_constant_access"}`
- `source-169` (`E3`, high confidence): Detected Webkul\Core\Providers\CoreServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":215,"usage_type":"class_constant_access"}`
- `source-170` (`E3`, high confidence): Detected Webkul\Core\Providers\EnvValidatorServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":216,"usage_type":"class_constant_access"}`
- `source-171` (`E3`, high confidence): Detected Webkul\Customer\Providers\CustomerServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":217,"usage_type":"class_constant_access"}`
- `source-172` (`E3`, high confidence): Detected Webkul\DataGrid\Providers\DataGridServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":218,"usage_type":"class_constant_access"}`
- `source-173` (`E3`, high confidence): Detected Webkul\DataTransfer\Providers\DataTransferServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":219,"usage_type":"class_constant_access"}`
- `source-174` (`E3`, high confidence): Detected Webkul\DebugBar\Providers\DebugBarServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":220,"usage_type":"class_constant_access"}`
- `source-175` (`E3`, high confidence): Detected Webkul\FPC\Providers\FPCServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":221,"usage_type":"class_constant_access"}`
- `source-176` (`E3`, high confidence): Detected Webkul\Installer\Providers\InstallerServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":222,"usage_type":"class_constant_access"}`
- `source-177` (`E3`, high confidence): Detected Webkul\Inventory\Providers\InventoryServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":223,"usage_type":"class_constant_access"}`
- `source-178` (`E3`, high confidence): Detected Webkul\MagicAI\Providers\MagicAIServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":224,"usage_type":"class_constant_access"}`
- `source-179` (`E3`, high confidence): Detected Webkul\Marketing\Providers\MarketingServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":225,"usage_type":"class_constant_access"}`
- `source-180` (`E3`, high confidence): Detected Webkul\Notification\Providers\NotificationServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":226,"usage_type":"class_constant_access"}`
- `source-181` (`E3`, high confidence): Detected Webkul\Payment\Providers\PaymentServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":227,"usage_type":"class_constant_access"}`
- `source-182` (`E3`, high confidence): Detected Webkul\Paypal\Providers\PaypalServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":228,"usage_type":"class_constant_access"}`
- `source-183` (`E3`, high confidence): Detected Webkul\Product\Providers\ProductServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":229,"usage_type":"class_constant_access"}`
- `source-184` (`E3`, high confidence): Detected Webkul\Rule\Providers\RuleServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":230,"usage_type":"class_constant_access"}`
- `source-185` (`E3`, high confidence): Detected Webkul\Sales\Providers\SalesServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":231,"usage_type":"class_constant_access"}`
- `source-186` (`E3`, high confidence): Detected Webkul\Shipping\Providers\ShippingServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":232,"usage_type":"class_constant_access"}`
- `source-187` (`E3`, high confidence): Detected Webkul\Shop\Providers\ShopServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":233,"usage_type":"class_constant_access"}`
- `source-188` (`E3`, high confidence): Detected Webkul\Sitemap\Providers\SitemapServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":234,"usage_type":"class_constant_access"}`
- `source-189` (`E3`, high confidence): Detected Webkul\SocialLogin\Providers\SocialLoginServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":235,"usage_type":"class_constant_access"}`
- `source-190` (`E3`, high confidence): Detected Webkul\SocialShare\Providers\SocialShareServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":236,"usage_type":"class_constant_access"}`
- `source-191` (`E3`, high confidence): Detected Webkul\Tax\Providers\TaxServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":237,"usage_type":"class_constant_access"}`
- `source-192` (`E3`, high confidence): Detected Webkul\Theme\Providers\ThemeServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":238,"usage_type":"class_constant_access"}`
- `source-193` (`E3`, high confidence): Detected Webkul\User\Providers\UserServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":239,"usage_type":"class_constant_access"}`
- `source-194` (`E3`, high confidence): Detected Illuminate\Support\Facades\Facade in config/app.php. Context: `{"file":"config/app.php","line":253,"usage_type":"static_call"}`
- `source-195` (`E3`, high confidence): Detected Webkul\Customer\Facades\Captcha in config/app.php. Context: `{"file":"config/app.php","line":254,"usage_type":"class_constant_access"}`
- `source-196` (`E3`, high confidence): Detected Webkul\Checkout\Facades\Cart in config/app.php. Context: `{"file":"config/app.php","line":255,"usage_type":"class_constant_access"}`
- `source-197` (`E3`, high confidence): Detected Konekt\Concord\Facades\Concord in config/app.php. Context: `{"file":"config/app.php","line":256,"usage_type":"class_constant_access"}`
- `source-198` (`E3`, high confidence): Detected Webkul\Core\Facades\Core in config/app.php. Context: `{"file":"config/app.php","line":257,"usage_type":"class_constant_access"}`
- `source-199` (`E3`, high confidence): Detected Maatwebsite\Excel\Facades\Excel in config/app.php. Context: `{"file":"config/app.php","line":258,"usage_type":"class_constant_access"}`
- `source-200` (`E3`, high confidence): Detected Konekt\Concord\Facades\Helper in config/app.php. Context: `{"file":"config/app.php","line":259,"usage_type":"class_constant_access"}`
- `source-201` (`E3`, high confidence): Detected Intervention\Image\Facades\Image in config/app.php. Context: `{"file":"config/app.php","line":260,"usage_type":"class_constant_access"}`
- `source-202` (`E3`, high confidence): Detected Barryvdh\DomPDF\Facade\Pdf in config/app.php. Context: `{"file":"config/app.php","line":261,"usage_type":"class_constant_access"}`
- `source-203` (`E3`, high confidence): Detected Webkul\Product\Facades\ProductImage in config/app.php. Context: `{"file":"config/app.php","line":262,"usage_type":"class_constant_access"}`
- `source-204` (`E3`, high confidence): Detected Webkul\Product\Facades\ProductVideo in config/app.php. Context: `{"file":"config/app.php","line":263,"usage_type":"class_constant_access"}`
- `source-205` (`E3`, high confidence): Detected Illuminate\Support\Facades\Redis in config/app.php. Context: `{"file":"config/app.php","line":264,"usage_type":"class_constant_access"}`
- `source-206` (`E3`, high confidence): Detected Astrotomic\Translatable\TranslatableServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":189,"usage_type":"service_provider"}`
- `source-207` (`E3`, high confidence): Detected Barryvdh\DomPDF\ServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":190,"usage_type":"service_provider"}`
- `source-208` (`E3`, high confidence): Detected Intervention\Image\ImageServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":191,"usage_type":"service_provider"}`
- `source-209` (`E3`, high confidence): Detected Konekt\Concord\ConcordServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":192,"usage_type":"service_provider"}`
- `source-210` (`E3`, high confidence): Detected Maatwebsite\Excel\ExcelServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":193,"usage_type":"service_provider"}`
- `source-211` (`E3`, high confidence): Detected Prettus\Repository\Providers\RepositoryServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":194,"usage_type":"service_provider"}`
- `source-212` (`E3`, high confidence): Detected App\Providers\AppServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":199,"usage_type":"service_provider"}`
- `source-213` (`E3`, high confidence): Detected App\Providers\AuthServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":200,"usage_type":"service_provider"}`
- `source-214` (`E3`, high confidence): Detected App\Providers\EventServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":202,"usage_type":"service_provider"}`
- `source-215` (`E3`, high confidence): Detected App\Providers\RouteServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":203,"usage_type":"service_provider"}`
- `source-216` (`E3`, high confidence): Detected Webkul\Admin\Providers\AdminServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":208,"usage_type":"service_provider"}`
- `source-217` (`E3`, high confidence): Detected Webkul\Attribute\Providers\AttributeServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":209,"usage_type":"service_provider"}`
- `source-218` (`E3`, high confidence): Detected Webkul\CartRule\Providers\CartRuleServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":210,"usage_type":"service_provider"}`
- `source-219` (`E3`, high confidence): Detected Webkul\CatalogRule\Providers\CatalogRuleServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":211,"usage_type":"service_provider"}`
- `source-220` (`E3`, high confidence): Detected Webkul\Category\Providers\CategoryServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":212,"usage_type":"service_provider"}`
- `source-221` (`E3`, high confidence): Detected Webkul\Checkout\Providers\CheckoutServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":213,"usage_type":"service_provider"}`
- `source-222` (`E3`, high confidence): Detected Webkul\CMS\Providers\CMSServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":214,"usage_type":"service_provider"}`
- `source-223` (`E3`, high confidence): Detected Webkul\Core\Providers\CoreServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":215,"usage_type":"service_provider"}`
- `source-224` (`E3`, high confidence): Detected Webkul\Core\Providers\EnvValidatorServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":216,"usage_type":"service_provider"}`
- `source-225` (`E3`, high confidence): Detected Webkul\Customer\Providers\CustomerServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":217,"usage_type":"service_provider"}`
- `source-226` (`E3`, high confidence): Detected Webkul\DataGrid\Providers\DataGridServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":218,"usage_type":"service_provider"}`
- `source-227` (`E3`, high confidence): Detected Webkul\DataTransfer\Providers\DataTransferServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":219,"usage_type":"service_provider"}`
- `source-228` (`E3`, high confidence): Detected Webkul\DebugBar\Providers\DebugBarServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":220,"usage_type":"service_provider"}`
- `source-229` (`E3`, high confidence): Detected Webkul\FPC\Providers\FPCServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":221,"usage_type":"service_provider"}`
- `source-230` (`E3`, high confidence): Detected Webkul\Installer\Providers\InstallerServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":222,"usage_type":"service_provider"}`
- `source-231` (`E3`, high confidence): Detected Webkul\Inventory\Providers\InventoryServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":223,"usage_type":"service_provider"}`
- `source-232` (`E3`, high confidence): Detected Webkul\MagicAI\Providers\MagicAIServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":224,"usage_type":"service_provider"}`
- `source-233` (`E3`, high confidence): Detected Webkul\Marketing\Providers\MarketingServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":225,"usage_type":"service_provider"}`
- `source-234` (`E3`, high confidence): Detected Webkul\Notification\Providers\NotificationServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":226,"usage_type":"service_provider"}`
- `source-235` (`E3`, high confidence): Detected Webkul\Payment\Providers\PaymentServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":227,"usage_type":"service_provider"}`
- `source-236` (`E3`, high confidence): Detected Webkul\Paypal\Providers\PaypalServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":228,"usage_type":"service_provider"}`
- `source-237` (`E3`, high confidence): Detected Webkul\Product\Providers\ProductServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":229,"usage_type":"service_provider"}`
- `source-238` (`E3`, high confidence): Detected Webkul\Rule\Providers\RuleServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":230,"usage_type":"service_provider"}`
- `source-239` (`E3`, high confidence): Detected Webkul\Sales\Providers\SalesServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":231,"usage_type":"service_provider"}`
- `source-240` (`E3`, high confidence): Detected Webkul\Shipping\Providers\ShippingServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":232,"usage_type":"service_provider"}`
- `source-241` (`E3`, high confidence): Detected Webkul\Shop\Providers\ShopServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":233,"usage_type":"service_provider"}`
- `source-242` (`E3`, high confidence): Detected Webkul\Sitemap\Providers\SitemapServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":234,"usage_type":"service_provider"}`
- `source-243` (`E3`, high confidence): Detected Webkul\SocialLogin\Providers\SocialLoginServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":235,"usage_type":"service_provider"}`
- `source-244` (`E3`, high confidence): Detected Webkul\SocialShare\Providers\SocialShareServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":236,"usage_type":"service_provider"}`
- `source-245` (`E3`, high confidence): Detected Webkul\Tax\Providers\TaxServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":237,"usage_type":"service_provider"}`
- `source-246` (`E3`, high confidence): Detected Webkul\Theme\Providers\ThemeServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":238,"usage_type":"service_provider"}`
- `source-247` (`E3`, high confidence): Detected Webkul\User\Providers\UserServiceProvider in config/app.php. Context: `{"file":"config/app.php","line":239,"usage_type":"service_provider"}`
- `source-248` (`E3`, high confidence): Detected Webkul\Customer\Facades\Captcha in config/app.php. Context: `{"file":"config/app.php","line":254,"usage_type":"facade_alias"}`
- `source-249` (`E3`, high confidence): Detected Webkul\Checkout\Facades\Cart in config/app.php. Context: `{"file":"config/app.php","line":255,"usage_type":"facade_alias"}`
- `source-250` (`E3`, high confidence): Detected Konekt\Concord\Facades\Concord in config/app.php. Context: `{"file":"config/app.php","line":256,"usage_type":"facade_alias"}`
- `source-251` (`E3`, high confidence): Detected Webkul\Core\Facades\Core in config/app.php. Context: `{"file":"config/app.php","line":257,"usage_type":"facade_alias"}`
- `source-252` (`E3`, high confidence): Detected Maatwebsite\Excel\Facades\Excel in config/app.php. Context: `{"file":"config/app.php","line":258,"usage_type":"facade_alias"}`
- `source-253` (`E3`, high confidence): Detected Konekt\Concord\Facades\Helper in config/app.php. Context: `{"file":"config/app.php","line":259,"usage_type":"facade_alias"}`
- `source-254` (`E3`, high confidence): Detected Intervention\Image\Facades\Image in config/app.php. Context: `{"file":"config/app.php","line":260,"usage_type":"facade_alias"}`
- `source-255` (`E3`, high confidence): Detected Barryvdh\DomPDF\Facade\Pdf in config/app.php. Context: `{"file":"config/app.php","line":261,"usage_type":"facade_alias"}`
- `source-256` (`E3`, high confidence): Detected Webkul\Product\Facades\ProductImage in config/app.php. Context: `{"file":"config/app.php","line":262,"usage_type":"facade_alias"}`
- `source-257` (`E3`, high confidence): Detected Webkul\Product\Facades\ProductVideo in config/app.php. Context: `{"file":"config/app.php","line":263,"usage_type":"facade_alias"}`
- `source-258` (`E3`, high confidence): Detected Illuminate\Support\Facades\Redis in config/app.php. Context: `{"file":"config/app.php","line":264,"usage_type":"facade_alias"}`
- `source-259` (`E3`, high confidence): Detected Webkul\Customer\Models\Customer in config/auth.php. Context: `{"file":"config/auth.php","line":24,"usage_type":"class_constant_access"}`
- `source-260` (`E3`, high confidence): Detected Webkul\User\Models\Admin in config/auth.php. Context: `{"file":"config/auth.php","line":29,"usage_type":"class_constant_access"}`
- `source-261` (`E3`, high confidence): Detected Webkul\Customer\Models\Customer in config/auth.php. Context: `{"file":"config/auth.php","line":24,"usage_type":"service_provider"}`
- `source-262` (`E3`, high confidence): Detected Webkul\User\Models\Admin in config/auth.php. Context: `{"file":"config/auth.php","line":29,"usage_type":"service_provider"}`
- `source-263` (`E3`, high confidence): Detected base_path in config/breadcrumbs.php. Context: `{"file":"config/breadcrumbs.php","line":40,"usage_type":"function_call"}`
- `source-264` (`E3`, high confidence): Detected Diglactic\Breadcrumbs\Manager in config/breadcrumbs.php. Context: `{"file":"config/breadcrumbs.php","line":70,"usage_type":"class_constant_access"}`
- `source-265` (`E3`, high confidence): Detected Diglactic\Breadcrumbs\Generator in config/breadcrumbs.php. Context: `{"file":"config/breadcrumbs.php","line":73,"usage_type":"class_constant_access"}`
- `source-266` (`E3`, high confidence): Detected env in config/broadcasting.php. Context: `{"file":"config/broadcasting.php","line":18,"usage_type":"function_call"}`
- `source-267` (`E3`, high confidence): Detected env in config/broadcasting.php. Context: `{"file":"config/broadcasting.php","line":34,"usage_type":"function_call"}`
- `source-268` (`E3`, high confidence): Detected env in config/broadcasting.php. Context: `{"file":"config/broadcasting.php","line":35,"usage_type":"function_call"}`
- `source-269` (`E3`, high confidence): Detected env in config/broadcasting.php. Context: `{"file":"config/broadcasting.php","line":36,"usage_type":"function_call"}`
- `source-270` (`E3`, high confidence): Detected env in config/broadcasting.php. Context: `{"file":"config/broadcasting.php","line":38,"usage_type":"function_call"}`
- `source-271` (`E3`, high confidence): Detected env in config/cache.php. Context: `{"file":"config/cache.php","line":18,"usage_type":"function_call"}`
- `source-272` (`E3`, high confidence): Detected storage_path in config/cache.php. Context: `{"file":"config/cache.php","line":49,"usage_type":"function_call"}`
- `source-273` (`E3`, high confidence): Detected env in config/cache.php. Context: `{"file":"config/cache.php","line":54,"usage_type":"function_call"}`
- `source-274` (`E3`, high confidence): Detected env in config/cache.php. Context: `{"file":"config/cache.php","line":56,"usage_type":"function_call"}`
- `source-275` (`E3`, high confidence): Detected env in config/cache.php. Context: `{"file":"config/cache.php","line":57,"usage_type":"function_call"}`
- `source-276` (`E3`, high confidence): Detected env in config/cache.php. Context: `{"file":"config/cache.php","line":64,"usage_type":"function_call"}`
- `source-277` (`E3`, high confidence): Detected env in config/cache.php. Context: `{"file":"config/cache.php","line":65,"usage_type":"function_call"}`
- `source-278` (`E3`, high confidence): Detected env in config/cache.php. Context: `{"file":"config/cache.php","line":73,"usage_type":"function_call"}`
- `source-279` (`E3`, high confidence): Detected env in config/cache.php. Context: `{"file":"config/cache.php","line":89,"usage_type":"function_call"}`
- `source-280` (`E3`, high confidence): Detected Illuminate\Support\Str in config/cache.php. Context: `{"file":"config/cache.php","line":91,"usage_type":"static_call"}`
- `source-281` (`E3`, high confidence): Detected env in config/cache.php. Context: `{"file":"config/cache.php","line":91,"usage_type":"function_call"}`
- `source-282` (`E3`, high confidence): Detected Webkul\Core\CoreConvention in config/concord.php. Context: `{"file":"config/concord.php","line":5,"usage_type":"class_constant_access"}`
- `source-283` (`E3`, high confidence): Detected Webkul\Admin\Providers\ModuleServiceProvider in config/concord.php. Context: `{"file":"config/concord.php","line":14,"usage_type":"class_constant_access"}`
- `source-284` (`E3`, high confidence): Detected Webkul\Attribute\Providers\ModuleServiceProvider in config/concord.php. Context: `{"file":"config/concord.php","line":15,"usage_type":"class_constant_access"}`
- `source-285` (`E3`, high confidence): Detected Webkul\CartRule\Providers\ModuleServiceProvider in config/concord.php. Context: `{"file":"config/concord.php","line":16,"usage_type":"class_constant_access"}`
- `source-286` (`E3`, high confidence): Detected Webkul\CatalogRule\Providers\ModuleServiceProvider in config/concord.php. Context: `{"file":"config/concord.php","line":17,"usage_type":"class_constant_access"}`
- `source-287` (`E3`, high confidence): Detected Webkul\Category\Providers\ModuleServiceProvider in config/concord.php. Context: `{"file":"config/concord.php","line":18,"usage_type":"class_constant_access"}`
- `source-288` (`E3`, high confidence): Detected Webkul\Checkout\Providers\ModuleServiceProvider in config/concord.php. Context: `{"file":"config/concord.php","line":19,"usage_type":"class_constant_access"}`
- `source-289` (`E3`, high confidence): Detected Webkul\Core\Providers\ModuleServiceProvider in config/concord.php. Context: `{"file":"config/concord.php","line":20,"usage_type":"class_constant_access"}`
- `source-290` (`E3`, high confidence): Detected Webkul\CMS\Providers\ModuleServiceProvider in config/concord.php. Context: `{"file":"config/concord.php","line":21,"usage_type":"class_constant_access"}`
- `source-291` (`E3`, high confidence): Detected Webkul\Customer\Providers\ModuleServiceProvider in config/concord.php. Context: `{"file":"config/concord.php","line":22,"usage_type":"class_constant_access"}`
- `source-292` (`E3`, high confidence): Detected Webkul\DataGrid\Providers\ModuleServiceProvider in config/concord.php. Context: `{"file":"config/concord.php","line":23,"usage_type":"class_constant_access"}`
- `source-293` (`E3`, high confidence): Detected Webkul\DataTransfer\Providers\ModuleServiceProvider in config/concord.php. Context: `{"file":"config/concord.php","line":24,"usage_type":"class_constant_access"}`
- `source-294` (`E3`, high confidence): Detected Webkul\Inventory\Providers\ModuleServiceProvider in config/concord.php. Context: `{"file":"config/concord.php","line":25,"usage_type":"class_constant_access"}`
- `source-295` (`E3`, high confidence): Detected Webkul\Marketing\Providers\ModuleServiceProvider in config/concord.php. Context: `{"file":"config/concord.php","line":26,"usage_type":"class_constant_access"}`
- `source-296` (`E3`, high confidence): Detected Webkul\Notification\Providers\ModuleServiceProvider in config/concord.php. Context: `{"file":"config/concord.php","line":27,"usage_type":"class_constant_access"}`
- `source-297` (`E3`, high confidence): Detected Webkul\Payment\Providers\ModuleServiceProvider in config/concord.php. Context: `{"file":"config/concord.php","line":28,"usage_type":"class_constant_access"}`
- `source-298` (`E3`, high confidence): Detected Webkul\Paypal\Providers\ModuleServiceProvider in config/concord.php. Context: `{"file":"config/concord.php","line":29,"usage_type":"class_constant_access"}`
- `source-299` (`E3`, high confidence): Detected Webkul\Product\Providers\ModuleServiceProvider in config/concord.php. Context: `{"file":"config/concord.php","line":30,"usage_type":"class_constant_access"}`
- `source-300` (`E3`, high confidence): Detected Webkul\Rule\Providers\ModuleServiceProvider in config/concord.php. Context: `{"file":"config/concord.php","line":31,"usage_type":"class_constant_access"}`
- `source-301` (`E3`, high confidence): Detected Webkul\Sales\Providers\ModuleServiceProvider in config/concord.php. Context: `{"file":"config/concord.php","line":32,"usage_type":"class_constant_access"}`
- `source-302` (`E3`, high confidence): Detected Webkul\Shipping\Providers\ModuleServiceProvider in config/concord.php. Context: `{"file":"config/concord.php","line":33,"usage_type":"class_constant_access"}`
- `source-303` (`E3`, high confidence): Detected Webkul\Shop\Providers\ModuleServiceProvider in config/concord.php. Context: `{"file":"config/concord.php","line":34,"usage_type":"class_constant_access"}`
- `source-304` (`E3`, high confidence): Detected Webkul\SocialLogin\Providers\ModuleServiceProvider in config/concord.php. Context: `{"file":"config/concord.php","line":35,"usage_type":"class_constant_access"}`
- `source-305` (`E3`, high confidence): Detected Webkul\Tax\Providers\ModuleServiceProvider in config/concord.php. Context: `{"file":"config/concord.php","line":36,"usage_type":"class_constant_access"}`
- `source-306` (`E3`, high confidence): Detected Webkul\Theme\Providers\ModuleServiceProvider in config/concord.php. Context: `{"file":"config/concord.php","line":37,"usage_type":"class_constant_access"}`
- `source-307` (`E3`, high confidence): Detected Webkul\User\Providers\ModuleServiceProvider in config/concord.php. Context: `{"file":"config/concord.php","line":38,"usage_type":"class_constant_access"}`
- `source-308` (`E3`, high confidence): Detected Webkul\Sitemap\Providers\ModuleServiceProvider in config/concord.php. Context: `{"file":"config/concord.php","line":39,"usage_type":"class_constant_access"}`
- `source-309` (`E3`, high confidence): Detected env in config/database.php. Context: `{"file":"config/database.php","line":16,"usage_type":"function_call"}`
- `source-310` (`E3`, high confidence): Detected env in config/database.php. Context: `{"file":"config/database.php","line":38,"usage_type":"function_call"}`
- `source-311` (`E3`, high confidence): Detected database_path in config/database.php. Context: `{"file":"config/database.php","line":38,"usage_type":"function_call"}`
- `source-312` (`E3`, high confidence): Detected env in config/database.php. Context: `{"file":"config/database.php","line":39,"usage_type":"function_call"}`
- `source-313` (`E3`, high confidence): Detected env in config/database.php. Context: `{"file":"config/database.php","line":44,"usage_type":"function_call"}`
- `source-314` (`E3`, high confidence): Detected env in config/database.php. Context: `{"file":"config/database.php","line":45,"usage_type":"function_call"}`
- `source-315` (`E3`, high confidence): Detected env in config/database.php. Context: `{"file":"config/database.php","line":46,"usage_type":"function_call"}`
- `source-316` (`E3`, high confidence): Detected env in config/database.php. Context: `{"file":"config/database.php","line":47,"usage_type":"function_call"}`
- `source-317` (`E3`, high confidence): Detected env in config/database.php. Context: `{"file":"config/database.php","line":48,"usage_type":"function_call"}`
- `source-318` (`E3`, high confidence): Detected env in config/database.php. Context: `{"file":"config/database.php","line":49,"usage_type":"function_call"}`
- `source-319` (`E3`, high confidence): Detected env in config/database.php. Context: `{"file":"config/database.php","line":52,"usage_type":"function_call"}`
- `source-320` (`E3`, high confidence): Detected env in config/database.php. Context: `{"file":"config/database.php","line":59,"usage_type":"function_call"}`
- `source-321` (`E3`, high confidence): Detected env in config/database.php. Context: `{"file":"config/database.php","line":60,"usage_type":"function_call"}`
- `source-322` (`E3`, high confidence): Detected env in config/database.php. Context: `{"file":"config/database.php","line":61,"usage_type":"function_call"}`
- `source-323` (`E3`, high confidence): Detected env in config/database.php. Context: `{"file":"config/database.php","line":62,"usage_type":"function_call"}`
- `source-324` (`E3`, high confidence): Detected env in config/database.php. Context: `{"file":"config/database.php","line":63,"usage_type":"function_call"}`
- `source-325` (`E3`, high confidence): Detected env in config/database.php. Context: `{"file":"config/database.php","line":65,"usage_type":"function_call"}`
- `source-326` (`E3`, high confidence): Detected env in config/database.php. Context: `{"file":"config/database.php","line":72,"usage_type":"function_call"}`
- `source-327` (`E3`, high confidence): Detected env in config/database.php. Context: `{"file":"config/database.php","line":73,"usage_type":"function_call"}`
- `source-328` (`E3`, high confidence): Detected env in config/database.php. Context: `{"file":"config/database.php","line":74,"usage_type":"function_call"}`
- `source-329` (`E3`, high confidence): Detected env in config/database.php. Context: `{"file":"config/database.php","line":75,"usage_type":"function_call"}`
- `source-330` (`E3`, high confidence): Detected env in config/database.php. Context: `{"file":"config/database.php","line":76,"usage_type":"function_call"}`
- `source-331` (`E3`, high confidence): Detected env in config/database.php. Context: `{"file":"config/database.php","line":112,"usage_type":"function_call"}`
- `source-332` (`E3`, high confidence): Detected env in config/database.php. Context: `{"file":"config/database.php","line":113,"usage_type":"function_call"}`
- `source-333` (`E3`, high confidence): Detected env in config/database.php. Context: `{"file":"config/database.php","line":114,"usage_type":"function_call"}`
- `source-334` (`E3`, high confidence): Detected env in config/database.php. Context: `{"file":"config/database.php","line":115,"usage_type":"function_call"}`
- `source-335` (`E3`, high confidence): Detected env in config/database.php. Context: `{"file":"config/database.php","line":119,"usage_type":"function_call"}`
- `source-336` (`E3`, high confidence): Detected env in config/database.php. Context: `{"file":"config/database.php","line":120,"usage_type":"function_call"}`
- `source-337` (`E3`, high confidence): Detected env in config/database.php. Context: `{"file":"config/database.php","line":121,"usage_type":"function_call"}`
- `source-338` (`E3`, high confidence): Detected env in config/database.php. Context: `{"file":"config/database.php","line":122,"usage_type":"function_call"}`
- `source-339` (`E3`, high confidence): Detected env in config/database.php. Context: `{"file":"config/database.php","line":126,"usage_type":"function_call"}`
- `source-340` (`E3`, high confidence): Detected env in config/database.php. Context: `{"file":"config/database.php","line":127,"usage_type":"function_call"}`
- `source-341` (`E3`, high confidence): Detected env in config/database.php. Context: `{"file":"config/database.php","line":128,"usage_type":"function_call"}`
- `source-342` (`E3`, high confidence): Detected env in config/database.php. Context: `{"file":"config/database.php","line":129,"usage_type":"function_call"}`
- `source-343` (`E3`, high confidence): Detected env in config/elasticsearch.php. Context: `{"file":"config/elasticsearch.php","line":16,"usage_type":"function_call"}`
- `source-344` (`E3`, high confidence): Detected env in config/elasticsearch.php. Context: `{"file":"config/elasticsearch.php","line":19,"usage_type":"function_call"}`
- `source-345` (`E3`, high confidence): Detected env in config/elasticsearch.php. Context: `{"file":"config/elasticsearch.php","line":20,"usage_type":"function_call"}`
- `source-346` (`E3`, high confidence): Detected env in config/elasticsearch.php. Context: `{"file":"config/elasticsearch.php","line":29,"usage_type":"function_call"}`
- `source-347` (`E3`, high confidence): Detected env in config/elasticsearch.php. Context: `{"file":"config/elasticsearch.php","line":32,"usage_type":"function_call"}`
- `source-348` (`E3`, high confidence): Detected env in config/elasticsearch.php. Context: `{"file":"config/elasticsearch.php","line":39,"usage_type":"function_call"}`
- `source-349` (`E3`, high confidence): Detected env in config/elasticsearch.php. Context: `{"file":"config/elasticsearch.php","line":44,"usage_type":"function_call"}`
- `source-350` (`E3`, high confidence): Detected env in config/elasticsearch.php. Context: `{"file":"config/elasticsearch.php","line":49,"usage_type":"function_call"}`
- `source-351` (`E3`, high confidence): Detected env in config/elasticsearch.php. Context: `{"file":"config/elasticsearch.php","line":50,"usage_type":"function_call"}`
- `source-352` (`E3`, high confidence): Detected env in config/filesystems.php. Context: `{"file":"config/filesystems.php","line":16,"usage_type":"function_call"}`
- `source-353` (`E3`, high confidence): Detected env in config/filesystems.php. Context: `{"file":"config/filesystems.php","line":29,"usage_type":"function_call"}`
- `source-354` (`E3`, high confidence): Detected storage_path in config/filesystems.php. Context: `{"file":"config/filesystems.php","line":48,"usage_type":"function_call"}`
- `source-355` (`E3`, high confidence): Detected storage_path in config/filesystems.php. Context: `{"file":"config/filesystems.php","line":53,"usage_type":"function_call"}`
- `source-356` (`E3`, high confidence): Detected storage_path in config/filesystems.php. Context: `{"file":"config/filesystems.php","line":58,"usage_type":"function_call"}`
- `source-357` (`E3`, high confidence): Detected env in config/filesystems.php. Context: `{"file":"config/filesystems.php","line":59,"usage_type":"function_call"}`
- `source-358` (`E3`, high confidence): Detected env in config/filesystems.php. Context: `{"file":"config/filesystems.php","line":65,"usage_type":"function_call"}`
- `source-359` (`E3`, high confidence): Detected env in config/filesystems.php. Context: `{"file":"config/filesystems.php","line":66,"usage_type":"function_call"}`
- `source-360` (`E3`, high confidence): Detected env in config/filesystems.php. Context: `{"file":"config/filesystems.php","line":67,"usage_type":"function_call"}`
- `source-361` (`E3`, high confidence): Detected env in config/filesystems.php. Context: `{"file":"config/filesystems.php","line":68,"usage_type":"function_call"}`
- `source-362` (`E3`, high confidence): Detected env in config/filesystems.php. Context: `{"file":"config/filesystems.php","line":69,"usage_type":"function_call"}`
- `source-363` (`E3`, high confidence): Detected env in config/hashing.php. Context: `{"file":"config/hashing.php","line":32,"usage_type":"function_call"}`
- `source-364` (`E3`, high confidence): Detected storage_path in config/imagecache.php. Context: `{"file":"config/imagecache.php","line":33,"usage_type":"function_call"}`
- `source-365` (`E3`, high confidence): Detected public_path in config/imagecache.php. Context: `{"file":"config/imagecache.php","line":34,"usage_type":"function_call"}`
- `source-366` (`E3`, high confidence): Detected Monolog\Handler\StreamHandler in config/logging.php. Context: `{"file":"config/logging.php","line":3,"usage_type":"namespace_import"}`
- `source-367` (`E3`, high confidence): Detected env in config/logging.php. Context: `{"file":"config/logging.php","line":18,"usage_type":"function_call"}`
- `source-368` (`E3`, high confidence): Detected storage_path in config/logging.php. Context: `{"file":"config/logging.php","line":43,"usage_type":"function_call"}`
- `source-369` (`E3`, high confidence): Detected storage_path in config/logging.php. Context: `{"file":"config/logging.php","line":49,"usage_type":"function_call"}`
- `source-370` (`E3`, high confidence): Detected env in config/logging.php. Context: `{"file":"config/logging.php","line":56,"usage_type":"function_call"}`
- `source-371` (`E3`, high confidence): Detected Monolog\Handler\StreamHandler in config/logging.php. Context: `{"file":"config/logging.php","line":64,"usage_type":"class_constant_access"}`
- `source-372` (`E3`, high confidence): Detected env in config/mail.php. Context: `{"file":"config/mail.php","line":15,"usage_type":"function_call"}`
- `source-373` (`E3`, high confidence): Detected env in config/mail.php. Context: `{"file":"config/mail.php","line":37,"usage_type":"function_call"}`
- `source-374` (`E3`, high confidence): Detected env in config/mail.php. Context: `{"file":"config/mail.php","line":38,"usage_type":"function_call"}`
- `source-375` (`E3`, high confidence): Detected env in config/mail.php. Context: `{"file":"config/mail.php","line":39,"usage_type":"function_call"}`
- `source-376` (`E3`, high confidence): Detected env in config/mail.php. Context: `{"file":"config/mail.php","line":40,"usage_type":"function_call"}`
- `source-377` (`E3`, high confidence): Detected env in config/mail.php. Context: `{"file":"config/mail.php","line":41,"usage_type":"function_call"}`
- `source-378` (`E3`, high confidence): Detected env in config/mail.php. Context: `{"file":"config/mail.php","line":60,"usage_type":"function_call"}`
- `source-379` (`E3`, high confidence): Detected env in config/mail.php. Context: `{"file":"config/mail.php","line":65,"usage_type":"function_call"}`
- `source-380` (`E3`, high confidence): Detected env in config/mail.php. Context: `{"file":"config/mail.php","line":92,"usage_type":"function_call"}`
- `source-381` (`E3`, high confidence): Detected env in config/mail.php. Context: `{"file":"config/mail.php","line":93,"usage_type":"function_call"}`
- `source-382` (`E3`, high confidence): Detected env in config/mail.php. Context: `{"file":"config/mail.php","line":105,"usage_type":"function_call"}`
- `source-383` (`E3`, high confidence): Detected env in config/mail.php. Context: `{"file":"config/mail.php","line":106,"usage_type":"function_call"}`
- `source-384` (`E3`, high confidence): Detected env in config/mail.php. Context: `{"file":"config/mail.php","line":120,"usage_type":"function_call"}`
- `source-385` (`E3`, high confidence): Detected env in config/mail.php. Context: `{"file":"config/mail.php","line":121,"usage_type":"function_call"}`
- `source-386` (`E3`, high confidence): Detected resource_path in config/mail.php. Context: `{"file":"config/mail.php","line":138,"usage_type":"function_call"}`
- `source-387` (`E3`, high confidence): Detected env in config/openai.php. Context: `{"file":"config/openai.php","line":15,"usage_type":"function_call"}`
- `source-388` (`E3`, high confidence): Detected env in config/openai.php. Context: `{"file":"config/openai.php","line":16,"usage_type":"function_call"}`
- `source-389` (`E3`, high confidence): Detected env in config/openai.php. Context: `{"file":"config/openai.php","line":27,"usage_type":"function_call"}`
- `source-390` (`E3`, high confidence): Detected env in config/queue.php. Context: `{"file":"config/queue.php","line":16,"usage_type":"function_call"}`
- `source-391` (`E3`, high confidence): Detected env in config/queue.php. Context: `{"file":"config/queue.php","line":53,"usage_type":"function_call"}`
- `source-392` (`E3`, high confidence): Detected env in config/queue.php. Context: `{"file":"config/queue.php","line":54,"usage_type":"function_call"}`
- `source-393` (`E3`, high confidence): Detected env in config/queue.php. Context: `{"file":"config/queue.php","line":55,"usage_type":"function_call"}`
- `source-394` (`E3`, high confidence): Detected env in config/queue.php. Context: `{"file":"config/queue.php","line":56,"usage_type":"function_call"}`
- `source-395` (`E3`, high confidence): Detected env in config/queue.php. Context: `{"file":"config/queue.php","line":57,"usage_type":"function_call"}`
- `source-396` (`E3`, high confidence): Detected env in config/queue.php. Context: `{"file":"config/queue.php","line":82,"usage_type":"function_call"}`
- `source-397` (`E3`, high confidence): Detected env in config/queue.php. Context: `{"file":"config/queue.php","line":83,"usage_type":"function_call"}`
- `source-398` (`E3`, high confidence): Detected League\Fractal\Serializer\DataArraySerializer in config/repository.php. Context: `{"file":"config/repository.php","line":37,"usage_type":"class_constant_access"}`
- `source-399` (`E3`, high confidence): Detected app in config/repository.php. Context: `{"file":"config/repository.php","line":275,"usage_type":"function_call"}`
- `source-400` (`E3`, high confidence): Detected app in config/repository.php. Context: `{"file":"config/repository.php","line":277,"usage_type":"function_call"}`
- `source-401` (`E3`, high confidence): Detected env in config/responsecache.php. Context: `{"file":"config/responsecache.php","line":7,"usage_type":"function_call"}`
- `source-402` (`E3`, high confidence): Detected Spatie\ResponseCache\CacheProfiles\CacheAllSuccessfulGetRequests in config/responsecache.php. Context: `{"file":"config/responsecache.php","line":16,"usage_type":"class_constant_access"}`
- `source-403` (`E3`, high confidence): Detected env in config/responsecache.php. Context: `{"file":"config/responsecache.php","line":23,"usage_type":"function_call"}`
- `source-404` (`E3`, high confidence): Detected env in config/responsecache.php. Context: `{"file":"config/responsecache.php","line":24,"usage_type":"function_call"}`
- `source-405` (`E3`, high confidence): Detected env in config/responsecache.php. Context: `{"file":"config/responsecache.php","line":31,"usage_type":"function_call"}`
- `source-406` (`E3`, high confidence): Detected env in config/responsecache.php. Context: `{"file":"config/responsecache.php","line":38,"usage_type":"function_call"}`
- `source-407` (`E3`, high confidence): Detected env in config/responsecache.php. Context: `{"file":"config/responsecache.php","line":44,"usage_type":"function_call"}`
- `source-408` (`E3`, high confidence): Detected env in config/responsecache.php. Context: `{"file":"config/responsecache.php","line":52,"usage_type":"function_call"}`
- `source-409` (`E3`, high confidence): Detected env in config/responsecache.php. Context: `{"file":"config/responsecache.php","line":58,"usage_type":"function_call"}`
- `source-410` (`E3`, high confidence): Detected env in config/responsecache.php. Context: `{"file":"config/responsecache.php","line":65,"usage_type":"function_call"}`
- `source-411` (`E3`, high confidence): Detected Spatie\ResponseCache\Replacers\CsrfTokenReplacer in config/responsecache.php. Context: `{"file":"config/responsecache.php","line":72,"usage_type":"class_constant_access"}`
- `source-412` (`E3`, high confidence): Detected Webkul\FPC\Hasher\DefaultHasher in config/responsecache.php. Context: `{"file":"config/responsecache.php","line":88,"usage_type":"class_constant_access"}`
- `source-413` (`E3`, high confidence): Detected Spatie\ResponseCache\Serializers\DefaultSerializer in config/responsecache.php. Context: `{"file":"config/responsecache.php","line":93,"usage_type":"class_constant_access"}`
- `source-414` (`E3`, high confidence): Detected Laravel\Sanctum\Sanctum in config/sanctum.php. Context: `{"file":"config/sanctum.php","line":3,"usage_type":"namespace_import"}`
- `source-415` (`E3`, high confidence): Detected explode in config/sanctum.php. Context: `{"file":"config/sanctum.php","line":18,"usage_type":"function_call"}`
- `source-416` (`E3`, high confidence): Detected env in config/sanctum.php. Context: `{"file":"config/sanctum.php","line":18,"usage_type":"function_call"}`
- `source-417` (`E3`, high confidence): Detected sprintf in config/sanctum.php. Context: `{"file":"config/sanctum.php","line":18,"usage_type":"function_call"}`
- `source-418` (`E3`, high confidence): Detected Laravel\Sanctum\Sanctum in config/sanctum.php. Context: `{"file":"config/sanctum.php","line":21,"usage_type":"static_call"}`
- `source-419` (`E3`, high confidence): Detected App\Http\Middleware\VerifyCsrfToken in config/sanctum.php. Context: `{"file":"config/sanctum.php","line":63,"usage_type":"class_constant_access"}`
- `source-420` (`E3`, high confidence): Detected App\Http\Middleware\EncryptCookies in config/sanctum.php. Context: `{"file":"config/sanctum.php","line":64,"usage_type":"class_constant_access"}`
- `source-421` (`E3`, high confidence): Detected env in config/services.php. Context: `{"file":"config/services.php","line":18,"usage_type":"function_call"}`
- `source-422` (`E3`, high confidence): Detected env in config/services.php. Context: `{"file":"config/services.php","line":19,"usage_type":"function_call"}`
- `source-423` (`E3`, high confidence): Detected env in config/services.php. Context: `{"file":"config/services.php","line":23,"usage_type":"function_call"}`
- `source-424` (`E3`, high confidence): Detected env in config/services.php. Context: `{"file":"config/services.php","line":24,"usage_type":"function_call"}`
- `source-425` (`E3`, high confidence): Detected env in config/services.php. Context: `{"file":"config/services.php","line":25,"usage_type":"function_call"}`
- `source-426` (`E3`, high confidence): Detected env in config/services.php. Context: `{"file":"config/services.php","line":29,"usage_type":"function_call"}`
- `source-427` (`E3`, high confidence): Detected env in config/services.php. Context: `{"file":"config/services.php","line":36,"usage_type":"function_call"}`
- `source-428` (`E3`, high confidence): Detected env in config/services.php. Context: `{"file":"config/services.php","line":41,"usage_type":"function_call"}`
- `source-429` (`E3`, high confidence): Detected env in config/services.php. Context: `{"file":"config/services.php","line":43,"usage_type":"function_call"}`
- `source-430` (`E3`, high confidence): Detected App\User in config/services.php. Context: `{"file":"config/services.php","line":48,"usage_type":"class_constant_access"}`
- `source-431` (`E3`, high confidence): Detected env in config/services.php. Context: `{"file":"config/services.php","line":49,"usage_type":"function_call"}`
- `source-432` (`E3`, high confidence): Detected env in config/services.php. Context: `{"file":"config/services.php","line":50,"usage_type":"function_call"}`
- `source-433` (`E3`, high confidence): Detected env in config/services.php. Context: `{"file":"config/services.php","line":54,"usage_type":"function_call"}`
- `source-434` (`E3`, high confidence): Detected env in config/services.php. Context: `{"file":"config/services.php","line":55,"usage_type":"function_call"}`
- `source-435` (`E3`, high confidence): Detected env in config/services.php. Context: `{"file":"config/services.php","line":56,"usage_type":"function_call"}`
- `source-436` (`E3`, high confidence): Detected env in config/services.php. Context: `{"file":"config/services.php","line":60,"usage_type":"function_call"}`
- `source-437` (`E3`, high confidence): Detected env in config/services.php. Context: `{"file":"config/services.php","line":61,"usage_type":"function_call"}`
- `source-438` (`E3`, high confidence): Detected env in config/services.php. Context: `{"file":"config/services.php","line":62,"usage_type":"function_call"}`
- `source-439` (`E3`, high confidence): Detected env in config/services.php. Context: `{"file":"config/services.php","line":66,"usage_type":"function_call"}`
- `source-440` (`E3`, high confidence): Detected env in config/services.php. Context: `{"file":"config/services.php","line":67,"usage_type":"function_call"}`
- `source-441` (`E3`, high confidence): Detected env in config/services.php. Context: `{"file":"config/services.php","line":68,"usage_type":"function_call"}`
- `source-442` (`E3`, high confidence): Detected env in config/services.php. Context: `{"file":"config/services.php","line":72,"usage_type":"function_call"}`
- `source-443` (`E3`, high confidence): Detected env in config/services.php. Context: `{"file":"config/services.php","line":73,"usage_type":"function_call"}`
- `source-444` (`E3`, high confidence): Detected env in config/services.php. Context: `{"file":"config/services.php","line":74,"usage_type":"function_call"}`
- `source-445` (`E3`, high confidence): Detected env in config/services.php. Context: `{"file":"config/services.php","line":78,"usage_type":"function_call"}`
- `source-446` (`E3`, high confidence): Detected env in config/services.php. Context: `{"file":"config/services.php","line":79,"usage_type":"function_call"}`
- `source-447` (`E3`, high confidence): Detected env in config/services.php. Context: `{"file":"config/services.php","line":80,"usage_type":"function_call"}`
- `source-448` (`E3`, high confidence): Detected env in config/session.php. Context: `{"file":"config/session.php","line":19,"usage_type":"function_call"}`
- `source-449` (`E3`, high confidence): Detected env in config/session.php. Context: `{"file":"config/session.php","line":32,"usage_type":"function_call"}`
- `source-450` (`E3`, high confidence): Detected storage_path in config/session.php. Context: `{"file":"config/session.php","line":60,"usage_type":"function_call"}`
- `source-451` (`E3`, high confidence): Detected env in config/session.php. Context: `{"file":"config/session.php","line":73,"usage_type":"function_call"}`
- `source-452` (`E3`, high confidence): Detected env in config/session.php. Context: `{"file":"config/session.php","line":99,"usage_type":"function_call"}`
- `source-453` (`E3`, high confidence): Detected env in config/session.php. Context: `{"file":"config/session.php","line":125,"usage_type":"function_call"}`
- `source-454` (`E3`, high confidence): Detected Illuminate\Support\Str in config/session.php. Context: `{"file":"config/session.php","line":127,"usage_type":"static_call"}`
- `source-455` (`E3`, high confidence): Detected env in config/session.php. Context: `{"file":"config/session.php","line":127,"usage_type":"function_call"}`
- `source-456` (`E3`, high confidence): Detected env in config/session.php. Context: `{"file":"config/session.php","line":154,"usage_type":"function_call"}`
- `source-457` (`E3`, high confidence): Detected env in config/session.php. Context: `{"file":"config/session.php","line":167,"usage_type":"function_call"}`
- `source-458` (`E3`, high confidence): Detected GuzzleHttp\RequestOptions in config/sitemap.php. Context: `{"file":"config/sitemap.php","line":3,"usage_type":"namespace_import"}`
- `source-459` (`E3`, high confidence): Detected Spatie\Sitemap\Crawler\Profile in config/sitemap.php. Context: `{"file":"config/sitemap.php","line":4,"usage_type":"namespace_import"}`
- `source-460` (`E3`, high confidence): Detected GuzzleHttp\RequestOptions in config/sitemap.php. Context: `{"file":"config/sitemap.php","line":19,"usage_type":"class_constant_access"}`
- `source-461` (`E3`, high confidence): Detected GuzzleHttp\RequestOptions in config/sitemap.php. Context: `{"file":"config/sitemap.php","line":25,"usage_type":"class_constant_access"}`
- `source-462` (`E3`, high confidence): Detected GuzzleHttp\RequestOptions in config/sitemap.php. Context: `{"file":"config/sitemap.php","line":30,"usage_type":"class_constant_access"}`
- `source-463` (`E3`, high confidence): Detected GuzzleHttp\RequestOptions in config/sitemap.php. Context: `{"file":"config/sitemap.php","line":35,"usage_type":"class_constant_access"}`
- `source-464` (`E3`, high confidence): Detected Spatie\Sitemap\Crawler\Profile in config/sitemap.php. Context: `{"file":"config/sitemap.php","line":55,"usage_type":"class_constant_access"}`
- `source-465` (`E3`, high confidence): Detected Astrotomic\Translatable\Validation\RuleFactory in config/translatable.php. Context: `{"file":"config/translatable.php","line":145,"usage_type":"class_constant_access"}`
- `source-466` (`E3`, high confidence): Detected resource_path in config/view.php. Context: `{"file":"config/view.php","line":27,"usage_type":"function_call"}`
- `source-467` (`E3`, high confidence): Detected realpath in config/view.php. Context: `{"file":"config/view.php","line":41,"usage_type":"function_call"}`
- `source-468` (`E3`, high confidence): Detected storage_path in config/view.php. Context: `{"file":"config/view.php","line":41,"usage_type":"function_call"}`
- `source-469` (`E3`, high confidence): Detected Shetabit\Visitor\Drivers\JenssegersAgent in config/visitor.php. Context: `{"file":"config/visitor.php","line":34,"usage_type":"class_constant_access"}`
- `source-470` (`E3`, high confidence): Detected Shetabit\Visitor\Drivers\UAParser in config/visitor.php. Context: `{"file":"config/visitor.php","line":35,"usage_type":"class_constant_access"}`
- `source-471` (`E3`, high confidence): Detected App\Models\User in database/factories/UserFactory.php. Context: `{"file":"database/factories/UserFactory.php","line":5,"usage_type":"namespace_import"}`
- `source-472` (`E3`, high confidence): Detected Illuminate\Database\Eloquent\Factories\Factory in database/factories/UserFactory.php. Context: `{"file":"database/factories/UserFactory.php","line":6,"usage_type":"namespace_import"}`
- `source-473` (`E3`, high confidence): Detected Illuminate\Support\Str in database/factories/UserFactory.php. Context: `{"file":"database/factories/UserFactory.php","line":7,"usage_type":"namespace_import"}`
- `source-474` (`E3`, high confidence): Detected Illuminate\Database\Eloquent\Factories\Factory in database/factories/UserFactory.php. Context: `{"file":"database/factories/UserFactory.php","line":9,"usage_type":"inheritance"}`
- `source-475` (`E3`, high confidence): Detected App\Models\User in database/factories/UserFactory.php. Context: `{"file":"database/factories/UserFactory.php","line":16,"usage_type":"class_constant_access"}`
- `source-476` (`E3`, high confidence): Detected preg_replace in database/factories/UserFactory.php. Context: `{"file":"database/factories/UserFactory.php","line":26,"usage_type":"function_call"}`
- `source-477` (`E3`, high confidence): Detected now in database/factories/UserFactory.php. Context: `{"file":"database/factories/UserFactory.php","line":28,"usage_type":"function_call"}`
- `source-478` (`E3`, high confidence): Detected Illuminate\Support\Str in database/factories/UserFactory.php. Context: `{"file":"database/factories/UserFactory.php","line":30,"usage_type":"static_call"}`
- `source-479` (`E3`, high confidence): Detected Illuminate\Database\Migrations\Migration in database/migrations/2014_10_12_000000_create_users_table.php. Context: `{"file":"database/migrations/2014_10_12_000000_create_users_table.php","line":3,"usage_type":"namespace_import"}`
- `source-480` (`E3`, high confidence): Detected Illuminate\Database\Schema\Blueprint in database/migrations/2014_10_12_000000_create_users_table.php. Context: `{"file":"database/migrations/2014_10_12_000000_create_users_table.php","line":4,"usage_type":"namespace_import"}`
- `source-481` (`E3`, high confidence): Detected Illuminate\Support\Facades\Schema in database/migrations/2014_10_12_000000_create_users_table.php. Context: `{"file":"database/migrations/2014_10_12_000000_create_users_table.php","line":5,"usage_type":"namespace_import"}`
- `source-482` (`E3`, high confidence): Detected Illuminate\Database\Migrations\Migration in database/migrations/2014_10_12_000000_create_users_table.php. Context: `{"file":"database/migrations/2014_10_12_000000_create_users_table.php","line":7,"usage_type":"inheritance"}`
- `source-483` (`E3`, high confidence): Detected Illuminate\Support\Facades\Schema in database/migrations/2014_10_12_000000_create_users_table.php. Context: `{"file":"database/migrations/2014_10_12_000000_create_users_table.php","line":16,"usage_type":"static_call"}`
- `source-484` (`E3`, high confidence): Detected Illuminate\Support\Facades\Schema in database/migrations/2014_10_12_000000_create_users_table.php. Context: `{"file":"database/migrations/2014_10_12_000000_create_users_table.php","line":33,"usage_type":"static_call"}`
- `source-485` (`E3`, high confidence): Detected Illuminate\Database\Migrations\Migration in database/migrations/2014_10_12_100000_create_password_resets_table.php. Context: `{"file":"database/migrations/2014_10_12_100000_create_password_resets_table.php","line":3,"usage_type":"namespace_import"}`
- `source-486` (`E3`, high confidence): Detected Illuminate\Database\Schema\Blueprint in database/migrations/2014_10_12_100000_create_password_resets_table.php. Context: `{"file":"database/migrations/2014_10_12_100000_create_password_resets_table.php","line":4,"usage_type":"namespace_import"}`
- `source-487` (`E3`, high confidence): Detected Illuminate\Support\Facades\Schema in database/migrations/2014_10_12_100000_create_password_resets_table.php. Context: `{"file":"database/migrations/2014_10_12_100000_create_password_resets_table.php","line":5,"usage_type":"namespace_import"}`
- `source-488` (`E3`, high confidence): Detected Illuminate\Database\Migrations\Migration in database/migrations/2014_10_12_100000_create_password_resets_table.php. Context: `{"file":"database/migrations/2014_10_12_100000_create_password_resets_table.php","line":7,"usage_type":"inheritance"}`
- `source-489` (`E3`, high confidence): Detected Illuminate\Support\Facades\Schema in database/migrations/2014_10_12_100000_create_password_resets_table.php. Context: `{"file":"database/migrations/2014_10_12_100000_create_password_resets_table.php","line":16,"usage_type":"static_call"}`
- `source-490` (`E3`, high confidence): Detected Illuminate\Support\Facades\Schema in database/migrations/2014_10_12_100000_create_password_resets_table.php. Context: `{"file":"database/migrations/2014_10_12_100000_create_password_resets_table.php","line":30,"usage_type":"static_call"}`
- `source-491` (`E3`, high confidence): Detected Illuminate\Database\Migrations\Migration in database/migrations/2019_12_14_000001_create_personal_access_tokens_table.php. Context: `{"file":"database/migrations/2019_12_14_000001_create_personal_access_tokens_table.php","line":3,"usage_type":"namespace_import"}`
- `source-492` (`E3`, high confidence): Detected Illuminate\Database\Schema\Blueprint in database/migrations/2019_12_14_000001_create_personal_access_tokens_table.php. Context: `{"file":"database/migrations/2019_12_14_000001_create_personal_access_tokens_table.php","line":4,"usage_type":"namespace_import"}`
- `source-493` (`E3`, high confidence): Detected Illuminate\Support\Facades\Schema in database/migrations/2019_12_14_000001_create_personal_access_tokens_table.php. Context: `{"file":"database/migrations/2019_12_14_000001_create_personal_access_tokens_table.php","line":5,"usage_type":"namespace_import"}`
- `source-494` (`E3`, high confidence): Detected Illuminate\Database\Migrations\Migration in database/migrations/2019_12_14_000001_create_personal_access_tokens_table.php. Context: `{"file":"database/migrations/2019_12_14_000001_create_personal_access_tokens_table.php","line":7,"usage_type":"inheritance"}`
- `source-495` (`E3`, high confidence): Detected Illuminate\Support\Facades\Schema in database/migrations/2019_12_14_000001_create_personal_access_tokens_table.php. Context: `{"file":"database/migrations/2019_12_14_000001_create_personal_access_tokens_table.php","line":14,"usage_type":"static_call"}`
- `source-496` (`E3`, high confidence): Detected Illuminate\Support\Facades\Schema in database/migrations/2019_12_14_000001_create_personal_access_tokens_table.php. Context: `{"file":"database/migrations/2019_12_14_000001_create_personal_access_tokens_table.php","line":31,"usage_type":"static_call"}`
- `source-497` (`E3`, high confidence): Detected Illuminate\Database\Migrations\Migration in database/migrations/2020_12_27_121950_create_jobs_table.php. Context: `{"file":"database/migrations/2020_12_27_121950_create_jobs_table.php","line":3,"usage_type":"namespace_import"}`
- `source-498` (`E3`, high confidence): Detected Illuminate\Database\Schema\Blueprint in database/migrations/2020_12_27_121950_create_jobs_table.php. Context: `{"file":"database/migrations/2020_12_27_121950_create_jobs_table.php","line":4,"usage_type":"namespace_import"}`
- `source-499` (`E3`, high confidence): Detected Illuminate\Support\Facades\Schema in database/migrations/2020_12_27_121950_create_jobs_table.php. Context: `{"file":"database/migrations/2020_12_27_121950_create_jobs_table.php","line":5,"usage_type":"namespace_import"}`
- `source-500` (`E3`, high confidence): Detected Illuminate\Database\Migrations\Migration in database/migrations/2020_12_27_121950_create_jobs_table.php. Context: `{"file":"database/migrations/2020_12_27_121950_create_jobs_table.php","line":7,"usage_type":"inheritance"}`
- `source-501` (`E3`, high confidence): Detected Illuminate\Support\Facades\Schema in database/migrations/2020_12_27_121950_create_jobs_table.php. Context: `{"file":"database/migrations/2020_12_27_121950_create_jobs_table.php","line":16,"usage_type":"static_call"}`
- `source-502` (`E3`, high confidence): Detected Illuminate\Support\Facades\Schema in database/migrations/2020_12_27_121950_create_jobs_table.php. Context: `{"file":"database/migrations/2020_12_27_121950_create_jobs_table.php","line":34,"usage_type":"static_call"}`
- `source-503` (`E3`, high confidence): Detected Illuminate\Database\Migrations\Migration in database/migrations/2022_03_15_160510_create_failed_jobs_table.php. Context: `{"file":"database/migrations/2022_03_15_160510_create_failed_jobs_table.php","line":3,"usage_type":"namespace_import"}`
- `source-504` (`E3`, high confidence): Detected Illuminate\Database\Schema\Blueprint in database/migrations/2022_03_15_160510_create_failed_jobs_table.php. Context: `{"file":"database/migrations/2022_03_15_160510_create_failed_jobs_table.php","line":4,"usage_type":"namespace_import"}`
- `source-505` (`E3`, high confidence): Detected Illuminate\Support\Facades\Schema in database/migrations/2022_03_15_160510_create_failed_jobs_table.php. Context: `{"file":"database/migrations/2022_03_15_160510_create_failed_jobs_table.php","line":5,"usage_type":"namespace_import"}`
- `source-506` (`E3`, high confidence): Detected Illuminate\Database\Migrations\Migration in database/migrations/2022_03_15_160510_create_failed_jobs_table.php. Context: `{"file":"database/migrations/2022_03_15_160510_create_failed_jobs_table.php","line":7,"usage_type":"inheritance"}`
- `source-507` (`E3`, high confidence): Detected Illuminate\Support\Facades\Schema in database/migrations/2022_03_15_160510_create_failed_jobs_table.php. Context: `{"file":"database/migrations/2022_03_15_160510_create_failed_jobs_table.php","line":16,"usage_type":"static_call"}`
- `source-508` (`E3`, high confidence): Detected Illuminate\Support\Facades\Schema in database/migrations/2022_03_15_160510_create_failed_jobs_table.php. Context: `{"file":"database/migrations/2022_03_15_160510_create_failed_jobs_table.php","line":34,"usage_type":"static_call"}`
- `source-509` (`E3`, high confidence): Detected Illuminate\Database\Migrations\Migration in database/migrations/2022_10_04_144444_create_job_batches_table.php. Context: `{"file":"database/migrations/2022_10_04_144444_create_job_batches_table.php","line":3,"usage_type":"namespace_import"}`
- `source-510` (`E3`, high confidence): Detected Illuminate\Database\Schema\Blueprint in database/migrations/2022_10_04_144444_create_job_batches_table.php. Context: `{"file":"database/migrations/2022_10_04_144444_create_job_batches_table.php","line":4,"usage_type":"namespace_import"}`
- `source-511` (`E3`, high confidence): Detected Illuminate\Support\Facades\Schema in database/migrations/2022_10_04_144444_create_job_batches_table.php. Context: `{"file":"database/migrations/2022_10_04_144444_create_job_batches_table.php","line":5,"usage_type":"namespace_import"}`
- `source-512` (`E3`, high confidence): Detected Illuminate\Database\Migrations\Migration in database/migrations/2022_10_04_144444_create_job_batches_table.php. Context: `{"file":"database/migrations/2022_10_04_144444_create_job_batches_table.php","line":7,"usage_type":"inheritance"}`
- `source-513` (`E3`, high confidence): Detected Illuminate\Support\Facades\Schema in database/migrations/2022_10_04_144444_create_job_batches_table.php. Context: `{"file":"database/migrations/2022_10_04_144444_create_job_batches_table.php","line":16,"usage_type":"static_call"}`
- `source-514` (`E3`, high confidence): Detected Illuminate\Support\Facades\Schema in database/migrations/2022_10_04_144444_create_job_batches_table.php. Context: `{"file":"database/migrations/2022_10_04_144444_create_job_batches_table.php","line":37,"usage_type":"static_call"}`
- `source-515` (`E3`, high confidence): Detected Illuminate\Database\Migrations\Migration in database/migrations/2023_10_05_163612_create_visits_table.php. Context: `{"file":"database/migrations/2023_10_05_163612_create_visits_table.php","line":3,"usage_type":"namespace_import"}`
- `source-516` (`E3`, high confidence): Detected Illuminate\Database\Schema\Blueprint in database/migrations/2023_10_05_163612_create_visits_table.php. Context: `{"file":"database/migrations/2023_10_05_163612_create_visits_table.php","line":4,"usage_type":"namespace_import"}`
- `source-517` (`E3`, high confidence): Detected Illuminate\Support\Facades\Schema in database/migrations/2023_10_05_163612_create_visits_table.php. Context: `{"file":"database/migrations/2023_10_05_163612_create_visits_table.php","line":5,"usage_type":"namespace_import"}`
- `source-518` (`E3`, high confidence): Detected Illuminate\Database\Migrations\Migration in database/migrations/2023_10_05_163612_create_visits_table.php. Context: `{"file":"database/migrations/2023_10_05_163612_create_visits_table.php","line":7,"usage_type":"inheritance"}`
- `source-519` (`E3`, high confidence): Detected Illuminate\Support\Facades\Schema in database/migrations/2023_10_05_163612_create_visits_table.php. Context: `{"file":"database/migrations/2023_10_05_163612_create_visits_table.php","line":16,"usage_type":"static_call"}`
- `source-520` (`E3`, high confidence): Detected config in database/migrations/2023_10_05_163612_create_visits_table.php. Context: `{"file":"database/migrations/2023_10_05_163612_create_visits_table.php","line":16,"usage_type":"function_call"}`
- `source-521` (`E3`, high confidence): Detected Illuminate\Support\Facades\Schema in database/migrations/2023_10_05_163612_create_visits_table.php. Context: `{"file":"database/migrations/2023_10_05_163612_create_visits_table.php","line":42,"usage_type":"static_call"}`
- `source-522` (`E3`, high confidence): Detected config in database/migrations/2023_10_05_163612_create_visits_table.php. Context: `{"file":"database/migrations/2023_10_05_163612_create_visits_table.php","line":42,"usage_type":"function_call"}`
- `source-523` (`E3`, high confidence): Detected visitor.table_name in database/migrations/2023_10_05_163612_create_visits_table.php. Context: `{"file":"database/migrations/2023_10_05_163612_create_visits_table.php","line":16,"usage_type":"config_reference"}`
- `source-524` (`E3`, high confidence): Detected visitor.table_name in database/migrations/2023_10_05_163612_create_visits_table.php. Context: `{"file":"database/migrations/2023_10_05_163612_create_visits_table.php","line":42,"usage_type":"config_reference"}`
- `source-525` (`E3`, high confidence): Detected Illuminate\Database\Seeder in database/seeders/DatabaseSeeder.php. Context: `{"file":"database/seeders/DatabaseSeeder.php","line":5,"usage_type":"namespace_import"}`
- `source-526` (`E3`, high confidence): Detected Webkul\Installer\Database\Seeders\DatabaseSeeder in database/seeders/DatabaseSeeder.php. Context: `{"file":"database/seeders/DatabaseSeeder.php","line":6,"usage_type":"namespace_import"}`
- `source-527` (`E3`, high confidence): Detected Illuminate\Database\Seeder in database/seeders/DatabaseSeeder.php. Context: `{"file":"database/seeders/DatabaseSeeder.php","line":8,"usage_type":"inheritance"}`
- `source-528` (`E3`, high confidence): Detected Webkul\Installer\Database\Seeders\DatabaseSeeder in database/seeders/DatabaseSeeder.php. Context: `{"file":"database/seeders/DatabaseSeeder.php","line":17,"usage_type":"class_constant_access"}`
- `source-529` (`E3`, high confidence): Detected Diglactic\Breadcrumbs\Breadcrumbs in routes/breadcrumbs.php. Context: `{"file":"routes/breadcrumbs.php","line":3,"usage_type":"namespace_import"}`
- `source-530` (`E3`, high confidence): Detected Diglactic\Breadcrumbs\Generator in routes/breadcrumbs.php. Context: `{"file":"routes/breadcrumbs.php","line":4,"usage_type":"namespace_import"}`
- `source-531` (`E3`, high confidence): Detected Diglactic\Breadcrumbs\Breadcrumbs in routes/breadcrumbs.php. Context: `{"file":"routes/breadcrumbs.php","line":7,"usage_type":"static_call"}`
- `source-532` (`E3`, high confidence): Detected trans in routes/breadcrumbs.php. Context: `{"file":"routes/breadcrumbs.php","line":8,"usage_type":"function_call"}`
- `source-533` (`E3`, high confidence): Detected route in routes/breadcrumbs.php. Context: `{"file":"routes/breadcrumbs.php","line":8,"usage_type":"function_call"}`
- `source-534` (`E3`, high confidence): Detected Diglactic\Breadcrumbs\Breadcrumbs in routes/breadcrumbs.php. Context: `{"file":"routes/breadcrumbs.php","line":12,"usage_type":"static_call"}`
- `source-535` (`E3`, high confidence): Detected trans in routes/breadcrumbs.php. Context: `{"file":"routes/breadcrumbs.php","line":14,"usage_type":"function_call"}`
- `source-536` (`E3`, high confidence): Detected route in routes/breadcrumbs.php. Context: `{"file":"routes/breadcrumbs.php","line":14,"usage_type":"function_call"}`
- `source-537` (`E3`, high confidence): Detected Diglactic\Breadcrumbs\Breadcrumbs in routes/breadcrumbs.php. Context: `{"file":"routes/breadcrumbs.php","line":18,"usage_type":"static_call"}`
- `source-538` (`E3`, high confidence): Detected trans in routes/breadcrumbs.php. Context: `{"file":"routes/breadcrumbs.php","line":20,"usage_type":"function_call"}`
- `source-539` (`E3`, high confidence): Detected route in routes/breadcrumbs.php. Context: `{"file":"routes/breadcrumbs.php","line":20,"usage_type":"function_call"}`
- `source-540` (`E3`, high confidence): Detected Diglactic\Breadcrumbs\Breadcrumbs in routes/breadcrumbs.php. Context: `{"file":"routes/breadcrumbs.php","line":24,"usage_type":"static_call"}`
- `source-541` (`E3`, high confidence): Detected trans in routes/breadcrumbs.php. Context: `{"file":"routes/breadcrumbs.php","line":26,"usage_type":"function_call"}`
- `source-542` (`E3`, high confidence): Detected route in routes/breadcrumbs.php. Context: `{"file":"routes/breadcrumbs.php","line":26,"usage_type":"function_call"}`
- `source-543` (`E3`, high confidence): Detected Diglactic\Breadcrumbs\Breadcrumbs in routes/breadcrumbs.php. Context: `{"file":"routes/breadcrumbs.php","line":30,"usage_type":"static_call"}`
- `source-544` (`E3`, high confidence): Detected trans in routes/breadcrumbs.php. Context: `{"file":"routes/breadcrumbs.php","line":32,"usage_type":"function_call"}`
- `source-545` (`E3`, high confidence): Detected route in routes/breadcrumbs.php. Context: `{"file":"routes/breadcrumbs.php","line":32,"usage_type":"function_call"}`
- `source-546` (`E3`, high confidence): Detected Diglactic\Breadcrumbs\Breadcrumbs in routes/breadcrumbs.php. Context: `{"file":"routes/breadcrumbs.php","line":36,"usage_type":"static_call"}`
- `source-547` (`E3`, high confidence): Detected trans in routes/breadcrumbs.php. Context: `{"file":"routes/breadcrumbs.php","line":38,"usage_type":"function_call"}`
- `source-548` (`E3`, high confidence): Detected route in routes/breadcrumbs.php. Context: `{"file":"routes/breadcrumbs.php","line":38,"usage_type":"function_call"}`
- `source-549` (`E3`, high confidence): Detected Diglactic\Breadcrumbs\Breadcrumbs in routes/breadcrumbs.php. Context: `{"file":"routes/breadcrumbs.php","line":42,"usage_type":"static_call"}`
- `source-550` (`E3`, high confidence): Detected trans in routes/breadcrumbs.php. Context: `{"file":"routes/breadcrumbs.php","line":44,"usage_type":"function_call"}`
- `source-551` (`E3`, high confidence): Detected route in routes/breadcrumbs.php. Context: `{"file":"routes/breadcrumbs.php","line":44,"usage_type":"function_call"}`
- `source-552` (`E3`, high confidence): Detected Diglactic\Breadcrumbs\Breadcrumbs in routes/breadcrumbs.php. Context: `{"file":"routes/breadcrumbs.php","line":48,"usage_type":"static_call"}`
- `source-553` (`E3`, high confidence): Detected trans in routes/breadcrumbs.php. Context: `{"file":"routes/breadcrumbs.php","line":50,"usage_type":"function_call"}`
- `source-554` (`E3`, high confidence): Detected route in routes/breadcrumbs.php. Context: `{"file":"routes/breadcrumbs.php","line":50,"usage_type":"function_call"}`
- `source-555` (`E3`, high confidence): Detected Diglactic\Breadcrumbs\Breadcrumbs in routes/breadcrumbs.php. Context: `{"file":"routes/breadcrumbs.php","line":53,"usage_type":"static_call"}`
- `source-556` (`E3`, high confidence): Detected trans in routes/breadcrumbs.php. Context: `{"file":"routes/breadcrumbs.php","line":55,"usage_type":"function_call"}`
- `source-557` (`E3`, high confidence): Detected route in routes/breadcrumbs.php. Context: `{"file":"routes/breadcrumbs.php","line":55,"usage_type":"function_call"}`
- `source-558` (`E3`, high confidence): Detected Diglactic\Breadcrumbs\Breadcrumbs in routes/breadcrumbs.php. Context: `{"file":"routes/breadcrumbs.php","line":59,"usage_type":"static_call"}`
- `source-559` (`E3`, high confidence): Detected trans in routes/breadcrumbs.php. Context: `{"file":"routes/breadcrumbs.php","line":61,"usage_type":"function_call"}`
- `source-560` (`E3`, high confidence): Detected route in routes/breadcrumbs.php. Context: `{"file":"routes/breadcrumbs.php","line":61,"usage_type":"function_call"}`
- `source-561` (`E3`, high confidence): Detected Diglactic\Breadcrumbs\Breadcrumbs in routes/breadcrumbs.php. Context: `{"file":"routes/breadcrumbs.php","line":65,"usage_type":"static_call"}`
- `source-562` (`E3`, high confidence): Detected trans in routes/breadcrumbs.php. Context: `{"file":"routes/breadcrumbs.php","line":67,"usage_type":"function_call"}`
- `source-563` (`E3`, high confidence): Detected route in routes/breadcrumbs.php. Context: `{"file":"routes/breadcrumbs.php","line":67,"usage_type":"function_call"}`
- `source-564` (`E3`, high confidence): Detected Diglactic\Breadcrumbs\Breadcrumbs in routes/breadcrumbs.php. Context: `{"file":"routes/breadcrumbs.php","line":71,"usage_type":"static_call"}`
- `source-565` (`E3`, high confidence): Detected trans in routes/breadcrumbs.php. Context: `{"file":"routes/breadcrumbs.php","line":73,"usage_type":"function_call"}`
- `source-566` (`E3`, high confidence): Detected route in routes/breadcrumbs.php. Context: `{"file":"routes/breadcrumbs.php","line":73,"usage_type":"function_call"}`
- `source-567` (`E3`, high confidence): Detected Diglactic\Breadcrumbs\Breadcrumbs in routes/breadcrumbs.php. Context: `{"file":"routes/breadcrumbs.php","line":77,"usage_type":"static_call"}`
- `source-568` (`E3`, high confidence): Detected trans in routes/breadcrumbs.php. Context: `{"file":"routes/breadcrumbs.php","line":79,"usage_type":"function_call"}`
- `source-569` (`E3`, high confidence): Detected route in routes/breadcrumbs.php. Context: `{"file":"routes/breadcrumbs.php","line":79,"usage_type":"function_call"}`
- `source-570` (`E3`, high confidence): Detected Diglactic\Breadcrumbs\Breadcrumbs in routes/breadcrumbs.php. Context: `{"file":"routes/breadcrumbs.php","line":83,"usage_type":"static_call"}`
- `source-571` (`E3`, high confidence): Detected trans in routes/breadcrumbs.php. Context: `{"file":"routes/breadcrumbs.php","line":85,"usage_type":"function_call"}`
- `source-572` (`E3`, high confidence): Detected route in routes/breadcrumbs.php. Context: `{"file":"routes/breadcrumbs.php","line":85,"usage_type":"function_call"}`
- `source-573` (`E3`, high confidence): Detected Diglactic\Breadcrumbs\Breadcrumbs in routes/breadcrumbs.php. Context: `{"file":"routes/breadcrumbs.php","line":89,"usage_type":"static_call"}`
- `source-574` (`E3`, high confidence): Detected trans in routes/breadcrumbs.php. Context: `{"file":"routes/breadcrumbs.php","line":91,"usage_type":"function_call"}`
- `source-575` (`E3`, high confidence): Detected route in routes/breadcrumbs.php. Context: `{"file":"routes/breadcrumbs.php","line":91,"usage_type":"function_call"}`
- `source-576` (`E3`, high confidence): Detected Diglactic\Breadcrumbs\Breadcrumbs in routes/breadcrumbs.php. Context: `{"file":"routes/breadcrumbs.php","line":95,"usage_type":"static_call"}`
- `source-577` (`E3`, high confidence): Detected route in routes/breadcrumbs.php. Context: `{"file":"routes/breadcrumbs.php","line":97,"usage_type":"function_call"}`
- `source-578` (`E3`, high confidence): Detected Broadcast in routes/channels.php. Context: `{"file":"routes/channels.php","line":14,"usage_type":"static_call"}`
- `source-579` (`E3`, high confidence): Detected Illuminate\Foundation\Inspiring in routes/console.php. Context: `{"file":"routes/console.php","line":3,"usage_type":"namespace_import"}`
- `source-580` (`E3`, high confidence): Detected Artisan in routes/console.php. Context: `{"file":"routes/console.php","line":16,"usage_type":"static_call"}`
- `source-581` (`E3`, high confidence): Detected Illuminate\Foundation\Inspiring in routes/console.php. Context: `{"file":"routes/console.php","line":17,"usage_type":"static_call"}`
- `source-582` (`E3`, high confidence): Detected Illuminate\Contracts\Console\Kernel in tests/CreatesApplication.php. Context: `{"file":"tests/CreatesApplication.php","line":5,"usage_type":"namespace_import"}`
- `source-583` (`E3`, high confidence): Detected Illuminate\Foundation\Application in tests/CreatesApplication.php. Context: `{"file":"tests/CreatesApplication.php","line":6,"usage_type":"namespace_import"}`
- `source-584` (`E3`, high confidence): Detected Illuminate\Contracts\Console\Kernel in tests/CreatesApplication.php. Context: `{"file":"tests/CreatesApplication.php","line":17,"usage_type":"class_constant_access"}`
- `source-585` (`E3`, high confidence): Detected uses in tests/Pest.php. Context: `{"file":"tests/Pest.php","line":14,"usage_type":"function_call"}`
- `source-586` (`E3`, high confidence): Detected Webkul\Admin\Tests\AdminTestCase in tests/Pest.php. Context: `{"file":"tests/Pest.php","line":14,"usage_type":"class_constant_access"}`
- `source-587` (`E3`, high confidence): Detected uses in tests/Pest.php. Context: `{"file":"tests/Pest.php","line":15,"usage_type":"function_call"}`
- `source-588` (`E3`, high confidence): Detected Webkul\Core\Tests\CoreTestCase in tests/Pest.php. Context: `{"file":"tests/Pest.php","line":15,"usage_type":"class_constant_access"}`
- `source-589` (`E3`, high confidence): Detected uses in tests/Pest.php. Context: `{"file":"tests/Pest.php","line":16,"usage_type":"function_call"}`
- `source-590` (`E3`, high confidence): Detected Webkul\DataGrid\Tests\DataGridTestCase in tests/Pest.php. Context: `{"file":"tests/Pest.php","line":16,"usage_type":"class_constant_access"}`
- `source-591` (`E3`, high confidence): Detected uses in tests/Pest.php. Context: `{"file":"tests/Pest.php","line":17,"usage_type":"function_call"}`
- `source-592` (`E3`, high confidence): Detected Webkul\Shop\Tests\ShopTestCase in tests/Pest.php. Context: `{"file":"tests/Pest.php","line":17,"usage_type":"class_constant_access"}`
- `source-593` (`E3`, high confidence): Detected expect in tests/Pest.php. Context: `{"file":"tests/Pest.php","line":30,"usage_type":"function_call"}`
- `source-594` (`E3`, high confidence): Detected Illuminate\Foundation\Testing\DatabaseTransactions in tests/TestCase.php. Context: `{"file":"tests/TestCase.php","line":5,"usage_type":"namespace_import"}`
- `source-595` (`E3`, high confidence): Detected Illuminate\Foundation\Testing\TestCase in tests/TestCase.php. Context: `{"file":"tests/TestCase.php","line":6,"usage_type":"namespace_import"}`
- `source-596` (`E3`, high confidence): Detected Illuminate\Foundation\Testing\TestCase in tests/TestCase.php. Context: `{"file":"tests/TestCase.php","line":8,"usage_type":"inheritance"}`
- `source-597` (`E3`, high confidence): Detected Tests\CreatesApplication in tests/TestCase.php. Context: `{"file":"tests/TestCase.php","line":10,"usage_type":"trait_reference"}`
- `source-598` (`E3`, high confidence): Detected Illuminate\Foundation\Testing\DatabaseTransactions in tests/TestCase.php. Context: `{"file":"tests/TestCase.php","line":10,"usage_type":"trait_reference"}`
- `laravel-transition-1` (`E4`, medium confidence): The implemented Laravel 10 to 11 rule pack covers this requested transition. Context: `{"source_major":10,"target_major":11,"rule_pack":"laravel-10-to-11","source":"https://laravel.com/docs/11.x/upgrade"}`
- `laravel-transition-2` (`E4`, medium confidence): The implemented Laravel 11 to 12 rule pack covers this requested transition. Context: `{"source_major":11,"target_major":12,"rule_pack":"laravel-11-to-12","source":"https://laravel.com/docs/12.x/upgrade"}`
- `laravel-transition-3` (`E4`, medium confidence): The implemented Laravel 12 to 13 rule pack covers this requested transition. Context: `{"source_major":12,"target_major":13,"rule_pack":"laravel-12-to-13","source":"https://github.com/laravel/docs/blob/9c5a062c14069bab9054b558829e282f9593a065/upgrade.md"}`
- `laravel-framework-constraint-1` (`E2`, high confidence): The root Laravel framework constraint does not include the requested target major. Context: `{"package":"laravel/framework","root_constraint":"^10.0","target_constraint":"^13.0","target_laravel_major":13}`
- `old-illuminate-consumer-1` (`E2`, high confidence): astrotomic/laravel-translatable declares an illuminate/support constraint that excludes the requested Laravel 11 range. Context: `{"package":"astrotomic/laravel-translatable","locked_version":"v11.12.1","illuminate_support_constraint":"^8.0 || ^9.0 || ^10.0","target_laravel_major":11}`
- `old-illuminate-consumer-2` (`E2`, high confidence): barryvdh/laravel-dompdf declares an illuminate/support constraint that excludes the requested Laravel 11 range. Context: `{"package":"barryvdh/laravel-dompdf","locked_version":"v2.0.1","illuminate_support_constraint":"^6|^7|^8|^9|^10","target_laravel_major":11}`
- `old-illuminate-consumer-3` (`E2`, high confidence): kalnoy/nestedset declares an illuminate/support constraint that excludes the requested Laravel 11 range. Context: `{"package":"kalnoy/nestedset","locked_version":"v6.0.3","illuminate_support_constraint":"^7.0|^8.0|^9.0|^10.0","target_laravel_major":11}`
- `old-illuminate-consumer-4` (`E2`, high confidence): maatwebsite/excel declares an illuminate/support constraint that excludes the requested Laravel 11 range. Context: `{"package":"maatwebsite/excel","locked_version":"3.1.52","illuminate_support_constraint":"5.8.*||^6.0||^7.0||^8.0||^9.0||^10.0","target_laravel_major":11}`
- `old-illuminate-consumer-5` (`E2`, high confidence): prettus/l5-repository declares an illuminate/support constraint that excludes the requested Laravel 11 range. Context: `{"package":"prettus/l5-repository","locked_version":"2.9.0","illuminate_support_constraint":"~5.0|~6.0|~7.0|^8.0|^9.0|^10.0","target_laravel_major":11}`
- `old-illuminate-consumer-6` (`E2`, high confidence): prettus/laravel-validation declares an illuminate/support constraint that excludes the requested Laravel 11 range. Context: `{"package":"prettus/laravel-validation","locked_version":"1.5.0","illuminate_support_constraint":"~5.4|^6.0|^7.0|^8.0|^9.0|^10.0","target_laravel_major":11}`
- `old-illuminate-consumer-7` (`E2`, high confidence): shetabit/visitor declares an illuminate/support constraint that excludes the requested Laravel 11 range. Context: `{"package":"shetabit/visitor","locked_version":"v4.1.0","illuminate_support_constraint":"^5.1|6.*|7.*|8.*|9.*|10.*","target_laravel_major":11}`
- `old-illuminate-consumer-8` (`E2`, high confidence): spatie/laravel-responsecache declares an illuminate/support constraint that excludes the requested Laravel 11 range. Context: `{"package":"spatie/laravel-responsecache","locked_version":"7.4.10","illuminate_support_constraint":"^8.71|^9.0|^10.0","target_laravel_major":11}`
- `old-illuminate-consumer-9` (`E2`, high confidence): spatie/laravel-sitemap declares an illuminate/support constraint that excludes the requested Laravel 11 range. Context: `{"package":"spatie/laravel-sitemap","locked_version":"6.4.0","illuminate_support_constraint":"^8.0|^9.0|^10.0","target_laravel_major":11}`
- `old-illuminate-consumer-10` (`E2`, high confidence): barryvdh/laravel-debugbar declares an illuminate/support constraint that excludes the requested Laravel 11 range. Context: `{"package":"barryvdh/laravel-debugbar","locked_version":"v3.9.2","illuminate_support_constraint":"^9|^10","target_laravel_major":11}`
- `old-illuminate-consumer-11` (`E2`, high confidence): konekt/concord declares an illuminate/support constraint that excludes the requested Laravel 12 range. Context: `{"package":"konekt/concord","locked_version":"1.14.0","illuminate_support_constraint":"^9.2|^10.0|^11.0","target_laravel_major":12}`
- `old-illuminate-consumer-12` (`E2`, high confidence): laravel/socialite declares an illuminate/support constraint that excludes the requested Laravel 12 range. Context: `{"package":"laravel/socialite","locked_version":"v5.11.0","illuminate_support_constraint":"^6.0|^7.0|^8.0|^9.0|^10.0|^11.0","target_laravel_major":12}`
- `old-illuminate-consumer-13` (`E2`, high confidence): laravel/tinker declares an illuminate/support constraint that excludes the requested Laravel 12 range. Context: `{"package":"laravel/tinker","locked_version":"v2.9.0","illuminate_support_constraint":"^6.0|^7.0|^8.0|^9.0|^10.0|^11.0","target_laravel_major":12}`
- `old-illuminate-consumer-14` (`E2`, high confidence): laravel/ui declares an illuminate/support constraint that excludes the requested Laravel 12 range. Context: `{"package":"laravel/ui","locked_version":"v4.4.0","illuminate_support_constraint":"^9.21|^10.0|^11.0","target_laravel_major":12}`
- `old-illuminate-consumer-15` (`E2`, high confidence): spatie/laravel-ignition declares an illuminate/support constraint that excludes the requested Laravel 12 range. Context: `{"package":"spatie/laravel-ignition","locked_version":"2.4.1","illuminate_support_constraint":"^10.0|^11.0","target_laravel_major":12}`
- `laravel-package-nunomaduro_collision-1` (`E2`, high confidence): nunomaduro/collision is present in Composer metadata. Context: `{"package":"nunomaduro/collision","locked_version":"v7.10.0","root_constraint":"^7.0","framework_requirements":[],"target_laravel_major":11}`
- `laravel-package-guidance-1` (`E4`, medium confidence): The encoded Laravel 11 guidance maps nunomaduro/collision to `^8.1`. Context: `{"package":"nunomaduro/collision","target_laravel_major":11,"compatible_package_constraint":"^8.1","sources":["https://laravel.com/docs/11.x/upgrade"]}`
- `laravel-package-laravel_sanctum-1` (`E2`, high confidence): laravel/sanctum is present in Composer metadata. Context: `{"package":"laravel/sanctum","locked_version":"v3.3.3","root_constraint":"^3.2","framework_requirements":{"illuminate/console":"^9.21|^10.0","illuminate/contracts":"^9.21|^10.0","illuminate/database":"^9.21|^10.0","illuminate/support":"^9.21|^10.0"},"target_laravel_major":11}`
- `laravel-package-guidance-2` (`E4`, medium confidence): The encoded Laravel 11 guidance maps laravel/sanctum to `^4.0`. Context: `{"package":"laravel/sanctum","target_laravel_major":11,"compatible_package_constraint":"^4.0","sources":["https://laravel.com/docs/11.x/upgrade"]}`
- `laravel-package-phpunit_phpunit-1` (`E2`, high confidence): phpunit/phpunit is present in Composer metadata. Context: `{"package":"phpunit/phpunit","locked_version":"10.5.5","root_constraint":"^10.0","framework_requirements":[],"target_laravel_major":11}`
- `laravel-package-guidance-3` (`E4`, medium confidence): The encoded Laravel 11 guidance maps phpunit/phpunit to `^10.5.35|^11.0.1|^12.0.1`. Context: `{"package":"phpunit/phpunit","target_laravel_major":11,"compatible_package_constraint":"^10.5.35|^11.0.1|^12.0.1","sources":["https://github.com/laravel/laravel/blob/ecf6de4992d70dd37c21676be6b8ba4743151e63/composer.json","https://github.com/laravel/framework/blob/e353708c960ec5066d76b0da4b81c8a68d183b93/composer.json"]}`
- `laravel-advisory-doctrine_dbal-1` (`E2`, high confidence): doctrine/dbal is present in Composer metadata. Context: `{"package":"doctrine/dbal","locked_version":"3.7.2","root_constraint":"^3.0","target_laravel_major":11}`
- `laravel-package-advisory-1` (`E4`, medium confidence): Review and remove doctrine/dbal if it was only installed for Laravel schema operations; Laravel 11 no longer depends on it. Context: `{"package":"doctrine/dbal","target_laravel_major":11,"source":"https://laravel.com/docs/11.x/upgrade"}`
- `laravel-advisory-laravel_sanctum-1` (`E2`, high confidence): laravel/sanctum is present in Composer metadata. Context: `{"package":"laravel/sanctum","locked_version":"v3.3.3","root_constraint":"^3.2","target_laravel_major":11}`
- `laravel-package-advisory-2` (`E4`, medium confidence): Publish the laravel/sanctum migrations before deploying the Laravel 11 upgrade; this package no longer loads its migrations automatically. Context: `{"package":"laravel/sanctum","target_laravel_major":11,"source":"https://laravel.com/docs/11.x/upgrade"}`
- `laravel-package-phpunit_phpunit-2` (`E2`, high confidence): phpunit/phpunit is present in Composer metadata. Context: `{"package":"phpunit/phpunit","locked_version":"10.5.5","root_constraint":"^10.0","framework_requirements":[],"target_laravel_major":12}`
- `laravel-package-guidance-4` (`E4`, medium confidence): The encoded Laravel 12 guidance maps phpunit/phpunit to `^10.5.35|^11.0|^12.0.1`. Context: `{"package":"phpunit/phpunit","target_laravel_major":12,"compatible_package_constraint":"^10.5.35|^11.0|^12.0.1","sources":["https://github.com/laravel/docs/blob/5b8c610735c8af96a3bda4e37a820b27dc40aee9/upgrade.md","https://github.com/laravel/framework/blob/5260836df1b953a558d9b810880f20db15568c01/composer.json"]}`
- `laravel-package-pestphp_pest-1` (`E2`, high confidence): pestphp/pest is present in Composer metadata. Context: `{"package":"pestphp/pest","locked_version":"v2.31.0","root_constraint":"^2.6","framework_requirements":[],"target_laravel_major":12}`
- `laravel-package-guidance-5` (`E4`, medium confidence): The encoded Laravel 12 guidance maps pestphp/pest to `^3.0|^4.0`. Context: `{"package":"pestphp/pest","target_laravel_major":12,"compatible_package_constraint":"^3.0|^4.0","sources":["https://laravel.com/docs/12.x/upgrade","https://github.com/pestphp/pest-plugin-laravel/blob/3057a36669ff11416cc0dc2b521b3aec58c488d0/composer.json"]}`
- `laravel-package-nesbot_carbon-1` (`E2`, high confidence): nesbot/carbon is present in Composer metadata. Context: `{"package":"nesbot/carbon","locked_version":"2.72.1","root_constraint":null,"framework_requirements":[],"target_laravel_major":12}`
- `laravel-package-guidance-6` (`E4`, medium confidence): The encoded Laravel 12 guidance maps nesbot/carbon to `^3.0`. Context: `{"package":"nesbot/carbon","target_laravel_major":12,"compatible_package_constraint":"^3.0","sources":["https://laravel.com/docs/12.x/upgrade"]}`
- `laravel-package-nunomaduro_collision-2` (`E2`, high confidence): nunomaduro/collision is present in Composer metadata. Context: `{"package":"nunomaduro/collision","locked_version":"v7.10.0","root_constraint":"^7.0","framework_requirements":[],"target_laravel_major":12}`
- `laravel-package-guidance-7` (`E4`, medium confidence): The encoded Laravel 12 guidance maps nunomaduro/collision to `^8.6`. Context: `{"package":"nunomaduro/collision","target_laravel_major":12,"compatible_package_constraint":"^8.6","sources":["https://github.com/laravel/laravel/blob/12.x/composer.json"]}`
- `laravel-package-laravel_tinker-1` (`E2`, high confidence): laravel/tinker is present in Composer metadata. Context: `{"package":"laravel/tinker","locked_version":"v2.9.0","root_constraint":"^2.0","framework_requirements":{"illuminate/console":"^6.0|^7.0|^8.0|^9.0|^10.0|^11.0","illuminate/contracts":"^6.0|^7.0|^8.0|^9.0|^10.0|^11.0","illuminate/support":"^6.0|^7.0|^8.0|^9.0|^10.0|^11.0"},"target_laravel_major":13}`
- `laravel-package-guidance-8` (`E4`, medium confidence): The encoded Laravel 13 guidance maps laravel/tinker to `^3.0`. Context: `{"package":"laravel/tinker","target_laravel_major":13,"compatible_package_constraint":"^3.0","sources":["https://github.com/laravel/docs/blob/9c5a062c14069bab9054b558829e282f9593a065/upgrade.md"]}`
- `laravel-package-phpunit_phpunit-3` (`E2`, high confidence): phpunit/phpunit is present in Composer metadata. Context: `{"package":"phpunit/phpunit","locked_version":"10.5.5","root_constraint":"^10.0","framework_requirements":[],"target_laravel_major":13}`
- `laravel-package-guidance-9` (`E4`, medium confidence): The encoded Laravel 13 guidance maps phpunit/phpunit to `^11.5.50|^12.0|^13.0.3`. Context: `{"package":"phpunit/phpunit","target_laravel_major":13,"compatible_package_constraint":"^11.5.50|^12.0|^13.0.3","sources":["https://github.com/laravel/docs/blob/9c5a062c14069bab9054b558829e282f9593a065/upgrade.md","https://github.com/laravel/laravel/blob/c926b8ca7fa01e71852e19141f2bdd7fabfb6ade/composer.json","https://github.com/laravel/framework/blob/8df67f9d176d1d0375a866d8c6780be95ce0336e/composer.json"]}`
- `laravel-package-pestphp_pest-2` (`E2`, high confidence): pestphp/pest is present in Composer metadata. Context: `{"package":"pestphp/pest","locked_version":"v2.31.0","root_constraint":"^2.6","framework_requirements":[],"target_laravel_major":13}`
- `laravel-package-guidance-10` (`E4`, medium confidence): The encoded Laravel 13 guidance maps pestphp/pest to `^4.0|^5.0`. Context: `{"package":"pestphp/pest","target_laravel_major":13,"compatible_package_constraint":"^4.0|^5.0","sources":["https://github.com/laravel/docs/blob/9c5a062c14069bab9054b558829e282f9593a065/upgrade.md","https://github.com/pestphp/pest-plugin-laravel/blob/3057a36669ff11416cc0dc2b521b3aec58c488d0/composer.json","https://github.com/pestphp/pest-plugin-laravel/blob/d1564646e3198f1b607e64a36501d6edff7d104e/composer.json"]}`
- `laravel-package-nunomaduro_collision-3` (`E2`, high confidence): nunomaduro/collision is present in Composer metadata. Context: `{"package":"nunomaduro/collision","locked_version":"v7.10.0","root_constraint":"^7.0","framework_requirements":[],"target_laravel_major":13}`
- `laravel-package-guidance-11` (`E4`, medium confidence): The encoded Laravel 13 guidance maps nunomaduro/collision to `^8.6`. Context: `{"package":"nunomaduro/collision","target_laravel_major":13,"compatible_package_constraint":"^8.6","sources":["https://github.com/laravel/laravel/blob/c926b8ca7fa01e71852e19141f2bdd7fabfb6ade/composer.json"]}`
- `laravel-request-forgery-guidance-1` (`E4`, high confidence): Laravel 13 renames the CSRF middleware to PreventRequestForgery and deprecates the previous aliases. Context: `{"legacy_symbols":["Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken","Illuminate\\Foundation\\Http\\Middleware\\ValidateCsrfToken"],"replacement_symbol":"Illuminate\\Foundation\\Http\\Middleware\\PreventRequestForgery","source":"https://github.com/laravel/docs/blob/9c5a062c14069bab9054b558829e282f9593a065/upgrade.md"}`
- `ownership-1` (`E2`, high confidence): Correlated Illuminate\Foundation\Http\Middleware\VerifyCsrfToken with Composer autoload metadata. Context: `{"symbol":"Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken","candidate_packages":["laravel/framework"],"mapping_types":["psr-4"],"matched_prefix":"illuminate\\"}`
- `root-constraint-1` (`E2`, high confidence): Compared the root requirement for laravel/framework with the requested target. Context: `{"package":"laravel/framework","from_constraint":"^10.0","to_constraint":"^13.0"}`
- `stage-plan-1` (`E5`, low confidence): Generated recommendations from the executed outcome of stage laravel-10-to-11. Context: `{"stage_id":"laravel-10-to-11","execution_state":"evaluated","resolution_status":"blocked","transition_recommended":false}`
